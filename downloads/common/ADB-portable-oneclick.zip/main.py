# -*- coding: utf-8 -*-
"""
ADB 环境一键部署工具
- 检测本机 ADB 环境
- 一键下载 Google platform-tools（多镜像兜底）
- 解压到指定目录
- 自动写入用户/系统 PATH 环境变量
- 验证安装结果
"""
import ctypes
import os
import queue
import shutil
import subprocess
import sys
import tempfile
import threading
import winreg
import zipfile
from pathlib import Path

import customtkinter as ctk
import requests

# ------------------------------------------------------------ 常量
APP_NAME = "ADB 环境一键部署"
ACCENT = "#3DDC84"          # Android 绿
ACCENT_HOVER = "#2FBF71"
DANGER = "#FF5C5C"
CARD_DARK = "#1B1F24"
CARD_LIGHT = "#F3F5F7"

DOWNLOAD_URLS = [
    "https://dl.google.com/android/repository/platform-tools-latest-windows.zip",
    "https://googledownloads.cn/android/repository/platform-tools-latest-windows.zip",
]
DEFAULT_INSTALL_DIR = r"C:\platform-tools"

CREATE_NO_WINDOW = 0x08000000


# ------------------------------------------------------------ 工具函数
def is_admin() -> bool:
    try:
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except Exception:
        return False


def run_silent(cmd, timeout=15):
    """静默执行命令，返回 (returncode, stdout)。"""
    try:
        p = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout,
            creationflags=CREATE_NO_WINDOW, encoding="utf-8", errors="replace",
        )
        return p.returncode, (p.stdout or "") + (p.stderr or "")
    except Exception as e:
        return -1, str(e)


def find_adb():
    """返回 (found: bool, version: str, source: str)"""
    code, out = run_silent(["adb", "version"])
    if code == 0 and "Android Debug Bridge" in out:
        ver = out.strip().splitlines()[0] if out.strip() else "未知版本"
        return True, ver, "PATH"
    for d in (DEFAULT_INSTALL_DIR, str(Path.home() / "platform-tools")):
        exe = os.path.join(d, "adb.exe")
        if os.path.exists(exe):
            code, out = run_silent([exe, "version"])
            ver = out.strip().splitlines()[0] if code == 0 and out.strip() else "已存在"
            return True, ver, d
    return False, "", ""


def read_path_var(system: bool) -> str:
    """读取注册表中的 Path（用户或系统）。"""
    if system:
        key_path = r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment"
        hive = winreg.HKEY_LOCAL_MACHINE
    else:
        key_path = r"Environment"
        hive = winreg.HKEY_CURRENT_USER
    try:
        with winreg.OpenKey(hive, key_path, 0, winreg.KEY_READ) as k:
            val, _ = winreg.QueryValueEx(k, "Path")
            return val
    except FileNotFoundError:
        return ""


def write_path_var(value: str, system: bool):
    if system:
        key_path = r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment"
        hive = winreg.HKEY_LOCAL_MACHINE
    else:
        key_path = r"Environment"
        hive = winreg.HKEY_CURRENT_USER
    with winreg.OpenKey(hive, key_path, 0, winreg.KEY_SET_VALUE) as k:
        winreg.SetValueEx(k, "Path", 0, winreg.REG_EXPAND_SZ, value)


def broadcast_env_change():
    """通知系统环境变量已更改，让新开的终端立即生效。"""
    try:
        HWND_BROADCAST, WM_SETTINGCHANGE, SMTO_ABORTIFHUNG = 0xFFFF, 0x001A, 0x0002
        result = ctypes.c_ulong()
        ctypes.windll.user32.SendMessageTimeoutW(
            HWND_BROADCAST, WM_SETTINGCHANGE, 0, "Environment",
            SMTO_ABORTIFHUNG, 5000, ctypes.byref(result),
        )
    except Exception:
        pass


def add_to_path(directory: str, system: bool) -> str:
    """把目录加入 Path（去重、不覆盖），返回操作描述。"""
    directory = os.path.normpath(directory)
    current = read_path_var(system)
    entries = [e for e in current.split(";") if e.strip()]
    if any(os.path.normpath(e).lower() == directory.lower() for e in entries):
        return "already"
    new_value = current.rstrip(";") + (";" if current.strip() else "") + directory
    write_path_var(new_value, system)
    broadcast_env_change()
    return "added"


def remove_from_path(directory: str, system: bool) -> bool:
    directory = os.path.normpath(directory)
    current = read_path_var(system)
    entries = [e for e in current.split(";") if e.strip()]
    kept = [e for e in entries if os.path.normpath(e).lower() != directory.lower()]
    if len(kept) == len(entries):
        return False
    write_path_var(";".join(kept), system)
    broadcast_env_change()
    return True


# ------------------------------------------------------------ 主界面
class AdbSetupApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("green")

        self.title(APP_NAME)
        self.geometry("720x640")
        self.minsize(680, 600)

        self.msg_queue = queue.Queue()
        self.busy = False

        self._build_ui()
        self.after(100, self._poll_queue)
        self.after(300, self.refresh_status)

    # ---------------- UI 构建
    def _build_ui(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(3, weight=1)

        # 头部
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.grid(row=0, column=0, sticky="ew", padx=24, pady=(20, 8))
        header.grid_columnconfigure(1, weight=1)

        logo = ctk.CTkLabel(header, text="⬢", font=ctk.CTkFont(size=34),
                            text_color=ACCENT, width=48)
        logo.grid(row=0, column=0, rowspan=2, padx=(0, 12))
        title = ctk.CTkLabel(header, text=APP_NAME,
                             font=ctk.CTkFont(size=22, weight="bold"), anchor="w")
        title.grid(row=0, column=1, sticky="w")
        sub = ctk.CTkLabel(header, text="自动下载 Platform-Tools · 解压 · 配置环境变量 · 验证",
                           font=ctk.CTkFont(size=12), text_color="gray60", anchor="w")
        sub.grid(row=1, column=1, sticky="w")

        self.theme_btn = ctk.CTkButton(header, text="☀ 浅色", width=80,
                                       fg_color="transparent", border_width=1,
                                       border_color="gray40", text_color=("gray20", "gray80"),
                                       hover_color=("gray85", "gray25"),
                                       command=self.toggle_theme)
        self.theme_btn.grid(row=0, column=2, rowspan=2)

        # 状态卡片
        self.status_card = ctk.CTkFrame(self, corner_radius=12)
        self.status_card.grid(row=1, column=0, sticky="ew", padx=24, pady=8)
        self.status_card.grid_columnconfigure(1, weight=1)

        self.status_icon = ctk.CTkLabel(self.status_card, text="…",
                                        font=ctk.CTkFont(size=26), width=56)
        self.status_icon.grid(row=0, column=0, rowspan=2, padx=8, pady=14)
        self.status_title = ctk.CTkLabel(self.status_card, text="正在检测本机 ADB 环境…",
                                         font=ctk.CTkFont(size=15, weight="bold"), anchor="w")
        self.status_title.grid(row=0, column=1, sticky="w", pady=(14, 0))
        self.status_detail = ctk.CTkLabel(self.status_card, text="",
                                          font=ctk.CTkFont(size=12), text_color="gray60", anchor="w")
        self.status_detail.grid(row=1, column=1, sticky="w", pady=(0, 14))
        self.refresh_btn = ctk.CTkButton(self.status_card, text="重新检测", width=90,
                                         fg_color="transparent", border_width=1,
                                         border_color="gray40", text_color=("gray20", "gray80"),
                                         hover_color=("gray85", "gray25"),
                                         command=self.refresh_status)
        self.refresh_btn.grid(row=0, column=2, rowspan=2, padx=14)

        # 配置区
        cfg = ctk.CTkFrame(self, corner_radius=12)
        cfg.grid(row=2, column=0, sticky="ew", padx=24, pady=8)
        cfg.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(cfg, text="安装目录", font=ctk.CTkFont(size=13, weight="bold"),
                     anchor="w").grid(row=0, column=0, padx=16, pady=(14, 4), sticky="w")
        self.dir_entry = ctk.CTkEntry(cfg, height=34)
        self.dir_entry.insert(0, DEFAULT_INSTALL_DIR)
        self.dir_entry.grid(row=0, column=1, padx=(4, 8), pady=(14, 4), sticky="ew")
        ctk.CTkButton(cfg, text="浏览", width=64, fg_color="transparent", border_width=1,
                      border_color="gray40", text_color=("gray20", "gray80"),
                      hover_color=("gray85", "gray25"),
                      command=self.browse_dir).grid(row=0, column=2, padx=(0, 16), pady=(14, 4))

        scope_text = "写入位置" + ("（已获取管理员权限）" if is_admin() else "（当前为普通权限，仅可写用户变量）")
        ctk.CTkLabel(cfg, text=scope_text, font=ctk.CTkFont(size=13, weight="bold"),
                     anchor="w").grid(row=1, column=0, padx=16, pady=4, sticky="w")
        self.scope_var = ctk.StringVar(value="user")
        scope_frame = ctk.CTkFrame(cfg, fg_color="transparent")
        scope_frame.grid(row=1, column=1, columnspan=2, sticky="w", padx=4, pady=4)
        ctk.CTkRadioButton(scope_frame, text="用户环境变量（推荐）", variable=self.scope_var,
                           value="user", fg_color=ACCENT).pack(side="left", padx=(0, 16))
        self.sys_radio = ctk.CTkRadioButton(scope_frame, text="系统环境变量（所有用户）",
                                            variable=self.scope_var, value="system",
                                            fg_color=ACCENT)
        self.sys_radio.pack(side="left")
        if not is_admin():
            self.sys_radio.configure(state="disabled")

        self.zip_var = ctk.StringVar(value="")
        zip_row = ctk.CTkFrame(cfg, fg_color="transparent")
        zip_row.grid(row=2, column=0, columnspan=3, sticky="ew", padx=16, pady=(4, 14))
        zip_row.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(zip_row, text="离线安装包（可选）", font=ctk.CTkFont(size=12),
                     text_color="gray60").grid(row=0, column=0, sticky="w")
        self.zip_label = ctk.CTkLabel(zip_row, text="未选择（将在线下载）",
                                      font=ctk.CTkFont(size=12), text_color="gray60", anchor="w")
        self.zip_label.grid(row=0, column=1, sticky="w", padx=10)
        ctk.CTkButton(zip_row, text="选择 ZIP", width=80, fg_color="transparent",
                      border_width=1, border_color="gray40",
                      text_color=("gray20", "gray80"), hover_color=("gray85", "gray25"),
                      command=self.pick_zip).grid(row=0, column=2)

        # 操作区
        action = ctk.CTkFrame(self, fg_color="transparent")
        action.grid(row=4, column=0, sticky="ew", padx=24, pady=(8, 4))
        action.grid_columnconfigure(0, weight=1)

        self.install_btn = ctk.CTkButton(
            action, text="⚡ 一键部署 ADB 环境", height=46,
            font=ctk.CTkFont(size=16, weight="bold"),
            fg_color=ACCENT, hover_color=ACCENT_HOVER, text_color="#0B1420",
            corner_radius=10, command=self.start_install)
        self.install_btn.grid(row=0, column=0, sticky="ew", padx=(0, 10))
        self.path_btn = ctk.CTkButton(
            action, text="仅配置环境变量", height=46, width=150,
            fg_color="transparent", border_width=1, border_color=ACCENT,
            text_color=ACCENT, hover_color=("gray85", "gray25"),
            corner_radius=10, command=self.start_path_only)
        self.path_btn.grid(row=0, column=1)

        self.progress = ctk.CTkProgressBar(self, height=10, progress_color=ACCENT,
                                           corner_radius=5)
        self.progress.grid(row=5, column=0, sticky="ew", padx=24, pady=(6, 2))
        self.progress.set(0)
        self.step_label = ctk.CTkLabel(self, text="就绪", font=ctk.CTkFont(size=12),
                                       text_color="gray60", anchor="w")
        self.step_label.grid(row=6, column=0, sticky="w", padx=26)

        # 日志
        log_card = ctk.CTkFrame(self, corner_radius=12)
        log_card.grid(row=3, column=0, sticky="nsew", padx=24, pady=8)
        log_card.grid_columnconfigure(0, weight=1)
        log_card.grid_rowconfigure(1, weight=1)
        ctk.CTkLabel(log_card, text="运行日志", font=ctk.CTkFont(size=13, weight="bold"),
                     anchor="w").grid(row=0, column=0, sticky="w", padx=16, pady=(10, 0))
        self.log_box = ctk.CTkTextbox(log_card, font=ctk.CTkFont(family="Consolas", size=12),
                                      corner_radius=8, wrap="word")
        self.log_box.grid(row=1, column=0, sticky="nsew", padx=12, pady=(6, 12))
        self.log_box.configure(state="disabled")

    # ---------------- 界面辅助
    def toggle_theme(self):
        cur = ctk.get_appearance_mode()
        if cur == "Dark":
            ctk.set_appearance_mode("light")
            self.theme_btn.configure(text="🌙 深色")
        else:
            ctk.set_appearance_mode("dark")
            self.theme_btn.configure(text="☀ 浅色")

    def browse_dir(self):
        from tkinter import filedialog
        d = filedialog.askdirectory(title="选择 ADB 安装目录")
        if d:
            self.dir_entry.delete(0, "end")
            self.dir_entry.insert(0, os.path.normpath(d))

    def pick_zip(self):
        from tkinter import filedialog
        f = filedialog.askopenfilename(title="选择 platform-tools ZIP",
                                       filetypes=[("ZIP 压缩包", "*.zip")])
        if f:
            self.zip_var.set(f)
            self.zip_label.configure(text=os.path.basename(f))

    def log(self, text: str):
        self.log_box.configure(state="normal")
        self.log_box.insert("end", text + "\n")
        self.log_box.see("end")
        self.log_box.configure(state="disabled")

    def set_step(self, text: str, frac: float = None):
        self.step_label.configure(text=text)
        if frac is not None:
            self.progress.set(frac)

    def set_busy(self, busy: bool):
        self.busy = busy
        state = "disabled" if busy else "normal"
        self.install_btn.configure(state=state)
        self.path_btn.configure(state=state)
        self.refresh_btn.configure(state=state)

    def refresh_status(self):
        if self.busy:
            return
        found, ver, src = find_adb()
        if found:
            self.status_icon.configure(text="✓", text_color=ACCENT)
            self.status_title.configure(text="已检测到 ADB 环境")
            self.status_detail.configure(text=f"{ver}    来源：{src}")
        else:
            self.status_icon.configure(text="✕", text_color=DANGER)
            self.status_title.configure(text="未检测到 ADB 环境")
            self.status_detail.configure(text="点击下方「一键部署」自动完成安装与环境变量配置")

    # ---------------- 队列轮询（线程安全刷新 UI）
    def _poll_queue(self):
        try:
            while True:
                kind, payload = self.msg_queue.get_nowait()
                if kind == "log":
                    self.log(payload)
                elif kind == "step":
                    text, frac = payload
                    self.set_step(text, frac)
                elif kind == "done":
                    ok, msg = payload
                    self.set_busy(False)
                    self.set_step("完成" if ok else "未完成")
                    self.refresh_status()
                    self._show_result(ok, msg)
        except queue.Empty:
            pass
        self.after(100, self._poll_queue)

    def _show_result(self, ok: bool, msg: str):
        win = ctk.CTkToplevel(self)
        win.title("部署结果")
        win.geometry("460x220")
        win.transient(self)
        win.grab_set()
        icon = "✓" if ok else "✕"
        color = ACCENT if ok else DANGER
        ctk.CTkLabel(win, text=icon, font=ctk.CTkFont(size=40),
                     text_color=color).pack(pady=(24, 6))
        ctk.CTkLabel(win, text="部署成功" if ok else "部署未完成",
                     font=ctk.CTkFont(size=18, weight="bold")).pack()
        ctk.CTkLabel(win, text=msg, font=ctk.CTkFont(size=12),
                     text_color="gray60", wraplength=400, justify="center").pack(pady=8, padx=20)
        ctk.CTkButton(win, text="知道了", fg_color=ACCENT, hover_color=ACCENT_HOVER,
                      text_color="#0B1420", command=win.destroy).pack(pady=10)
        self.update_idletasks()
        x = self.winfo_x() + (self.winfo_width() - 460) // 2
        y = self.winfo_y() + (self.winfo_height() - 220) // 2
        win.geometry(f"+{x}+{y}")

    # ---------------- 后台任务
    def qlog(self, t):
        self.msg_queue.put(("log", t))

    def qstep(self, t, f=None):
        self.msg_queue.put(("step", (t, f)))

    def start_install(self):
        if self.busy:
            return
        install_dir = self.dir_entry.get().strip() or DEFAULT_INSTALL_DIR
        system = self.scope_var.get() == "system"
        zip_path = self.zip_var.get().strip() or None
        self.set_busy(True)
        self.progress.set(0)
        threading.Thread(target=self._install_worker,
                         args=(install_dir, system, zip_path), daemon=True).start()

    def start_path_only(self):
        if self.busy:
            return
        install_dir = self.dir_entry.get().strip() or DEFAULT_INSTALL_DIR
        system = self.scope_var.get() == "system"
        self.set_busy(True)
        threading.Thread(target=self._path_only_worker,
                         args=(install_dir, system), daemon=True).start()

    def _path_only_worker(self, install_dir, system):
        try:
            self.qstep("正在配置环境变量…", 0.4)
            adb_exe = os.path.join(install_dir, "adb.exe")
            if not os.path.exists(adb_exe):
                self.qlog(f"[提示] {adb_exe} 不存在，仍将把目录写入 PATH")
            result = add_to_path(install_dir, system)
            scope = "系统" if system else "用户"
            if result == "already":
                self.qlog(f"[信息] 该目录已存在于{scope} Path 中，无需修改")
                self.msg_queue.put(("done", (True, "该目录已在环境变量中")))
            else:
                self.qlog(f"[成功] 已写入{scope} Path：{install_dir}")
                self.qlog("[提示] 已广播环境变更，新打开的终端立即可用 adb")
                self.msg_queue.put(("done", (True, f"已添加到{scope}环境变量 Path")))
            self.qstep("完成", 1.0)
        except PermissionError:
            self.qlog("[错误] 权限不足，写入系统变量请以管理员身份运行")
            self.msg_queue.put(("done", (False, "权限不足，请右键以管理员身份运行")))
        except Exception as e:
            self.qlog(f"[错误] {e}")
            self.msg_queue.put(("done", (False, str(e))))

    def _install_worker(self, install_dir, system, zip_path):
        tmp_zip = None
        try:
            os.makedirs(install_dir, exist_ok=True)

            # 1. 获取 ZIP
            if zip_path:
                self.qstep("使用本地安装包…", 0.2)
                self.qlog(f"[步骤 1/4] 使用本地安装包：{zip_path}")
                tmp_zip = zip_path
            else:
                self.qstep("正在下载 Platform-Tools…", 0.05)
                self.qlog("[步骤 1/4] 下载 Platform-Tools（官方源，多镜像兜底）")
                tmp_zip = self._download()

            # 2. 解压
            self.qstep("正在解压…", 0.6)
            self.qlog(f"[步骤 2/4] 解压到 {install_dir}")
            self._extract(tmp_zip, install_dir)

            # 3. 环境变量
            self.qstep("正在配置环境变量…", 0.8)
            scope = "系统" if system else "用户"
            self.qlog(f"[步骤 3/4] 写入{scope} Path 环境变量")
            result = add_to_path(install_dir, system)
            if result == "already":
                self.qlog("[信息] 目录已存在于 Path，跳过")
            else:
                self.qlog(f"[成功] 已写入：{install_dir}")

            # 4. 验证
            self.qstep("正在验证…", 0.92)
            self.qlog("[步骤 4/4] 验证 adb 是否可用")
            adb_exe = os.path.join(install_dir, "adb.exe")
            code, out = run_silent([adb_exe, "version"])
            if code == 0 and "Android Debug Bridge" in out:
                ver = out.strip().splitlines()[0]
                self.qlog(f"[验证通过] {ver}")
                self.qlog("[完成] 请打开新的终端窗口，输入 adb version 验证")
                self.qstep("完成", 1.0)
                self.msg_queue.put(("done", (True, "ADB 环境部署完成，新终端中可直接使用 adb")))
            else:
                self.qlog(f"[警告] 验证输出异常：{out[:200]}")
                self.qstep("完成", 1.0)
                self.msg_queue.put(("done", (True, "文件已安装并配置环境变量，请在新终端中验证")))
        except PermissionError:
            self.qlog("[错误] 权限不足：写入系统变量或 C 盘目录需要管理员权限")
            self.msg_queue.put(("done", (False, "权限不足，请右键以管理员身份运行，或更换安装目录")))
        except Exception as e:
            self.qlog(f"[错误] {type(e).__name__}: {e}")
            self.msg_queue.put(("done", (False, str(e))))
        finally:
            if tmp_zip and not zip_path and tmp_zip.startswith(tempfile.gettempdir()):
                try:
                    os.remove(tmp_zip)
                except OSError:
                    pass

    def _download(self) -> str:
        last_err = None
        for url in DOWNLOAD_URLS:
            try:
                self.qlog(f"  → 尝试源：{url}")
                with requests.get(url, stream=True, timeout=(10, 300)) as r:
                    r.raise_for_status()
                    total = int(r.headers.get("Content-Length", 0))
                    tmp = os.path.join(tempfile.gettempdir(), "platform-tools-latest.zip")
                    done = 0
                    with open(tmp, "wb") as f:
                        for chunk in r.iter_content(chunk_size=256 * 1024):
                            if not chunk:
                                continue
                            f.write(chunk)
                            done += len(chunk)
                            if total:
                                frac = 0.05 + 0.5 * done / total
                                mb = done / 1024 / 1024
                                tmb = total / 1024 / 1024
                                self.qstep(f"正在下载 Platform-Tools… {mb:.1f}/{tmb:.1f} MB", frac)
                    self.qlog(f"  ✓ 下载完成（{done / 1024 / 1024:.1f} MB）")
                    return tmp
            except Exception as e:
                last_err = e
                self.qlog(f"  ✗ 该源不可用：{e}")
        raise RuntimeError(f"所有下载源均失败：{last_err}。可使用「选择 ZIP」离线安装。")

    def _extract(self, zip_file: str, install_dir: str):
        with zipfile.ZipFile(zip_file) as z:
            names = z.namelist()
            # 官方包内有一层 platform-tools/ 目录，直接解压到上级即可
            top = os.path.commonpath([n for n in names if n.strip("/")]) if names else ""
            target_parent = os.path.dirname(install_dir.rstrip("\\/")) or "C:\\"
            if top.replace("/", "\\").startswith("platform-tools"):
                # 若目标目录名就是 platform-tools，解压到其父目录
                if os.path.basename(install_dir.rstrip("\\/")).lower() == "platform-tools":
                    z.extractall(target_parent)
                else:
                    z.extractall(install_dir)
                    inner = os.path.join(install_dir, "platform-tools")
                    if os.path.isdir(inner):
                        for item in os.listdir(inner):
                            shutil.move(os.path.join(inner, item), install_dir)
                        os.rmdir(inner)
            else:
                z.extractall(install_dir)
        count = len(os.listdir(install_dir)) if os.path.isdir(install_dir) else 0
        self.qlog(f"  ✓ 解压完成（{count} 个文件/目录）")


def main():
    app = AdbSetupApp()
    app.mainloop()


if __name__ == "__main__":
    main()
