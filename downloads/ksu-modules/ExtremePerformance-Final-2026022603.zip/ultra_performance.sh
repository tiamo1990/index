#!/system/bin/sh

# ============================================
# 极致性能优化脚本 v16.0 (完全修复版)
# ============================================

# 设置环境变量
export PATH=/system/bin:/system/xbin:/sbin:$PATH

# 颜色定义（如果终端支持）
if [ -t 1 ]; then
    RED='\033[0;31m'
    GREEN='\033[0;32m'
    YELLOW='\033[1;33m'
    BLUE='\033[0;34m'
    CYAN='\033[0;36m'
    NC='\033[0m'
else
    RED=''; GREEN=''; YELLOW=''; BLUE=''; CYAN=''; NC=''
fi

# 配置文件路径
CONFIG_FILE="/data/local/tmp/ultra_perf.conf"
PID_FILE="/data/local/tmp/ultra_perf.pid"
LOG_FILE="/data/local/tmp/ultra_perf.log"

# 默认配置
PERF_MODE="balanced"
THERMAL_LIMIT=110000
GPU_BOOST="true"
IO_BOOST="true"
NET_BOOST="true"
GAME_MODE="false"

# ========== 日志函数 ==========

log() {
    local level="$1"
    local msg="$2"
    local timestamp=$(date "+%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] [$level] $msg" >> "$LOG_FILE"
}

ui_print() {
    echo -e "${GREEN}[INFO]${NC} $1"
    log "INFO" "$1"
}

ui_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
    log "WARN" "$1"
}

ui_error() {
    echo -e "${RED}[ERROR]${NC} $1"
    log "ERROR" "$1"
}

# ========== 配置文件加载 ==========

load_config() {
    if [ -f "$CONFIG_FILE" ]; then
        ui_print "加载配置文件: $CONFIG_FILE"
        
        # 安全地读取配置文件
        while IFS='=' read -r key value || [ -n "$key" ]; do
            # 跳过注释和空行
            case "$key" in
                ''|\#*) continue ;;
            esac
            
            # 去除首尾空格
            key=$(echo "$key" | xargs)
            value=$(echo "$value" | xargs | tr -d '"')
            
            case "$key" in
                "PERF_MODE") PERF_MODE="$value" ;;
                "THERMAL_LIMIT") 
                    if [ -n "$value" ] && [ "$value" -gt 0 ] 2>/dev/null; then
                        THERMAL_LIMIT=$((value * 1000))
                    fi
                    ;;
                "GPU_BOOST") GPU_BOOST="$value" ;;
                "IO_BOOST") IO_BOOST="$value" ;;
                "NET_BOOST") NET_BOOST="$value" ;;
                "GAME_MODE") GAME_MODE="$value" ;;
            esac
        done < "$CONFIG_FILE"
    else
        ui_warn "使用默认配置，创建配置文件"
        cat > "$CONFIG_FILE" << 'EOF'
# 极致性能配置文件
# 模式选择: ultra/balanced/powersave
PERF_MODE="balanced"

# 温控阈值 (单位: °C)
THERMAL_LIMIT=110

# 功能开关 (true/false)
GPU_BOOST="true"
IO_BOOST="true"
NET_BOOST="true"
GAME_MODE="false"
EOF
        chmod 644 "$CONFIG_FILE"
    fi
    
    ui_print "当前配置:"
    ui_print "  模式: $PERF_MODE"
    ui_print "  温控: $((THERMAL_LIMIT/1000))°C"
    ui_print "  GPU增强: $GPU_BOOST"
    ui_print "  I/O增强: $IO_BOOST"
    ui_print "  网络增强: $NET_BOOST"
    ui_print "  游戏模式: $GAME_MODE"
}

# ========== 文件操作安全函数 ==========

safe_write() {
    local file="$1"
    local value="$2"
    
    if [ ! -e "$file" ]; then
        ui_warn "文件不存在: $file"
        return 1
    fi
    
    if [ ! -w "$file" ]; then
        # 尝试临时修改权限
        local orig_perm=$(stat -c "%a" "$file" 2>/dev/null)
        chmod 644 "$file" 2>/dev/null
    fi
    
    if [ -w "$file" ]; then
        echo "$value" > "$file" 2>/dev/null
        local result=$?
        if [ $result -eq 0 ]; then
            return 0
        else
            ui_warn "写入失败: $file <- $value"
            return 1
        fi
    else
        ui_warn "文件不可写: $file"
        return 1
    fi
}

safe_read() {
    local file="$1"
    local default="$2"
    
    if [ -f "$file" ] && [ -r "$file" ]; then
        cat "$file" 2>/dev/null | head -n1
    else
        echo "$default"
    fi
}

# ========== CPU优化（完全修复） ==========

get_cpu_policies() {
    local policies=""
    for policy in /sys/devices/system/cpu/cpufreq/policy*; do
        if [ -d "$policy" ]; then
            policies="$policies $policy"
        fi
    done
    echo "$policies"
}

get_available_governors() {
    local policy="$1"
    local gov_file="$policy/scaling_available_governors"
    
    if [ -f "$gov_file" ]; then
        cat "$gov_file" 2>/dev/null
    fi
}

set_cpu_governor() {
    local policy="$1"
    local target_gov="$2"
    local gov_file="$policy/scaling_governor"
    
    if [ ! -f "$gov_file" ]; then
        return 1
    fi
    
    local avail_govs=$(get_available_governors "$policy")
    
    # 检查目标governor是否可用
    if echo "$avail_govs" | grep -q "$target_gov"; then
        safe_write "$gov_file" "$target_gov"
        return $?
    else
        # 尝试其他可用的governor
        for gov in "schedutil" "interactive" "ondemand" "conservative"; do
            if echo "$avail_govs" | grep -q "$gov"; then
                safe_write "$gov_file" "$gov"
                return $?
            fi
        done
        return 1
    fi
}

optimize_cpu_ultra() {
    ui_print "▶ CPU极致优化"
    
    # 1. 启用所有CPU核心
    for cpu_online in /sys/devices/system/cpu/cpu*/online; do
        if [ -f "$cpu_online" ]; then
            safe_write "$cpu_online" "1"
        fi
    done
    ui_print "  ✓ 所有CPU核心已激活"
    
    # 2. 设置performance governor
    local cpu_count=0
    for policy in $(get_cpu_policies); do
        if set_cpu_governor "$policy" "performance"; then
            cpu_count=$((cpu_count + 1))
        fi
    done
    ui_print "  ✓ 已设置 $cpu_count 个策略为 performance"
    
    # 3. 锁定CPU频率
    for policy in $(get_cpu_policies); do
        local max_freq_file="$policy/cpuinfo_max_freq"
        local min_freq_file="$policy/scaling_min_freq"
        local max_freq_target="$policy/scaling_max_freq"
        
        if [ -f "$max_freq_file" ]; then
            local max_freq=$(safe_read "$max_freq_file")
            if [ -n "$max_freq" ] && [ "$max_freq" -gt 0 ] 2>/dev/null; then
                safe_write "$min_freq_file" "$max_freq"
                safe_write "$max_freq_target" "$max_freq"
                ui_print "  ✓ $(basename $policy): 锁定频率 ${max_freq}KHz"
            fi
        fi
    done
    
    # 4. CPU输入升频优化
    for input_boost in /sys/module/cpu_boost/parameters/*; do
        case "$input_boost" in
            *input_boost_enabled)
                safe_write "$input_boost" "1"
                ;;
            *input_boost_freq)
                safe_write "$input_boost" "0:1248000"
                ;;
            *dynamic_stune_boost)
                safe_write "$input_boost" "50"
                ;;
        esac
    done
    
    # 5. 禁用CPU休眠
    for pm in /sys/module/lpm_levels/parameters/*; do
        case "$pm" in
            *sleep_disabled)
                safe_write "$pm" "Y"
                ;;
            *lpm_prediction)
                safe_write "$pm" "0"
                ;;
        esac
    done
    
    # 6. 设置schedutil参数（如果使用）
    for sched in /sys/devices/system/cpu/cpufreq/schedutil/*; do
        case "$sched" in
            *up_rate_limit_us)
                safe_write "$sched" "1000"
                ;;
            *down_rate_limit_us)
                safe_write "$sched" "2000"
                ;;
            *hispeed_load)
                safe_write "$sched" "80"
                ;;
            *hispeed_freq)
                if [ -f "$sched" ]; then
                    for policy in $(get_cpu_policies); do
                        if [ -f "$policy/cpuinfo_max_freq" ]; then
                            local max_freq=$(safe_read "$policy/cpuinfo_max_freq")
                            local hispeed=$((max_freq * 80 / 100))
                            safe_write "$sched" "$hispeed"
                            break
                        fi
                    done
                fi
                ;;
        esac
    done
    
    ui_print "  ✓ CPU优化完成"
}

optimize_cpu_balanced() {
    ui_print "▶ CPU均衡优化"
    
    local cpu_count=0
    for policy in $(get_cpu_policies); do
        # 尝试设置schedutil或interactive
        if set_cpu_governor "$policy" "schedutil"; then
            cpu_count=$((cpu_count + 1))
        elif set_cpu_governor "$policy" "interactive"; then
            cpu_count=$((cpu_count + 1))
        fi
    done
    ui_print "  ✓ 已设置 $cpu_count 个策略"
    
    # 设置合理的频率范围
    for policy in $(get_cpu_policies); do
        local min_freq_file="$policy/cpuinfo_min_freq"
        local max_freq_file="$policy/cpuinfo_max_freq"
        local scaling_min="$policy/scaling_min_freq"
        
        if [ -f "$min_freq_file" ] && [ -f "$max_freq_file" ]; then
            local min_freq=$(safe_read "$min_freq_file")
            local max_freq=$(safe_read "$max_freq_file")
            
            # 最低频率提升30%
            local enhanced_min=$((min_freq * 13 / 10))
            if [ "$enhanced_min" -lt "$max_freq" ]; then
                safe_write "$scaling_min" "$enhanced_min"
            fi
        fi
    done
}

optimize_cpu_powersave() {
    ui_print "▶ CPU省电优化"
    
    # 计算要禁用的核心数
    local total_cpus=$(cat /sys/devices/system/cpu/present | cut -d '-' -f 2)
    total_cpus=$((total_cpus + 1))
    local keep_cpus=$((total_cpus / 2))
    
    if [ "$keep_cpus" -lt 2 ]; then
        keep_cpus=2
    fi
    
    # 禁用部分核心
    local cpu=0
    for online in /sys/devices/system/cpu/cpu*/online; do
        if [ $cpu -ge $keep_cpus ]; then
            safe_write "$online" "0"
        else
            safe_write "$online" "1"
        fi
        cpu=$((cpu + 1))
    done
    ui_print "  ✓ 限制使用 $keep_cpus 个核心"
    
    # 设置powersave governor
    for policy in $(get_cpu_policies); do
        set_cpu_governor "$policy" "powersave"
    done
    
    # 降低最大频率
    for policy in $(get_cpu_policies); do
        local max_freq_file="$policy/cpuinfo_max_freq"
        local scaling_max="$policy/scaling_max_freq"
        
        if [ -f "$max_freq_file" ]; then
            local max_freq=$(safe_read "$max_freq_file")
            local reduced_freq=$((max_freq * 7 / 10))
            safe_write "$scaling_max" "$reduced_freq"
        fi
    done
}

# ========== GPU优化（完全修复） ==========

optimize_gpu() {
    if [ "$GPU_BOOST" != "true" ]; then
        return
    fi
    
    ui_print "▶ GPU增强"
    
    local gpu_optimized=0
    
    # Adreno GPU优化
    for gpu_path in /sys/class/kgsl/kgsl-3d0 /sys/devices/platform/kgsl-3d0.0/kgsl/kgsl-3d0; do
        if [ -d "$gpu_path" ]; then
            # GPU频率锁定
            if [ -f "$gpu_path/max_gpuclk" ]; then
                local max_gpu=$(safe_read "$gpu_path/max_gpuclk")
                if [ -n "$max_gpu" ] && [ "$max_gpu" -gt 0 ]; then
                    safe_write "$gpu_path/min_gpuclk" "$max_gpu"
                    local mhz=$((max_gpu / 1000000))
                    ui_print "  ✓ GPU频率锁定: ${mhz}MHz"
                    gpu_optimized=$((gpu_optimized + 1))
                fi
            fi
            
            # GPU电源策略
            for policy_file in "$gpu_path/power_policy" "$gpu_path/devfreq/governor"; do
                if [ -f "$policy_file" ]; then
                    safe_write "$policy_file" "performance"
                fi
            done
            
            # 禁用GPU节流
            for throttle in "$gpu_path/throttling" "$gpu_path/force_no_nap" "$gpu_path/bus_split"; do
                if [ -f "$throttle" ]; then
                    case "$throttle" in
                        *throttling) safe_write "$throttle" "0" ;;
                        *force_no_nap) safe_write "$throttle" "1" ;;
                        *bus_split) safe_write "$throttle" "0" ;;
                    esac
                fi
            done
        fi
    done
    
    # Mali GPU优化
    for mali_path in /sys/class/misc/mali*/device /sys/devices/platform/mali*/devfreq; do
        if [ -d "$mali_path" ]; then
            if [ -f "$mali_path/governor" ]; then
                safe_write "$mali_path/governor" "performance"
                gpu_optimized=$((gpu_optimized + 1))
            fi
        fi
    done
    
    if [ $gpu_optimized -eq 0 ]; then
        ui_warn "  ! 未找到GPU优化接口"
    fi
}

# ========== 内存控制器优化 ==========

optimize_memory() {
    ui_print "▶ 内存控制器优化"
    
    local mem_optimized=0
    
    # DDR/MIF优化
    for ddr_path in /sys/class/devfreq/* /sys/kernel/mem_policy/*; do
        local name=$(basename "$ddr_path" 2>/dev/null)
        case "$name" in
            *ddr*|*mif*|*mem*|*emory*)
                if [ -f "$ddr_path/governor" ]; then
                    safe_write "$ddr_path/governor" "performance"
                    mem_optimized=$((mem_optimized + 1))
                fi
                
                # 锁定频率
                if [ -f "$ddr_path/max_freq" ] && [ -f "$ddr_path/min_freq" ]; then
                    local max_ddr=$(safe_read "$ddr_path/max_freq")
                    if [ -n "$max_ddr" ] && [ "$max_ddr" -gt 0 ]; then
                        safe_write "$ddr_path/min_freq" "$max_ddr"
                    fi
                fi
                ;;
        esac
    done
    
    if [ $mem_optimized -gt 0 ]; then
        ui_print "  ✓ 已优化 $mem_optimized 个内存控制器"
    fi
    
    # VM优化（仅ultra模式）
    if [ "$PERF_MODE" = "ultra" ]; then
        safe_write "/proc/sys/vm/swappiness" "10"
        safe_write "/proc/sys/vm/dirty_ratio" "20"
        safe_write "/proc/sys/vm/dirty_background_ratio" "5"
        safe_write "/proc/sys/vm/vfs_cache_pressure" "50"
        safe_write "/proc/sys/vm/min_free_kbytes" "8192"
        safe_write "/proc/sys/vm/extra_free_kbytes" "108134"
        ui_print "  ✓ 虚拟内存参数已优化"
    fi
}

# ========== 温控策略优化 ==========

optimize_thermal() {
    ui_print "▶ 温控策略优化"
    
    local thermal_modified=0
    local thermal_threshold=$((THERMAL_LIMIT))
    
    # 遍历所有温控区域
    for thermal_zone in /sys/class/thermal/thermal_zone*; do
        if [ -d "$thermal_zone" ] && [ -f "$thermal_zone/type" ]; then
            local type=$(safe_read "$thermal_zone/type")
            
            # 查找所有温控点
            for trip_point in "$thermal_zone"/trip_point_*_temp; do
                if [ -f "$trip_point" ]; then
                    local current_temp=$(safe_read "$trip_point")
                    
                    # 检查是否是数值
                    if [ -n "$current_temp" ] && [ "$current_temp" -gt 0 ] 2>/dev/null; then
                        # 如果是CPU/GPU相关的温控点，提高阈值
                        if echo "$type" | grep -E "cpu|gpu|ddr|cluster" >/dev/null; then
                            if [ "$current_temp" -lt "$thermal_threshold" ]; then
                                safe_write "$trip_point" "$thermal_threshold"
                                thermal_modified=$((thermal_modified + 1))
                            fi
                        fi
                    fi
                fi
            done
        fi
    done
    
    if [ $thermal_modified -gt 0 ]; then
        ui_print "  ✓ 已调整 $thermal_modified 个温控点"
    fi
    
    # 禁用特定温控（仅ultra模式）
    if [ "$PERF_MODE" = "ultra" ]; then
        for thermal_control in \
            /sys/module/msm_thermal/parameters/enabled \
            /sys/module/msm_thermal/core_control/enabled \
            /sys/module/thermal/parameters/enabled; do
            if [ -f "$thermal_control" ]; then
                safe_write "$thermal_control" "N"
            fi
        done
    fi
}

# ========== I/O调度优化 ==========

optimize_io() {
    if [ "$IO_BOOST" != "true" ]; then
        return
    fi
    
    ui_print "▶ I/O调度优化"
    
    local block_optimized=0
    
    for block in /sys/block/*/queue; do
        if [ -d "$block" ]; then
            local scheduler_file="$block/scheduler"
            
            # 设置I/O调度器
            if [ -f "$scheduler_file" ]; then
                local schedulers=$(cat "$scheduler_file" 2>/dev/null)
                
                # 按优先级选择调度器
                if echo "$schedulers" | grep -q "kyber"; then
                    safe_write "$scheduler_file" "kyber"
                    block_optimized=$((block_optimized + 1))
                elif echo "$schedulers" | grep -q "mq-deadline"; then
                    safe_write "$scheduler_file" "mq-deadline"
                    block_optimized=$((block_optimized + 1))
                elif echo "$schedulers" | grep -q "noop"; then
                    safe_write "$scheduler_file" "noop"
                    block_optimized=$((block_optimized + 1))
                fi
            fi
            
            # 优化I/O参数
            safe_write "$block/read_ahead_kb" "512"
            safe_write "$block/nr_requests" "256"
            safe_write "$block/iostats" "0"
            safe_write "$block/add_random" "0"
            safe_write "$block/nomerges" "2"
            safe_write "$block/rq_affinity" "2"
        fi
    done
    
    if [ $block_optimized -gt 0 ]; then
        ui_print "  ✓ 已优化 $block_optimized 个块设备"
    fi
}

# ========== 网络优化 ==========

optimize_network() {
    if [ "$NET_BOOST" != "true" ]; then
        return
    fi
    
    ui_print "▶ 网络优化"
    
    # TCP拥塞控制
    if [ -f /proc/sys/net/ipv4/tcp_congestion_control ]; then
        local avail_cc=$(cat /proc/sys/net/ipv4/tcp_available_congestion_control 2>/dev/null)
        
        if echo "$avail_cc" | grep -q "bbr"; then
            safe_write "/proc/sys/net/ipv4/tcp_congestion_control" "bbr"
            ui_print "  ✓ TCP BBR 启用"
        elif echo "$avail_cc" | grep -q "cubic"; then
            safe_write "/proc/sys/net/ipv4/tcp_congestion_control" "cubic"
            ui_print "  ✓ TCP Cubic 启用"
        fi
    fi
    
    # 网络缓冲区优化
    safe_write "/proc/sys/net/core/rmem_max" "16777216"
    safe_write "/proc/sys/net/core/wmem_max" "16777216"
    safe_write "/proc/sys/net/core/rmem_default" "87380"
    safe_write "/proc/sys/net/core/wmem_default" "87380"
    
    # TCP缓冲区优化
    safe_write "/proc/sys/net/ipv4/tcp_rmem" "4096 87380 16777216"
    safe_write "/proc/sys/net/ipv4/tcp_wmem" "4096 65536 16777216"
    
    # 网络参数优化
    safe_write "/proc/sys/net/ipv4/tcp_slow_start_after_idle" "0"
    safe_write "/proc/sys/net/ipv4/tcp_no_metrics_save" "1"
    safe_write "/proc/sys/net/ipv4/tcp_moderate_rcvbuf" "1"
    safe_write "/proc/sys/net/ipv4/tcp_tw_reuse" "1"
    safe_write "/proc/sys/net/ipv4/tcp_fastopen" "3"
    
    ui_print "  ✓ 网络参数已优化"
}

# ========== 游戏模式优化 ==========

optimize_game_mode() {
    if [ "$GAME_MODE" != "true" ] && [ "$PERF_MODE" != "ultra" ]; then
        return
    fi
    
    ui_print "▶ 游戏模式优化"
    
    # 输入响应优化
    local input_optimized=0
    for input in /sys/class/input/input*/; do
        if [ -f "${input}enable" ]; then
            safe_write "${input}enable" "1"
            input_optimized=$((input_optimized + 1))
        fi
    done
    
    if [ $input_optimized -gt 0 ]; then
        ui_print "  ✓ 输入响应优化完成"
    fi
    
    # 触控采样率提升
    for touch in \
        /sys/class/touch/touch*/sample_rate \
        /sys/devices/virtual/input/input*/sample_rate \
        /sys/module/msm_performance/parameters/touchboost; do
        if [ -f "$touch" ]; then
            case "$touch" in
                *sample_rate) safe_write "$touch" "240" ;;
                *touchboost) safe_write "$touch" "1" ;;
            esac
        fi
    done
    
    # 游戏优化专用接口
    for game_opt in \
        /proc/game_opt/disable_cpufreq_limit \
        /sys/module/perf_ctl/parameters/game_mode \
        /sys/module/game_opt/parameters/game_mode; do
        if [ -f "$game_opt" ]; then
            safe_write "$game_opt" "1"
        fi
    done
    
    # MIUI游戏工具箱优化
    if [ -n "$(getprop ro.miui.ui.version.code)" ]; then
        settings put system speed_mode_enable 1 2>/dev/null
        settings put secure speed_mode_enable 1 2>/dev/null
    fi
    
    ui_print "  ✓ 游戏优化完成"
}

# ========== 系统参数优化 ==========

optimize_system() {
    ui_print "▶ 系统参数优化"
    
    # LMKD优化
    setprop ro.lmk.kill_heaviest_task true 2>/dev/null
    setprop ro.lmk.kill_timeout_ms 100 2>/dev/null
    setprop ro.lmk.use_minfree_levels true 2>/dev/null
    
    # 熵池优化
    safe_write "/proc/sys/kernel/random/read_wakeup_threshold" "512"
    safe_write "/proc/sys/kernel/random/write_wakeup_threshold" "1024"
    
    # 调度器优化
    safe_write "/proc/sys/kernel/sched_child_runs_first" "1"
    safe_write "/proc/sys/kernel/sched_autogroup_enabled" "0"
    safe_write "/proc/sys/kernel/sched_tunable_scaling" "1"
    
    # CFS调度器优化
    safe_write "/proc/sys/kernel/sched_latency_ns" "10000000"
    safe_write "/proc/sys/kernel/sched_min_granularity_ns" "2000000"
    safe_write "/proc/sys/kernel/sched_wakeup_granularity_ns" "3000000"
    
    ui_print "  ✓ 系统参数已优化"
}

# ========== 状态监控服务 ==========

start_monitor_service() {
    ui_print "▶ 启动监控服务"
    
    # 停止旧服务
    if [ -f "$PID_FILE" ]; then
        local old_pid=$(cat "$PID_FILE" 2>/dev/null)
        if [ -n "$old_pid" ] && kill -0 "$old_pid" 2>/dev/null; then
            kill "$old_pid" 2>/dev/null
            sleep 1
        fi
        rm -f "$PID_FILE"
    fi
    
    # 启动新服务
    (
        # 记录PID
        echo $$ > "$PID_FILE"
        
        # 记录启动时间
        log "INFO" "监控服务已启动 (PID: $$)"
        
        # 主循环
        while true; do
            sleep 30
            
            # 重新加载配置
            if [ -f "$CONFIG_FILE" ]; then
                while IFS='=' read -r key value || [ -n "$key" ]; do
                    case "$key" in
                        ''|\#*) continue ;;
                    esac
                    key=$(echo "$key" | xargs)
                    value=$(echo "$value" | xargs | tr -d '"')
                    
                    case "$key" in
                        "PERF_MODE") CURRENT_MODE="$value" ;;
                        "THERMAL_LIMIT") 
                            if [ -n "$value" ] && [ "$value" -gt 0 ] 2>/dev/null; then
                                CURRENT_THERMAL=$((value * 1000))
                            fi
                            ;;
                    esac
                done < "$CONFIG_FILE"
            fi
            
            # 检查CPU governor
            for policy in $(get_cpu_policies); do
                local gov_file="$policy/scaling_governor"
                if [ -f "$gov_file" ]; then
                    local current_gov=$(cat "$gov_file" 2>/dev/null)
                    
                    if [ "$CURRENT_MODE" = "ultra" ] && [ "$current_gov" != "performance" ]; then
                        log "INFO" "重新应用CPU优化"
                        set_cpu_governor "$policy" "performance"
                    elif [ "$CURRENT_MODE" = "balanced" ] && [ "$current_gov" != "schedutil" ] && [ "$current_gov" != "interactive" ]; then
                        set_cpu_governor "$policy" "schedutil" || set_cpu_governor "$policy" "interactive"
                    fi
                fi
            done
            
            # 温度监控
            for thermal in /sys/class/thermal/thermal_zone*/temp; do
                if [ -f "$thermal" ]; then
                    local temp=$(cat "$thermal" 2>/dev/null)
                    if [ -n "$temp" ] && [ "$temp" -gt "$CURRENT_THERMAL" ] 2>/dev/null; then
                        log "WARN" "温度过高: $((temp/1000))°C"
                        
                        # 温度过高时临时降频
                        if [ "$temp" -gt "$((CURRENT_THERMAL + 10000))" ]; then
                            for policy in $(get_cpu_policies); do
                                local max_freq_file="$policy/cpuinfo_max_freq"
                                local scaling_max="$policy/scaling_max_freq"
                                
                                if [ -f "$max_freq_file" ]; then
                                    local max_freq=$(cat "$max_freq_file" 2>/dev/null)
                                    local reduced=$((max_freq * 8 / 10))
                                    echo "$reduced" > "$scaling_max" 2>/dev/null
                                fi
                            done
                            log "WARN" "已临时降频20%"
                        fi
                    fi
                fi
            done
        done
    ) &
    
    local new_pid=$!
    ui_print "  ✓ 监控服务已启动 (PID: $new_pid)"
}

# ========== 状态显示 ==========

show_status() {
    echo "========================================"
    echo "    极致性能 - 系统状态"
    echo "========================================"
    
    # CPU信息
    echo -e "\n${CYAN}CPU 信息:${NC}"
    for policy in $(get_cpu_policies); do
        if [ -d "$policy" ]; then
            local gov=$(safe_read "$policy/scaling_governor" "unknown")
            local min=$(safe_read "$policy/scaling_min_freq" "0")
            local max=$(safe_read "$policy/scaling_max_freq" "0")
            local cur=$(safe_read "$policy/scaling_cur_freq" "0")
            
            if [ "$min" -gt 0 ] 2>/dev/null; then
                echo "  $(basename $policy): $gov | ${min}KHz ~ ${max}KHz | 当前: ${cur}KHz"
            fi
        fi
    done
    
    # 核心在线状态
    echo -e "\n${CYAN}CPU 核心状态:${NC}"
    local cpu=0
    for online in /sys/devices/system/cpu/cpu*/online; do
        if [ -f "$online" ]; then
            local status=$(safe_read "$online")
            if [ "$status" = "1" ]; then
                echo "  CPU$cpu: 在线"
            else
                echo "  CPU$cpu: 离线"
            fi
        fi
        cpu=$((cpu + 1))
    done
    
    # GPU信息
    echo -e "\n${CYAN}GPU 信息:${NC}"
    for gpu in /sys/class/kgsl/kgsl-3d0 /sys/class/kgsl/kgsl-3d1; do
        if [ -d "$gpu" ]; then
            local max_gpu=$(safe_read "$gpu/max_gpuclk" "0")
            local cur_gpu=$(safe_read "$gpu/gpuclk" "0")
            
            if [ "$max_gpu" -gt 0 ] 2>/dev/null; then
                local max_mhz=$((max_gpu / 1000000))
                local cur_mhz=$((cur_gpu / 1000000))
                echo "  GPU频率: ${cur_mhz}MHz / ${max_mhz}MHz"
            fi
        fi
    done
    
    # 温度信息
    echo -e "\n${CYAN}温度信息:${NC}"
    for thermal in /sys/class/thermal/thermal_zone*/temp; do
        if [ -f "$thermal" ]; then
            local temp=$(safe_read "$thermal")
            if [ "$temp" -gt 0 ] 2>/dev/null; then
                local zone=$(dirname "$thermal")/type
                local type=$(safe_read "$zone" "unknown")
                echo "  $type: $((temp/1000))°C"
            fi
        fi
    done
    
    # 内存信息
    echo -e "\n${CYAN}内存信息:${NC}"
    local mem_total=$(cat /proc/meminfo | grep "MemTotal" | awk '{print $2}')
    local mem_free=$(cat /proc/meminfo | grep "MemFree" | awk '{print $2}')
    local mem_avail=$(cat /proc/meminfo | grep "MemAvailable" | awk '{print $2}')
    
    if [ -n "$mem_total" ]; then
        echo "  总计: $((mem_total/1024)) MB"
        echo "  可用: $((mem_avail/1024)) MB"
        echo "  空闲: $((mem_free/1024)) MB"
    fi
    
    # 监控服务状态
    echo -e "\n${CYAN}监控服务:${NC}"
    if [ -f "$PID_FILE" ]; then
        local pid=$(cat "$PID_FILE" 2>/dev/null)
        if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
            echo "  ✓ 运行中 (PID: $pid)"
        else
            echo "  ✗ 已停止"
            rm -f "$PID_FILE"
        fi
    else
        echo "  ✗ 未运行"
    fi
    
    echo ""
}

# ========== 清理函数 ==========

cleanup() {
    ui_print "清理资源..."
    
    # 停止监控服务
    if [ -f "$PID_FILE" ]; then
        local pid=$(cat "$PID_FILE" 2>/dev/null)
        if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
            kill "$pid" 2>/dev/null
            ui_print "监控服务已停止"
        fi
        rm -f "$PID_FILE"
    fi
    
    # 保存最后运行的配置
    echo "$PERF_MODE" > /data/local/tmp/ultra_perf_last 2>/dev/null
    
    ui_print "清理完成"
}

# ========== 主函数 ==========

main() {
    echo "========================================"
    echo "    🔥 极致性能优化 v16.0 🔥"
    echo "========================================"
    echo ""
    
    # 检查root权限
    if [ "$(id -u)" != "0" ]; then
        ui_error "需要root权限"
        exit 1
    fi
    
    # 加载配置
    load_config
    
    # 根据模式执行优化
    echo ""
    case "$PERF_MODE" in
        "ultra")
            ui_print "激活极致性能模式"
            echo "----------------------------------------"
            optimize_cpu_ultra
            optimize_gpu
            optimize_memory
            optimize_thermal
            optimize_io
            optimize_network
            optimize_game_mode
            optimize_system
            ;;
        "balanced")
            ui_print "激活均衡模式"
            echo "----------------------------------------"
            optimize_cpu_balanced
            optimize_gpu
            optimize_memory
            optimize_thermal
            optimize_io
            optimize_network
            optimize_system
            ;;
        "powersave")
            ui_print "激活省电模式"
            echo "----------------------------------------"
            optimize_cpu_powersave
            optimize_io
            ;;
        *)
            ui_error "未知模式: $PERF_MODE"
            exit 1
            ;;
    esac
    
    # 启动监控
    echo ""
    start_monitor_service
    
    # 显示状态
    echo ""
    show_status
    
    echo ""
    echo "========================================"
    echo "    ✨ 优化完成 ✨"
    echo "========================================"
    echo ""
    echo "配置文件: $CONFIG_FILE"
    echo "日志文件: $LOG_FILE"
    echo ""
    echo "命令:"
    echo "  su -c ultra_performance status   - 查看状态"
    echo "  su -c ultra_performance stop     - 停止监控"
    echo "  su -c ultra_performance ultra    - 切换极致模式"
    echo "  su -c ultra_performance balanced - 切换均衡模式"
    echo "  su -c ultra_performance powersave - 切换省电模式"
    echo ""
}

# ========== 信号处理 ==========

trap cleanup EXIT INT TERM

# ========== 命令行参数处理 ==========

case "$1" in
    "status")
        show_status
        ;;
    "stop")
        cleanup
        ;;
    "ultra")
        PERF_MODE="ultra"
        main
        ;;
    "balanced")
        PERF_MODE="balanced"
        main
        ;;
    "powersave")
        PERF_MODE="powersave"
        main
        ;;
    "")
        main
        ;;
    *)
        echo "使用方法: $0 [status|stop|ultra|balanced|powersave]"
        exit 1
        ;;
esac

exit 0