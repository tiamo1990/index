#!/system/bin/sh

# 极致性能模块安装脚本

# Magisk模块路径
MODPATH=${0%/*}

# 输出函数
ui_print() {
    echo "$1"
}

# 检查Magisk版本
ui_print "****************************************"
ui_print "    🔥 极致性能·最终版 安装程序 🔥    "
ui_print "****************************************"
ui_print "- Magisk版本: $MAGISK_VERSION_CODE"

if [ "$MAGISK_VERSION_CODE" -lt 20400 ]; then
    ui_print "! 需要Magisk v20.4+ (20400+)"
    abort
fi

# 检查设备兼容性
ui_print "- 设备信息:"
ui_print "  ARCH: $ARCH"
ui_print "  API: $API"
ui_print "  ABI: $ABI"

# 检查必要文件（非阻塞）
ui_print "- 检查系统兼容性..."
MISSING_FILES=""
for file in /sys/class/power_supply/battery/status /sys/devices/system/cpu/online; do
    if [ ! -e "$file" ]; then
        MISSING_FILES="$MISSING_FILES $file"
    fi
done

if [ -n "$MISSING_FILES" ]; then
    ui_print "! 警告: 以下文件不存在: $MISSING_FILES"
    ui_print "! 模块可能不兼容，但仍可尝试安装"
fi

# 复制二进制文件
ui_print "- 安装二进制文件..."
BIN_COPIED=0

if [ "$ARCH" = "arm" ] || [ "$ARCH" = "arm64" ]; then
    if [ -d "$MODPATH/bin/armeabi-v7a" ]; then
        cp -rf "$MODPATH/bin/armeabi-v7a"/* "$MODPATH/" 2>/dev/null
        BIN_COPIED=1
    fi
fi

if [ "$ARCH" = "arm64" ] && [ -d "$MODPATH/bin/arm64-v8a" ]; then
    cp -rf "$MODPATH/bin/arm64-v8a"/* "$MODPATH/" 2>/dev/null
    BIN_COPIED=1
fi

if [ "$ARCH" = "x86" ] && [ -d "$MODPATH/bin/x86" ]; then
    cp -rf "$MODPATH/bin/x86"/* "$MODPATH/" 2>/dev/null
    BIN_COPIED=1
fi

if [ "$ARCH" = "x64" ] && [ -d "$MODPATH/bin/x86_64" ]; then
    cp -rf "$MODPATH/bin/x86_64"/* "$MODPATH/" 2>/dev/null
    BIN_COPIED=1
fi

# 清理二进制目录
rm -rf "$MODPATH/bin"

if [ $BIN_COPIED -eq 0 ]; then
    ui_print "! 未找到适合的二进制文件"
    ui_print "! 将使用脚本模式运行"
fi

# 设置权限
ui_print "- 设置权限..."

# 递归设置权限
find "$MODPATH" -type d -exec chmod 755 {} \;
find "$MODPATH" -type f -exec chmod 644 {} \;

# 设置可执行文件权限
if [ -f "$MODPATH/ultra_performance.sh" ]; then
    chmod 755 "$MODPATH/ultra_performance.sh"
    ui_print "  ✓ ultra_performance.sh"
fi

if [ -f "$MODPATH/service.sh" ]; then
    chmod 755 "$MODPATH/service.sh"
    ui_print "  ✓ service.sh"
fi

if [ -f "$MODPATH/uninstall.sh" ]; then
    chmod 755 "$MODPATH/uninstall.sh"
    ui_print "  ✓ uninstall.sh"
fi

# 创建配置文件（如果不存在）
if [ ! -f "/data/local/tmp/ultra_perf.conf" ]; then
    ui_print "- 创建配置文件..."
    mkdir -p /data/local/tmp
    cat > "/data/local/tmp/ultra_perf.conf" << 'EOF'
# 极致性能配置文件
# 模式选择: ultra/balanced/powersave
PERF_MODE="balanced"

# 温控阈值 (单位: °C)
THERMAL_LIMIT=110

# 功能开关 (true/false)
GPU_BOOST="true"
IO_BOOST="true"
NET_BOOST="true"
GAME_MODE="false"
EOF
    chmod 644 "/data/local/tmp/ultra_perf.conf"
    ui_print "  ✓ /data/local/tmp/ultra_perf.conf"
fi

# 创建日志目录
touch "/data/local/tmp/ultra_perf.log" 2>/dev/null
chmod 644 "/data/local/tmp/ultra_perf.log" 2>/dev/null

# 安装完成
ui_print "****************************************"
ui_print "    ✅ 安装成功！"
ui_print "****************************************"
ui_print ""
ui_print "📱 使用方法:"
ui_print "   su -c ultra_performance.sh        # 应用优化"
ui_print "   su -c ultra_performance.sh status # 查看状态"
ui_print "   su -c ultra_performance.sh stop   # 停止监控"
ui_print ""
ui_print "⚙️ 配置文件:"
ui_print "   /data/local/tmp/ultra_perf.conf"
ui_print ""
ui_print "📝 日志文件:"
ui_print "   /data/local/tmp/ultra_perf.log"
ui_print ""
ui_print "🔥 重启手机后生效"
ui_print "****************************************"