#!/system/bin/sh

# 极致性能开机自启服务
# 等待系统完全启动

# 日志函数
log() {
    echo "[$(date "+%Y-%m-%d %H:%M:%S")] $1" >> /data/local/tmp/ultra_perf_service.log
}

log "开机自启服务启动"

# 等待系统启动完成
BOOT_WAIT=0
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 5
    BOOT_WAIT=$((BOOT_WAIT + 5))
    if [ $BOOT_WAIT -gt 120 ]; then
        log "等待系统启动超时"
        break
    fi
done

log "系统启动完成，等待额外时间..."

# 等待额外时间确保服务就绪
sleep 30

# 检查模块是否启用
if [ ! -f "/data/adb/modules/ultra_performance_final/disable" ]; then
    log "模块已启用，应用优化"
    
    # 检查脚本是否存在
    SCRIPT_PATH="/data/adb/modules/ultra_performance_final/ultra_performance.sh"
    if [ -f "$SCRIPT_PATH" ]; then
        # 读取配置
        if [ -f "/data/local/tmp/ultra_perf.conf" ]; then
            # 提取模式
            PERF_MODE=$(grep "^PERF_MODE" /data/local/tmp/ultra_perf.conf | cut -d'=' -f2 | tr -d ' "')
            if [ -z "$PERF_MODE" ]; then
                PERF_MODE="balanced"
            fi
            
            log "应用模式: $PERF_MODE"
            
            # 应用优化（后台运行）
            sh "$SCRIPT_PATH" "$PERF_MODE" > /dev/null 2>&1 &
            log "优化已应用"
        else
            log "配置文件不存在，使用默认配置"
            sh "$SCRIPT_PATH" "balanced" > /dev/null 2>&1 &
        fi
    else
        log "错误: 脚本不存在"
    fi
else
    log "模块已禁用，跳过"
fi

log "开机自启服务完成"

exit 0