#!/system/bin/sh

# 卸载脚本
echo "========================================"
echo "    极致性能模块 - 卸载程序"
echo "========================================"

# 停止监控服务
if [ -f "/data/local/tmp/ultra_perf.pid" ]; then
    PID=$(cat "/data/local/tmp/ultra_perf.pid" 2>/dev/null)
    if [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null; then
        echo "- 停止监控服务 (PID: $PID)"
        kill "$PID" 2>/dev/null
        sleep 1
    fi
    rm -f "/data/local/tmp/ultra_perf.pid"
fi

# 询问是否删除配置文件
if [ -f "/data/local/tmp/ultra_perf.conf" ]; then
    echo ""
    echo "是否删除配置文件? (y/n)"
    read -r ANSWER
    case "$ANSWER" in
        y|Y)
            rm -f "/data/local/tmp/ultra_perf.conf"
            echo "- 配置文件已删除"
            ;;
        *)
            echo "- 配置文件已保留: /data/local/tmp/ultra_perf.conf"
            ;;
    esac
fi

# 询问是否删除日志
if [ -f "/data/local/tmp/ultra_perf.log" ]; then
    echo ""
    echo "是否删除日志文件? (y/n)"
    read -r ANSWER
    case "$ANSWER" in
        y|Y)
            rm -f "/data/local/tmp/ultra_perf.log"
            echo "- 日志文件已删除"
            ;;
        *)
            echo "- 日志文件已保留: /data/local/tmp/ultra_perf.log"
            ;;
    esac
fi

# 删除服务日志
rm -f "/data/local/tmp/ultra_perf_service.log" 2>/dev/null

echo ""
echo "========================================"
echo "    卸载完成，重启后生效"
echo "========================================"

exit 0