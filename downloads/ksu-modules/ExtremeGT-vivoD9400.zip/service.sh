# Avoid system failure to start
sleep 60

# charge turbo
echo 1 > /sys/class/cms_class/scene_disable
# echo 1 > /sys/class/cms_class/freq_test
# It could get too hot and destroy the equipment
# echo 0 > /sys/class/cms_class/cms_enable
echo 1 > /sys/class/cms_class/switch_state
chmod 444 /sys/class/cms_class/switch_state

# disable throttling
stop thermal_core
stop thermald
# stop vendor.thermal-mediatek # 会导致玩不了原神？d'n'm'd！
for tz in `ls /sys/class/thermal | grep thermal_zone`
do
  if [[ -f /sys/class/thermal/$tz/type ]]; then
    case $(cat /sys/class/thermal/$tz/type) in
    *"shell"*|*"skin"*|"vir_"*)
      echo -n "$tz: " ; cat  /sys/class/thermal/$tz/type
      echo 27000 > /sys/class/thermal/$tz/emul_temp
    ;;
    esac
  fi
done

# Disable system performance adjustment
echo 0 > /proc/powerhal_cpu_ctrl/adpf_enable
echo 0 > /sys/rsc/svp/svp_enable
echo 0 > /sys/rsc/svp/enabled
stop vivo-vperf-hal-1-0
stop vendor.vivoperfservice
stop touch_boost

# Emulated Temperature
for tz in /sys/class/thermal/thermal_zone*; do
  if [[ -f $tz/type ]]; then
    case $(cat $tz/type) in
    *"shell"*|*"skin"*|"vir"*|*"wifi"*|*"ntc"*)
      echo 32000 > $tz/emul_temp
    ;;
    esac
  fi
done
