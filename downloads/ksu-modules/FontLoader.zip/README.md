# FontLoader

Modifying fonts is a common scenario using the Magisk module. For example, fonts for CJK languages in the Android system only have one font-weight, users can use the Magisk module to modify font files to add the remaining font weights.

However, starting from Android 12, fonts are loaded only when the app needs to render the font. Before, fonts are preloaded in the zygote process. When users revert the change of Magisk (with MagiskHide before or DenyList nowadays), apps will not be able to access font files from modules and finally result in a crash.

This module is a Zygisk module that is designed to solve the problem. The principle is simple, preload the font when the app has not yet lost access to the font.

## Something else

* Why not using the font upgrade feature from Android 12?

  The font upgrade feature cannot set the default font-weight and language. Therefore it can only be used to upgrade/add a font with a single font-weight like emoji font. This is exactly how it is used in the documentation.

  Also, the font upgrade feature requires signing font files. It is impossible to add our key without modifying Magisk.

## Difference between this module and RikkaW/FontLoader

This module is based on original FontLoader, with improvements as below:

1. Respect more font paths such as /product/fonts
2. Use ashmem fd rather than memory remapping to hide font in maps
3. Fix memory leaks of original modules and general code improvements
