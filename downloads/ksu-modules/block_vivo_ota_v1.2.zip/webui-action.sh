#!/system/bin/sh

MODDIR=${MODDIR:-"$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"}

# shellcheck source=lib/vivo_state.sh
. "$MODDIR/lib/vivo_state.sh" || exit 1
initialize_config_backend || exit 1

reject() {
  printf '%s\n' 'Invalid WebUI action' >&2
  exit 1
}

if [ "$#" -eq 1 ] && [ "$1" = status ]; then
  reconcile_device_state || exit 1
  emit_status
  exit 0
fi

[ "$#" -eq 3 ] || reject
[ "$1" = set ] || reject

case "$2:$3" in
  ota:0|ota:1|space:0|space:1|device:0|device:1) ;;
  *) reject ;;
esac

reconcile_device_state || exit 1

case "$2:$3" in
  ota:0|ota:1)
    config_set ota_enabled "$3" || exit 1
    ;;
  space:0|space:1)
    config_set space_enabled "$3" || exit 1
    ;;
  device:0|device:1)
    [ "$(config_get device_ui_locked)" = 0 ] || reject
    [ "$(detect_device_status)" = abnormal ] || reject
    config_set device_enabled "$3" || exit 1
    ;;
esac

render_system_prop || exit 1
refresh_description || exit 1
emit_status
