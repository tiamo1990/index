#!/system/bin/sh

VIVO_MODULE_ID=block_vivo_ota
VIVO_BACKEND_PREFERENCE_FILE=.config-backend

sanitize_single_line() {
  printf '%s' "$1" | tr '\r\n' '  ' | tr -s ' ' | sed 's/^ *//;s/ *$//'
}

transform_ota_version() {
  version=$(sanitize_single_line "$1")
  transformed=$(printf '%s\n' "$version" | sed -n 's/^\([0-9][0-9]*\.[0-9][0-9]*\.[0-9][0-9]*\)\(\..*\)\{0,1\}$/\1.999/p')
  [ -n "$transformed" ] || return 1
  printf '%s' "$transformed"
}

preserve_real_version() {
  version=$(sanitize_single_line "$1")
  [ -n "$version" ] || return 1
  temp_file=$MODDIR/.real-version.tmp.$$
  printf '%s\n' "$version" > "$temp_file" || return 1
  mv "$temp_file" "$MODDIR/real-version"
}

get_real_version() {
  if [ -f "$MODDIR/real-version" ]; then
    version=$(sed -n '1p' "$MODDIR/real-version")
    version=$(sanitize_single_line "$version")
    [ -n "$version" ] && {
      printf '%s' "$version"
      return
    }
  fi
  _vivo_get_first_prop ro.vivo.product.version.incremental ro.build.version.incremental
}

_vivo_installed_module_dir() {
  printf '%s' "${VIVO_INSTALLED_MODULE_DIR:-/data/adb/modules/$VIVO_MODULE_ID}"
}

_vivo_read_trusted_real_version() {
  _vivo_real_version_file=$1
  [ -f "$_vivo_real_version_file" ] || return 1
  _vivo_real_version=$(sed -n '1p' "$_vivo_real_version_file")
  _vivo_real_version=$(sanitize_single_line "$_vivo_real_version")
  [ -n "$_vivo_real_version" ] || return 1
  _vivo_forged_version=$(transform_ota_version "$_vivo_real_version") || return 1
  [ "$_vivo_real_version" != "$_vivo_forged_version" ] || return 1
  printf '%s' "$_vivo_real_version"
}

_vivo_read_trusted_module_prop_version() {
  _vivo_module_prop_file=$1
  [ -f "$_vivo_module_prop_file" ] || return 1

  _vivo_module_description=$(sed -n 's/^description=//p' "$_vivo_module_prop_file" | sed -n '1p')
  _vivo_module_version=$(printf '%s\n' "$_vivo_module_description" | sed -n 's/^.*系统版本: \([^|]*\).*$/\1/p')
  _vivo_module_version=$(sanitize_single_line "$_vivo_module_version")
  [ -n "$_vivo_module_version" ] || return 1
  _vivo_forged_version=$(transform_ota_version "$_vivo_module_version") || return 1
  [ "$_vivo_module_version" != "$_vivo_forged_version" ] || return 1
  printf '%s' "$_vivo_module_version"
}

resolve_install_real_version() {
  _vivo_reported_version=$(sanitize_single_line "$1")

  _vivo_saved_version=$(_vivo_read_trusted_real_version "$MODDIR/real-version") && {
    printf '%s' "$_vivo_saved_version"
    return
  }

  _vivo_prior_module_dir=$(_vivo_installed_module_dir)
  if [ "$_vivo_prior_module_dir" != "$MODDIR" ]; then
    _vivo_saved_version=$(_vivo_read_trusted_real_version "$_vivo_prior_module_dir/real-version") && {
      printf '%s' "$_vivo_saved_version"
      return
    }
    _vivo_saved_version=$(_vivo_read_trusted_module_prop_version "$_vivo_prior_module_dir/module.prop") && {
      printf '%s' "$_vivo_saved_version"
      return
    }
  fi

  [ -n "$_vivo_reported_version" ] || return 1
  _vivo_forged_version=$(transform_ota_version "$_vivo_reported_version") || return 1
  [ "$_vivo_reported_version" != "$_vivo_forged_version" ] || return 1
  printf '%s' "$_vivo_reported_version"
}

detect_device_status() {
  passed=$(getprop ro.vendor.seed.customize.passed 2>/dev/null)
  if [ -n "$passed" ]; then
    [ "$passed" = yes ] && { printf normal; return; }
    printf abnormal
    return
  fi

  oem=$(getprop ro.vivo.oem.name 2>/dev/null)
  seed=$(getprop ro.vendor.seed.customize 2>/dev/null)
  rpmb=$(getprop ro.vendor.rpmb.customize 2>/dev/null)
  if [ -n "$oem" ] && [ -n "$seed" ] && [ -n "$rpmb" ]; then
    [ "$oem" = "$seed" ] && [ "$seed" = "$rpmb" ] && { printf normal; return; }
    printf abnormal
    return
  fi
  printf unknown
}

detect_space_status() {
  verifiedbootstate=$(getprop ro.boot.verifiedbootstate 2>/dev/null)
  veritymode=$(getprop ro.boot.veritymode 2>/dev/null)
  if [ -n "$verifiedbootstate" ] && [ -n "$veritymode" ]; then
    [ "$verifiedbootstate" = green ] && [ "$veritymode" = enforcing ] && {
      printf normal
      return
    }
    printf abnormal
    return
  fi
  printf unknown
}

_vivo_config_key_valid() {
  case "$1" in
    ota_enabled|space_enabled|device_enabled|device_ui_locked) return 0 ;;
    *) return 1 ;;
  esac
}

_vivo_run_ksud() {
  if command -v ksud >/dev/null 2>&1; then
    KSU_MODULE=$VIVO_MODULE_ID command ksud "$@"
  elif [ -x /data/adb/ksud ]; then
    KSU_MODULE=$VIVO_MODULE_ID /data/adb/ksud "$@"
  else
    return 127
  fi
}

_vivo_ksu_config_get() {
  _vivo_run_ksud module config get "$1" 2>/dev/null
}

_vivo_ksu_config_set() {
  _vivo_run_ksud module config set "$1" "$2" >/dev/null 2>&1
}

_vivo_file_config_get() {
  key=$1
  config_file=$MODDIR/config.prop
  if [ -f "$config_file" ]; then
    value=$(sed -n "s/^${key}=//p" "$config_file" | tail -n 1)
    case "$value" in
      0|1) printf '%s' "$value"; return ;;
    esac
  fi
  printf 0
}

_vivo_file_config_set() {
  key=$1
  value=$2
  config_file=$MODDIR/config.prop
  temp_file=$MODDIR/.config.prop.tmp.$$
  if [ -f "$config_file" ]; then
    sed "/^${key}=/d" "$config_file" > "$temp_file" || return 1
  else
    : > "$temp_file" || return 1
  fi
  printf '%s=%s\n' "$key" "$value" >> "$temp_file" || return 1
  mv "$temp_file" "$config_file"
}

_vivo_persist_file_backend() {
  _vivo_backend_marker=$MODDIR/$VIVO_BACKEND_PREFERENCE_FILE
  _vivo_backend_marker_tmp=$MODDIR/$VIVO_BACKEND_PREFERENCE_FILE.tmp.$$
  printf '%s\n' file > "$_vivo_backend_marker_tmp" || return 1
  mv "$_vivo_backend_marker_tmp" "$_vivo_backend_marker" || return 1
  VIVO_CONFIG_BACKEND=file
  export VIVO_CONFIG_BACKEND
}

_vivo_has_persistent_file_backend() {
  _vivo_backend_marker=$MODDIR/$VIVO_BACKEND_PREFERENCE_FILE
  if [ -f "$_vivo_backend_marker" ] && [ "$(sed -n '1p' "$_vivo_backend_marker")" = file ]; then
    return 0
  fi
  return 1
}

select_config_backend() {
  requested_backend=${VIVO_CONFIG_BACKEND:-}
  case "$requested_backend" in
    file)
      export VIVO_CONFIG_BACKEND
      return
      ;;
    ksu) ;;
    '')
      if _vivo_has_persistent_file_backend; then
        VIVO_CONFIG_BACKEND=file
        export VIVO_CONFIG_BACKEND
        return
      fi
      if [ "${KSU:-}" != true ] \
        && { [ -n "${MAGISK_VER_CODE:-}" ] || [ "${MAGISK_VER:-}" = true ]; }; then
        VIVO_CONFIG_BACKEND=file
        export VIVO_CONFIG_BACKEND
        return
      fi
      ;;
    *) return 1 ;;
  esac

  if _vivo_run_ksud module config list >/dev/null 2>&1; then
    VIVO_CONFIG_BACKEND=ksu
  else
    VIVO_CONFIG_BACKEND=file
  fi
  export VIVO_CONFIG_BACKEND
}

initialize_config_backend() {
  select_config_backend || return 1
  [ "$VIVO_CONFIG_BACKEND" = ksu ] || return 0

  for key in ota_enabled space_enabled device_enabled device_ui_locked; do
    value=$(_vivo_ksu_config_get "$key") || value=
    case "$value" in
      0|1)
        _vivo_file_config_set "$key" "$value" || return 1
        ;;
      *)
        value=$(_vivo_file_config_get "$key")
        _vivo_ksu_config_set "$key" "$value" || {
          _vivo_persist_file_backend || return 1
          return 0
        }
        ;;
    esac
  done
}

config_get() {
  key=$1
  _vivo_config_key_valid "$key" || return 1

  if [ "${VIVO_CONFIG_BACKEND:-file}" = ksu ]; then
    value=$(_vivo_ksu_config_get "$key") || {
      _vivo_file_config_get "$key"
      return
    }
    case "$value" in
      0|1) printf '%s' "$value" ;;
      *) _vivo_file_config_get "$key" ;;
    esac
    return
  fi

  _vivo_file_config_get "$key"
}

config_set() {
  key=$1
  value=$2
  _vivo_config_key_valid "$key" || return 1
  case "$value" in
    0|1) ;;
    *) return 1 ;;
  esac

  if [ "${VIVO_CONFIG_BACKEND:-file}" = ksu ]; then
    if _vivo_ksu_config_set "$key" "$value"; then
      _vivo_file_config_set "$key" "$value"
      return
    fi
    _vivo_persist_file_backend || return 1
  fi

  _vivo_file_config_set "$key" "$value"
}

render_system_prop() {
  version=${1:-"$(get_real_version)"}
  version=$(sanitize_single_line "$version")
  temp_file=$MODDIR/.system.prop.tmp.$$
  target_file=$MODDIR/system.prop

  : > "$temp_file" || return 1
  if [ "$(config_get ota_enabled)" = 1 ]; then
    transformed=$(transform_ota_version "$version") || {
      rm -f "$temp_file"
      return 1
    }
    printf 'ro.vivo.product.version.incremental=%s\n' "$transformed" >> "$temp_file" || return 1
  fi
  if [ "$(config_get space_enabled)" = 1 ]; then
    printf '%s\n' 'ro.vendor.seed.notification.isEnable_2=0' >> "$temp_file" || return 1
  fi
  if [ "$(config_get device_enabled)" = 1 ]; then
    printf '%s\n' 'ro.vendor.seed.notification.isEnable_1=0' >> "$temp_file" || return 1
    printf '%s\n' 'ro.vendor.seed.notification.isEnable_3=0' >> "$temp_file" || return 1
  fi
  mv "$temp_file" "$target_file"
}

reconcile_device_state() {
  device_state=${1:-"$(detect_device_status)"}
  current_device=$(config_get device_enabled)
  current_lock=$(config_get device_ui_locked)

  case "$device_state" in
    normal)
      desired_device=0
      desired_lock=1
      ;;
    abnormal)
      desired_device=$current_device
      desired_lock=0
      ;;
    unknown)
      desired_device=0
      desired_lock=1
      ;;
    *) return 1 ;;
  esac

  [ "$current_device" = "$desired_device" ] && [ "$current_lock" = "$desired_lock" ] && return 0
  config_set device_enabled "$desired_device" || return 1
  config_set device_ui_locked "$desired_lock" || return 1
  render_system_prop || return 1
  refresh_description
}

_vivo_get_first_prop() {
  for prop in "$@"; do
    value=$(getprop "$prop" 2>/dev/null)
    if [ -n "$value" ]; then
      sanitize_single_line "$value"
      return
    fi
  done
}

_vivo_root_environment() {
  if [ -x /data/adb/ksud ] || command -v ksud >/dev/null 2>&1; then
    printf KernelSU
  elif [ -f /data/adb/magisk/util_functions.sh ] || command -v magisk >/dev/null 2>&1; then
    printf Magisk
  else
    printf Unknown
  fi
}

description_symbol() {
  state=$1
  rule_enabled=$2

  case "$state" in
    normal) printf '∞' ;;
    abnormal)
      [ "$rule_enabled" = 1 ] && { printf '✅'; return; }
      printf '❌'
      ;;
    *) printf '❌' ;;
  esac
}

refresh_description() {
  device_status=$(detect_device_status)
  space_status=$(detect_space_status)
  model=$(_vivo_get_first_prop ro.vivo.market.name ro.product.marketname ro.product.model)
  version=$(get_real_version)
  [ -n "$model" ] || model=Unknown
  [ -n "$version" ] || version=Unknown
  ota_symbol='❌'
  [ "$(config_get ota_enabled)" = 1 ] && ota_symbol='✅'
  space_symbol=$(description_symbol "$space_status" "$(config_get space_enabled)")
  device_symbol=$(description_symbol "$device_status" "$(config_get device_enabled)")
  description="当前机型: $model | 系统版本: $version | OTA屏蔽: $ota_symbol | 数据空间屏蔽: $space_symbol | 设备异常屏蔽: $device_symbol"

  prop_file=$MODDIR/module.prop
  temp_file=$MODDIR/.module.prop.tmp.$$
  found_description=0
  : > "$temp_file" || return 1
  while IFS= read -r line || [ -n "$line" ]; do
    case "$line" in
      description=*)
        printf 'description=%s\n' "$description" >> "$temp_file" || return 1
        found_description=1
        ;;
      *) printf '%s\n' "$line" >> "$temp_file" || return 1 ;;
    esac
  done < "$prop_file"
  [ "$found_description" = 1 ] || return 1
  mv "$temp_file" "$prop_file" || return 1

  if [ "${VIVO_CONFIG_BACKEND:-file}" = ksu ]; then
    _vivo_ksu_config_set override.description "$description" || {
      _vivo_persist_file_backend || return 1
    }
  fi
}

emit_status() {
  model=$(_vivo_get_first_prop ro.vivo.market.name ro.product.marketname ro.product.model)
  version=$(get_real_version)
  [ -n "$model" ] || model=Unknown
  [ -n "$version" ] || version=Unknown
  printf 'model=%s\n' "$model"
  printf 'version=%s\n' "$version"
  printf 'root=%s\n' "$(_vivo_root_environment)"
  printf 'ota=%s\n' "$(config_get ota_enabled)"
  printf 'space=%s\n' "$(config_get space_enabled)"
  printf 'space_status=%s\n' "$(detect_space_status)"
  printf 'device=%s\n' "$(config_get device_enabled)"
  printf 'device_status=%s\n' "$(detect_device_status)"
  printf 'device_ui_locked=%s\n' "$(config_get device_ui_locked)"
}
