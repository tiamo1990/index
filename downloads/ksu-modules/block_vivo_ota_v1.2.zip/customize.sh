#!/system/bin/sh

SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

get_root_type() {
  if [ -x /data/adb/ksud ] || command -v ksud >/dev/null 2>&1; then
    printf 'KernelSU'
  elif [ -f /data/adb/magisk/util_functions.sh ] || command -v magisk >/dev/null 2>&1; then
    printf 'Magisk'
  else
    printf 'Unknown'
  fi
}

read_repair_choice() {
  local getevent output pid choice i event delay completed
  getevent=${GETEVENT_BIN:-/system/bin/getevent}
  output="${MODPATH:-${TMPDIR:-/tmp}}/.vivo-getevent.$$"
  choice=repair-unavailable
  delay=${INSTALL_DELAY:-1}

  if [ -x "$getevent" ]; then
    : > "$output" || { printf '%s\n' "$choice"; return; }
    "$getevent" -qlc 1 > "$output" 2>&1 &
    pid=$!
    i=0
    completed=0
    while [ "$i" -lt 10 ]; do
      if ! kill -0 "$pid" 2>/dev/null; then
        completed=1
        event=$(tr -d '\r' < "$output")
        case "$event" in
          '') choice=repair-no-input ;;
          *'
'*) choice=repair-unexpected ;;
          KEY_VOLUMEUP) choice=repair ;;
          KEY_VOLUMEDOWN) choice=skip ;;
          *)
            if printf '%s\n' "$event" | grep -Eq '^[[:space:]]*([^[:space:]]+:[[:space:]]+)?EV_KEY[[:space:]]+KEY_VOLUMEDOWN[[:space:]]+(DOWN|UP)[[:space:]]*$'; then
              choice=skip
            elif printf '%s\n' "$event" | grep -Eq '^[[:space:]]*([^[:space:]]+:[[:space:]]+)?EV_KEY[[:space:]]+KEY_VOLUMEUP[[:space:]]+(DOWN|UP)[[:space:]]*$'; then
              choice=repair
            else
              choice=repair-unexpected
            fi
            ;;
        esac
        break
      fi
      sleep "$delay"
      i=$((i + 1))
    done
    [ "$completed" = 1 ] || choice=repair-timeout
    kill "$pid" 2>/dev/null || true
    wait "$pid" 2>/dev/null || true
    rm -f "$output"
  fi

  printf '%s\n' "$choice"
}

print_detection_result() {
  local label=$1 state=$2
  case "$state" in
    normal) ui_print "$label: ✓" ;;
    abnormal) ui_print "$label: 异常" ;;
    *) ui_print "$label: 状态无法确认" ;;
  esac
}

main() {
  . "$MODPATH/lib/vivo_state.sh" || {
    ui_print '! 无法加载模块状态库'
    abort '! 安装终止'
    return 1
  }

  local reported_ver real_ver model device_state space_state choice
  MODDIR=${MODDIR:-$MODPATH}

  if [ "${BOOTMODE:-}" != true ]; then
    ui_print '! 请使用 KernelSU 或 Magisk Manager 安装本模块'
    abort '! Recovery 模式安装不受支持'
    return 1
  fi

  initialize_config_backend || return 1

  if command -v set_perm >/dev/null 2>&1; then
    [ -f "$MODPATH/webui-action.sh" ] && set_perm "$MODPATH/webui-action.sh" 0 0 0755
    [ -f "$MODPATH/lib/vivo_state.sh" ] && set_perm "$MODPATH/lib/vivo_state.sh" 0 0 0755
  fi

  reported_ver=$(getprop ro.vivo.product.version.incremental 2>/dev/null)
  real_ver=$(resolve_install_real_version "$reported_ver")
  if [ -z "$real_ver" ]; then
    abort '! 无法确认真实系统版本'
    return 1
  fi
  preserve_real_version "$real_ver" || return 1
  model=$(_vivo_get_first_prop ro.vivo.market.name ro.product.marketname ro.product.model)
  model=${model:-Unknown}
  device_state=$(detect_device_status)
  space_state=$(detect_space_status)

  ui_print "Root 环境: $(get_root_type)"
  ui_print "机型: $model"
  ui_print "版本: $real_ver"
  print_detection_result '设备异常检查' "$device_state"
  print_detection_result '数据空间检查' "$space_state"

  choice=
  if [ "$device_state" = abnormal ] || [ "$space_state" = abnormal ]; then
    ui_print '音量+：修复[推荐]'
    ui_print '音量-：跳过修复'
    choice=$(read_repair_choice)
    case "$choice" in
      skip)
        ui_print '选择结果: 跳过修复'
        ;;
      repair-timeout)
        ui_print '等待超时，已默认选择修复'
        ui_print '选择结果: 修复（默认）'
        ;;
      repair-unavailable|repair-no-input|repair-unexpected)
        ui_print '未读取到有效按键，已默认选择修复'
        ui_print '选择结果: 修复（默认）'
        ;;
      *)
        ui_print '选择结果: 修复'
        ;;
    esac
    [ "$choice" = skip ] || ui_print '正在修复…'
  fi

  config_set ota_enabled 1 || return 1
  case "$device_state" in
    normal)
      config_set device_enabled 0 || return 1
      config_set device_ui_locked 1 || return 1
      ;;
    abnormal)
      if [ "$choice" != skip ]; then
        config_set device_enabled 1 || return 1
      else
        config_set device_enabled 0 || return 1
      fi
      config_set device_ui_locked 0 || return 1
      ;;
    *)
      config_set device_enabled 0 || return 1
      config_set device_ui_locked 1 || return 1
      ;;
  esac

  if [ "$space_state" = abnormal ] && [ "$choice" != skip ]; then
    config_set space_enabled 1 || return 1
  else
    config_set space_enabled 0 || return 1
  fi

  render_system_prop "$real_ver" || return 1
  refresh_description || return 1
  if [ "$device_state" = abnormal ] || [ "$space_state" = abnormal ]; then
    if [ "$choice" = skip ]; then
      ui_print '已跳过修复'
    else
      ui_print '修复完成'
    fi
  fi
  ui_print '安装完成'
}

if [ -n "${MODPATH:-}" ]; then
  main
fi
