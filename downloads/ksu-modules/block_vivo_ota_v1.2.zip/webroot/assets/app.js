import { assertBridgeResult, waitForKernelSUBridge } from "./kernelsu.js";
import {
  ACTIONS,
  ALLOWED_ACTIONS,
  canMutate,
  createLifecycle,
  isInteractionDisabled,
  isTrustedModuleDir,
  parseStatus,
  reduceLifecycle,
  selectMutationAction,
} from "./state.js";

let bridge = null;
const app = document.querySelector("#app");
const banner = document.querySelector("#state-banner");
const bridgeIndicator = document.querySelector("#bridge-indicator");
const controls = Object.freeze({
  ota: document.querySelector("#ota-switch"),
  space: document.querySelector("#space-switch"),
  device: document.querySelector("#device-switch"),
});
const values = Object.freeze({
  model: document.querySelector("#model-value"),
  version: document.querySelector("#version-value"),
  root: document.querySelector("#root-value"),
  otaStatus: document.querySelector("#ota-status-value"),
  spaceStatus: document.querySelector("#space-status-value"),
  deviceStatus: document.querySelector("#device-status-value"),
  deviceDescription: document.querySelector("#device-description"),
  deviceNote: document.querySelector("#device-switch-note"),
});

const state = {
  moduleDir: "",
  status: {},
  lifecycle: createLifecycle(),
  requestId: 0,
};

const setText = (element, text) => {
  element.textContent = String(text);
};

const setBanner = (message, kind = "loading") => {
  app.dataset.state = kind;
  banner.dataset.kind = kind;
  setText(banner, message);
};

const transition = (event) => {
  state.lifecycle = reduceLifecycle(state.lifecycle, event);
  setBanner(state.lifecycle.message, state.lifecycle.phase);
  renderStatus();
};

const setStatusSymbol = (element, enabled, status = enabled ? "on" : "off") => {
  setText(element, enabled ? "✅" : "❌");
  element.dataset.status = status;
};

const setDetectionSymbol = (element, detection, enabled) => {
  if (detection === "normal") {
    setText(element, "∞");
    element.dataset.status = "normal";
    return;
  }
  setStatusSymbol(element, detection === "abnormal" && enabled, detection === "unknown" ? "unknown" : undefined);
};

const setSwitch = (name, checked, disabled = false, locked = false) => {
  const control = controls[name];
  control.setAttribute("aria-checked", String(Boolean(checked)));
  control.classList.toggle("is-on", Boolean(checked));
  control.classList.toggle("is-locked", locked);
  control.disabled = disabled;
};

const renderStatus = () => {
  const current = state.status;
  const normalLocked = current.device_status === "normal";
  const unknownLocked = current.device_status === "unknown" || current.device_ui_locked === "1";

  setText(values.model, current.model || "未知设备");
  setText(values.version, current.version || "未知版本");
  setText(values.root, current.root || "已连接");
  setStatusSymbol(values.otaStatus, current.ota === "1");
  setDetectionSymbol(values.spaceStatus, current.space_status, current.space === "1");
  if (normalLocked) {
    setDetectionSymbol(values.deviceStatus, "normal", current.device === "1");
  } else if (current.device_status === "unknown") {
    setDetectionSymbol(values.deviceStatus, "unknown", false);
  } else {
    setDetectionSymbol(values.deviceStatus, "abnormal", current.device === "1");
  }

  const interactionsDisabled = isInteractionDisabled(state.lifecycle);
  setSwitch("ota", current.ota === "1", interactionsDisabled);
  setSwitch("space", current.space === "1", interactionsDisabled);
  setSwitch("device", normalLocked || current.device === "1", interactionsDisabled || normalLocked || unknownLocked, normalLocked);

  if (normalLocked) {
    setText(values.deviceDescription, "状态正常");
    setText(values.deviceNote, "");
  } else if (unknownLocked) {
    setText(values.deviceDescription, "无法确认设备状态，已保护性锁定此操作。");
    setText(values.deviceNote, "状态未知，暂不允许写入通知规则");
  } else {
    setText(values.deviceDescription, "检测到设备配置异常，可按需启用通知修复。");
    setText(values.deviceNote, "异常设备可手动切换");
  }
};

const showDemo = () => {
  state.status = {
    model: "演示设备",
    version: "仅展示",
    root: "未连接 KernelSU",
    ota: "1",
    space: "0",
    space_status: "unknown",
    device: "0",
    device_status: "unknown",
    device_ui_locked: "1",
  };
  bridgeIndicator.textContent = "❔";
  transition({ type: "BRIDGE_MISSING" });
};

const runAction = async (action) => {
  if (!state.moduleDir || !ALLOWED_ACTIONS.has(action)) {
    throw new Error("模块操作尚未就绪");
  }
  const request = ++state.requestId;
  const result = assertBridgeResult(await bridge.exec(action, { cwd: state.moduleDir }));
  return { request, status: parseStatus(result.stdout) };
};

const refreshStatus = async () => {
  const response = await runAction(ACTIONS.status);
  if (response.request !== state.requestId) return false;
  state.status = response.status;
  renderStatus();
  return true;
};

const mutationState = () => ({ ...state.lifecycle, moduleDir: state.moduleDir, status: state.status });

const handleToggle = async (name) => {
  if (!canMutate(mutationState(), name)) return;
  const normalLocked = name === "device" && state.status.device_status === "normal";
  const unknownLocked = name === "device" && (state.status.device_status === "unknown" || state.status.device_ui_locked === "1");
  if (normalLocked || unknownLocked) {
    return;
  }

  const isOn = controls[name].getAttribute("aria-checked") === "true";
  const action = selectMutationAction(mutationState(), name, isOn);
  if (!action) return;

  transition({ type: "ACTION_START" });
  try {
    await runAction(action);
    await refreshStatus();
    transition({ type: "ACTION_SUCCESS" });
    bridge.toast("已保存，重启后生效");
  } catch (error) {
    transition({ type: "ACTION_FAILURE", error: error.message });
    bridge.toast("保存失败");
  }
};

const activateTab = (name) => {
  for (const button of document.querySelectorAll("[role=tab]")) {
    const active = button.dataset.tab === name;
    button.classList.toggle("is-active", active);
    button.setAttribute("aria-selected", String(active));
    button.tabIndex = active ? 0 : -1;
  }
  for (const panel of document.querySelectorAll("[data-panel]")) {
    const active = panel.dataset.panel === name;
    panel.classList.toggle("is-active", active);
    panel.hidden = !active;
  }
};

for (const [name, control] of Object.entries(controls)) {
  control.addEventListener("click", () => handleToggle(name));
}
const tabButtons = [...document.querySelectorAll("[role=tab]")];
for (const button of tabButtons) {
  button.addEventListener("click", () => activateTab(button.dataset.tab));
  button.addEventListener("keydown", (event) => {
    const currentIndex = tabButtons.indexOf(button);
    let nextIndex = null;
    if (event.key === "ArrowRight") nextIndex = (currentIndex + 1) % tabButtons.length;
    if (event.key === "ArrowLeft") nextIndex = (currentIndex - 1 + tabButtons.length) % tabButtons.length;
    if (event.key === "Home") nextIndex = 0;
    if (event.key === "End") nextIndex = tabButtons.length - 1;
    if (nextIndex === null) return;
    event.preventDefault();
    activateTab(tabButtons[nextIndex].dataset.tab);
    tabButtons[nextIndex].focus();
  });
}

const initialise = async () => {
  transition({ type: "LOAD_START" });
  bridge = await waitForKernelSUBridge();
  if (!bridge) {
    showDemo();
    return;
  }

  bridge.enableEdgeToEdge();
  try {
    const moduleInfo = JSON.parse(await bridge.moduleInfo());
    const moduleDir = moduleInfo.path || moduleInfo.moduleDir || moduleInfo.dir;
    if (!isTrustedModuleDir(moduleDir)) throw new Error("未获取到可信模块目录");
    state.moduleDir = moduleDir;
    await refreshStatus();
    transition({ type: "LOAD_SUCCESS" });
    bridgeIndicator.textContent = "✅";
  } catch (error) {
    bridgeIndicator.textContent = "⚠️";
    transition({ type: "LOAD_FAILURE", error: error.message });
  }
};

initialise();
