export const ACTIONS = Object.freeze({
  status: "./webui-action.sh status",
  otaOn: "./webui-action.sh set ota 1",
  otaOff: "./webui-action.sh set ota 0",
  spaceOn: "./webui-action.sh set space 1",
  spaceOff: "./webui-action.sh set space 0",
  deviceOn: "./webui-action.sh set device 1",
  deviceOff: "./webui-action.sh set device 0",
});
export const ALLOWED_ACTIONS = new Set(Object.values(ACTIONS));

const REQUIRED_STATUS_KEYS = Object.freeze([
  "model",
  "version",
  "root",
  "ota",
  "space",
  "space_status",
  "device",
  "device_status",
  "device_ui_locked",
]);
const SWITCH_STATUS_KEYS = new Set(["ota", "space", "device", "device_ui_locked"]);
const DEVICE_STATUS_VALUES = new Set(["normal", "abnormal", "unknown"]);

export const createLifecycle = () => ({
  phase: "loading",
  ready: false,
  busy: false,
  demo: false,
  message: "正在读取模块状态",
});

export const reduceLifecycle = (lifecycle, event) => {
  switch (event.type) {
    case "LOAD_START":
      return createLifecycle();
    case "LOAD_SUCCESS":
      return { phase: "success", ready: true, busy: false, demo: false, message: "模块状态已同步。" };
    case "LOAD_FAILURE":
      return { phase: "error", ready: false, busy: false, demo: false, message: `无法读取模块状态：${event.error || "未知错误"}` };
    case "BRIDGE_MISSING":
      return { phase: "no-bridge", ready: false, busy: false, demo: true, message: "未检测到 KernelSU 桥接，当前为演示模式，所有开关均不会执行操作。" };
    case "ACTION_START":
      return { ...lifecycle, phase: "action", busy: true, message: "正在保存设置，请稍候。" };
    case "ACTION_SUCCESS":
      return { phase: "success", ready: true, busy: false, demo: false, message: "已保存，重启后生效" };
    case "ACTION_FAILURE":
      return { ...lifecycle, phase: "error", busy: false, message: `保存失败：${event.error || "未知错误"}` };
    default:
      return lifecycle;
  }
};

export const isInteractionDisabled = (lifecycle) => !lifecycle.ready || lifecycle.busy || lifecycle.demo;

export const isTrustedModuleDir = (moduleDir) =>
  typeof moduleDir === "string" &&
  moduleDir.startsWith("/") &&
  !moduleDir.includes("\0") &&
  !moduleDir.split("/").includes("..");

export const parseStatus = (stdout) => {
  if (typeof stdout !== "string") throw new Error("状态输出格式错误");
  const status = Object.create(null);

  for (const line of stdout.split(/\r?\n/)) {
    if (line === "") continue;
    const separator = line.indexOf("=");
    if (separator < 1) throw new Error("无效状态字段");
    const key = line.slice(0, separator);
    const value = line.slice(separator + 1);
    if (!REQUIRED_STATUS_KEYS.includes(key) || Object.hasOwn(status, key)) {
      throw new Error("无效状态字段");
    }
    status[key] = value;
  }

  for (const key of REQUIRED_STATUS_KEYS) {
    if (!Object.hasOwn(status, key)) throw new Error("缺少状态字段");
  }
  if (!status.model.trim() || !status.version.trim() || !status.root.trim()) {
    throw new Error("无效状态字段");
  }
  for (const key of SWITCH_STATUS_KEYS) {
    if (status[key] !== "0" && status[key] !== "1") throw new Error("无效状态字段");
  }
  if (!DEVICE_STATUS_VALUES.has(status.device_status)) throw new Error("无效状态字段");
  return Object.freeze(status);
};

export const canMutate = (state, name) => {
  if (!Object.hasOwn({ ota: true, space: true, device: true }, name)) return false;
  if (!state.ready || state.busy || state.demo || !isTrustedModuleDir(state.moduleDir)) return false;
  if (name !== "device") return true;
  return state.status?.device_status === "abnormal" && state.status?.device_ui_locked === "0";
};

export const selectMutationAction = (state, name, isOn) => {
  if (!canMutate(state, name)) return null;
  if (name === "ota") return isOn ? ACTIONS.otaOff : ACTIONS.otaOn;
  if (name === "space") return isOn ? ACTIONS.spaceOff : ACTIONS.spaceOn;
  return isOn ? ACTIONS.deviceOff : ACTIONS.deviceOn;
};
