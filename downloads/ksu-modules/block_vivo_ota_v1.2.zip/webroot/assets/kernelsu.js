const textValue = (value) => typeof value === "string" ? value : "";
let callbackCounter = 0;

const uniqueCallbackName = () => `vivo_exec_callback_${Date.now()}_${callbackCounter += 1}`;

const hasNativeBridge = (ksu) =>
  ksu && typeof ksu.exec === "function" && typeof ksu.moduleInfo === "function";

export const normaliseResult = (result) => {
  if (Array.isArray(result)) {
    const [errno, stdout = "", stderr = ""] = result;
    return { errno, stdout: textValue(stdout), stderr: textValue(stderr) };
  }

  return {
    errno: result?.errno,
    stdout: textValue(result?.stdout),
    stderr: textValue(result?.stderr),
  };
};

export const assertBridgeResult = (result) => {
  if (!Number.isInteger(result?.errno)) {
    throw new Error("KernelSU 桥接返回无效结果");
  }
  if (result.errno !== 0) {
    throw new Error(result.stderr || "模块操作失败");
  }
  return result;
};

export const createKernelSUBridge = () => {
  const ksu = window.ksu;
  if (!hasNativeBridge(ksu)) return null;

  return Object.freeze({
    exec(command, options = {}) {
      return new Promise((resolve, reject) => {
        const callbackName = uniqueCallbackName();
        const cleanup = () => { delete window[callbackName]; };
        window[callbackName] = (errno, stdout, stderr) => {
          cleanup();
          resolve(normaliseResult({ errno, stdout, stderr }));
        };
        try {
          ksu.exec(command, JSON.stringify(options), callbackName);
        } catch (error) {
          cleanup();
          reject(error);
        }
      });
    },
    async moduleInfo() {
      return ksu.moduleInfo();
    },
    enableEdgeToEdge() {
      if (typeof ksu.enableEdgeToEdge === "function") {
        ksu.enableEdgeToEdge(true);
      }
    },
    toast(message) {
      if (typeof ksu.toast === "function") {
        ksu.toast(String(message));
      }
    },
  });
};

export const waitForKernelSUBridge = async ({ timeoutMs = 400, intervalMs = 20 } = {}) => {
  const deadline = Date.now() + timeoutMs;
  do {
    const bridge = createKernelSUBridge();
    if (bridge) return bridge;
    if (Date.now() >= deadline) return null;
    await new Promise((resolve) => setTimeout(resolve, intervalMs));
  } while (true);
};
