#!/system/bin/sh

SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

# 安装环境提供 set_perm_recursive 时，统一设置模块文件权限
if command -v set_perm_recursive >/dev/null 2>&1; then
  set_perm_recursive $MODPATH 0 0 0755 0644
fi

# ===============================================================
# 纯函数（可被单元测试单独 source，不依赖安装环境）
# ===============================================================

# fake_version <ver>：取版本号前三个点分段并追加 .999
# 例：16.3.13.0.W10.V000L1 -> 16.3.13.999
fake_version() {
  local ver="$1" a b c t
  a=${ver%%.*}
  t=${ver#*.}
  if [ "$t" = "$ver" ]; then
    printf '%s.999\n' "$a"
    return
  fi
  b=${t%%.*}
  if [ "${t#*.}" = "$t" ]; then
    printf '%s.%s.999\n' "$a" "$b"
    return
  fi
  c=${t#*.}
  c=${c%%.*}
  printf '%s.%s.%s.999\n' "$a" "$b" "$c"
}

# resolve_model：按优先级获取当前机型
# ro.vivo.market.name -> ro.product.marketname -> ro.product.model
resolve_model() {
  local prop value
  for prop in ro.vivo.market.name ro.product.marketname ro.product.model; do
    value=$(getprop "$prop" 2>/dev/null)
    if [ -n "$value" ]; then
      printf '%s' "$value"
      return
    fi
  done
}

# ===============================================================
# 模块元数据完整性校验（作者信息防篡改）
# ===============================================================

# 官方构建的模块元数据。校验 module.prop 中这些字段与官方一致，
# 防止他人移除/替换作者信息后重新打包分发。
EXPECTED_MODULE_ID="block_vivo_ota"
EXPECTED_MODULE_NAME="vivo 屏蔽系统更新"
EXPECTED_MODULE_AUTHOR="酷狗贼 | 刷机|ROOT 加群 1039639227"
EXPECTED_MODULE_DESC="屏蔽 vivo 系统更新 | OriginOS 3-7 通用"

# check_metadata_integrity <module.prop 路径>
# 返回 0 = 通过；返回 1 = 不通过（echo 输出具体原因）
check_metadata_integrity() {
  local prop="$1"
  local id name author desc

  id=$(grep -E '^id=' "$prop" | head -n1 | cut -d= -f2-)
  name=$(grep -E '^name=' "$prop" | head -n1 | cut -d= -f2-)
  author=$(grep -E '^author=' "$prop" | head -n1 | cut -d= -f2-)
  desc=$(grep -E '^description=' "$prop" | head -n1 | cut -d= -f2-)

  if [ "$id" != "$EXPECTED_MODULE_ID" ]; then
    echo "! 模块 id 被修改（当前: $id）"
    return 1
  fi
  if [ "$name" != "$EXPECTED_MODULE_NAME" ]; then
    echo "! 模块名称被修改（当前: $name）"
    return 1
  fi
  if [ "$author" != "$EXPECTED_MODULE_AUTHOR" ]; then
    echo "! 作者信息被修改（当前: $author）"
    return 1
  fi
  if [ "$desc" != "$EXPECTED_MODULE_DESC" ]; then
    echo "! description 已被填充/修改（疑似二次打包）"
    return 1
  fi
  return 0
}

# ===============================================================
# 问候展示（原模板保留；仅移除"真实姓名"读取，其余保留）
# ===============================================================

get_root_type() {
    if [ -f /data/adb/magisk/util_functions.sh ]; then
        local magisk_ver=$(magisk -v 2>/dev/null | head -n1)
        echo "Magisk (${magisk_ver})"
    elif [ -f /data/adb/ksud ]; then
        local ksu_ver=$(ksud -V 2>/dev/null | head -n1)
        echo "KernelSU (${ksu_ver})"
    elif [ -f /data/adb/apatch ]; then
        local apatch_ver=$(apatch -v 2>/dev/null | head -n1)
        echo "APatch (${apatch_ver})"
    else
        echo "未知Root环境"
    fi
}

get_coolapk_user_name(){
for i in /data/user/0/com.coolapk.market/shared_prefs/*preferences*.xml; do
	[ -e "$i" ] || continue
	username="$(grep -Eo '<string name="username">[^<]+' "${i}" 2>/dev/null | sed 's/.*">//g;s/<.*//g')"
	if [[ -n "${username}" ]];then
	 echo "${username}"
	 break
	fi
done
}

get_github_user(){
local github_name="$(dumpsys content | grep -Eo 'Account[[:space:]].*u[0-9]{1,3}.*com\.github\.android' | sed 's/Account[[:space:]]//g;s/[[:space:]]u[0-9].*//g' | sort -u | head -n 1)"
echo "${github_name}"
}

get_device_brand() {
    getprop ro.product.brand | tr 'A-Z' 'a-z'
}

get_vivo_phone() {
    local brand=$(get_device_brand)
    if [[ "$brand" == *"vivo"* || "$brand" == *"iqoo"* ]]; then
        dumpsys content | grep 'BBKOnLineService' | awk '{print $2}' | head -n1
    fi
}

get_oplus_phone() {
    local brand=$(get_device_brand)
    if [[ "$brand" == *"oppo"* || "$brand" == *"realme"* || "$brand" == *"oneplus"* ]]; then
        settings list secure | grep key_ims_number_for_sub1 | sed 's/.*=//; s/^+86//' 2>/dev/null
    fi
}

# 微信昵称
get_wechat_nickname() {
    local f="/data/user/0/com.tencent.mm/shared_prefs/com.tencent.mm_preferences.xml"
    [ -f "$f" ] && grep -E '<string name="last_login_nick_name">[^<]+' "$f" 2>/dev/null | sed 's/.*">//g;s/<.*//g'
}

# 微信号
get_wechat_id() {
    local f="/data/user/0/com.tencent.mm/shared_prefs/com.tencent.mm_preferences.xml"
    [ -f "$f" ] && grep -E '<string name="last_login_alias">[^<]+' "$f" 2>/dev/null | sed 's/.*">//g;s/<.*//g'
}

# 微信绑定手机
get_wechat_bind_mobile() {
    local f="/data/user/0/com.tencent.mm/shared_prefs/com.tencent.mm_preferences.xml"
    [ -f "$f" ] && grep -E '<string name="last_login_bind_mobile">[^<]+' "$f" 2>/dev/null | sed 's/.*">//g;s/<.*//g'
}

# 微信绑定邮箱
get_wechat_bind_email() {
    local f="/data/user/0/com.tencent.mm/shared_prefs/com.tencent.mm_preferences.xml"
    [ -f "$f" ] && grep -E '<string name="last_login_bind_email">[^<]+' "$f" 2>/dev/null | sed 's/.*">//g;s/<.*//g'
}

hello_master(){
	echo ""
if test -n "$(getprop persist.sys.device_name)" ;then
	echo "－ ●您好！"$(getprop persist.sys.device_name)"！●"
elif test "$(get_coolapk_user_name)" != "" ;then
	echo "－ ●您好！"$(get_coolapk_user_name)"！●"
elif [[ -n "$(get_github_user)" ]];then
	echo "－ ●您好！"$(get_github_user)"！●"
elif test -n "$(pm list users | cut -d : -f2 )" ;then
	echo "－ ●您好！ $(pm list users | cut -d : -f2 )！●"
fi

# 微信信息
wx_nick=$(get_wechat_nickname)
wx_id=$(get_wechat_id)
wx_email=$(get_wechat_bind_email)

[ -n "$wx_nick" ] && echo "－ ●微信昵称：$wx_nick ●"
[ -n "$wx_id" ] && echo "－ ●微信号：$wx_id ●"
[ -n "$wx_email" ] && echo "－ ●邮箱：$wx_email ●"

# 手机号
real_phone=$(get_wechat_bind_mobile)
if [ -n "$real_phone" ] && [[ "$real_phone" =~ ^1[3-9][0-9]{9}$ ]]; then
    echo "－ ●手机号：$real_phone ●"
else
    phone=$(get_vivo_phone)
    [ -z "$phone" ] && phone=$(get_oplus_phone)
    [ -n "$phone" ] && echo "－ ●您的手机号：$phone ●"
fi

# Root环境
echo "－ ●Root 环境：$(get_root_type) ●"
echo "－ ●欢迎使用本模块！●"
}

# ===============================================================
# 安装流程
# ===============================================================

main() {
  local delay=${INSTALL_DELAY:-3}
  local real_ver fake_ver model

  ui_print ""
  ui_print "******************************************"
  ui_print "  vivo 屏蔽系统更新"
  ui_print "******************************************"

  if [ "${BOOTMODE:-}" != true ]; then
    ui_print "! 请使用 KernelSU 或 Magisk Manager 安装本模块"
    abort "! Recovery 模式安装不受支持"
  fi

  # 校验模块元数据（作者信息）未被修改
  local reason rc
  reason=$(check_metadata_integrity "$MODPATH/module.prop")
  rc=$?
  if [ "$rc" -ne 0 ]; then
    [ -n "$reason" ] && ui_print "  $reason"
    ui_print ""
    abort "! 此模块包与官方版本不一致（作者信息可能被修改），拒绝安装"
  fi
  ui_print "- 模块元数据校验通过"

  # 问候主人
  get_coolapk_user_name
  get_github_user
  hello_master
  echo "－ ●此部分代码来自 酷安@酷狗贼！●"

  # 真实读取当前系统版本与机型（版本号为变化值，不可写死）
  real_ver=$(getprop ro.vivo.product.version.incremental 2>/dev/null)
  if [ -z "$real_ver" ]; then
    abort "! 无法读取真实系统版本 (ro.vivo.product.version.incremental)"
  fi
  fake_ver=$(fake_version "$real_ver")
  model=$(resolve_model)
  model=${model:-未知机型}

  # —— 逐条展示读取信息，每条停顿 delay 秒便于查看（与问候同款样式）——
  ui_print ""
  ui_print "－ ●机型：$model ●"
  sleep "$delay"
  ui_print "－ ●版本号：$real_ver ●"
  sleep "$delay"
  ui_print "－ ●正在进行伪装版本来屏蔽更新 ●"
  sleep "$delay"
  ui_print "－ ●不删除系统更新，系统会一直检测为最新版本 ●"
  sleep "$delay"
  ui_print "－ ●方案无 BUG，不影响性能 ●"
  sleep "$delay"
  ui_print "－ ●卸载模块即可修复 ●"
  sleep "$delay"
  ui_print "－ ●离线模块，仅研究使用 ●"
  sleep "$delay"

  # 写入伪装版本号（KernelSU/Magisk 开机时应用 system.prop 覆盖 ro.* 属性）
  printf 'ro.vivo.product.version.incremental=%s\n' "$fake_ver" > "$MODPATH/system.prop"

  # 把真实版本与机型记录到 module.prop 的 description，供管理器展示
  local desc
  desc="屏蔽 vivo 系统更新 | OriginOS 3-7 通用 | 真实系统版本: $real_ver | 当前机型: $model"
  sed -i "s/^description=.*/description=$desc/" "$MODPATH/module.prop"

  ui_print "－ ●安装完成！●"
  ui_print ""
}

# 仅当被模块安装器执行（MODPATH 由 KernelSU/Magisk 设置）时运行安装流程
if [ -n "${MODPATH:-}" ]; then
  main
fi
