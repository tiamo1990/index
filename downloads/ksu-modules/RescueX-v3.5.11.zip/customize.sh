#!/system/bin/sh
# RescueX v3.5.11 - customize.sh

# v3.0.1 改进（专业级升级）：
# - 三级渐进式救砖支持
# - 嫌疑模块追踪基础设施初始化
# - APP 解冻功能

MODID="RescueX"
RX_VERSION="v3.5.11"

# 解析绝对路径（兼容 KSU/Magisk/APatch）
MODPATH="$(cd "${0%/*}" 2>/dev/null && pwd)"
[ -z "$MODPATH" ] && MODPATH="${0%/*}"

ui_print() { echo "$1"; }

get_manual_snapshot_limit() {
    local limit="${MAX_MANUAL_SNAPSHOTS:-12}"
    case "$limit" in ''|*[!0-9]*) limit=12 ;; esac
    [ "$limit" -lt 1 ] 2>/dev/null && limit=1
    echo "$limit"
}

prune_manual_snapshots_dir() {
    local dir="$1"
    local limit count snap
    [ -d "$dir" ] || return 0
    limit=$(get_manual_snapshot_limit)
    count=0
    for snap in $(ls -1 "$dir"/snap-*.txt 2>/dev/null | sort -r); do
        [ -f "$snap" ] || continue
        count=$((count + 1))
        if [ "$count" -gt "$limit" ]; then
            rm -f "$snap" 2>/dev/null
        fi
    done
    return 0
}

# Compat-8: set_perm 兼容层
if ! command -v set_perm >/dev/null 2>&1; then
    set_perm() {
        local target="$1" owner="$2" group="$3" perm="$4"
        chmod "$perm" "$target" 2>/dev/null
        chown "${owner}:${group}" "$target" 2>/dev/null
    }
fi

ui_print "============================================"
ui_print "  RescueX 自动救砖 $RX_VERSION"
ui_print "  Reliable Bootloop Protection"
ui_print "============================================"

# === 系统版本检查 ===
API=$(getprop ro.build.version.sdk 2>/dev/null)
case "$API" in ''|*[!0-9]*) API=0 ;; esac
if [ "$API" -lt 28 ]; then
    ui_print "! 需要 Android 9.0 (API 28) 或更高版本"
    ui_print "! 当前 SDK: ${API:-未知}"
    exit 1
fi
ui_print "- 设备 SDK: $API"

MODEL=$(getprop ro.product.model 2>/dev/null | tr -cd 'A-Za-z0-9 ._-')
ui_print "- 设备型号: ${MODEL:-Unknown}"

# === 检测管理器类型 ===
MANAGER="unknown"
if [ -d "/data/adb/ksu" ]; then
    if pm list packages 2>/dev/null | grep -qi "sukisu"; then
        MANAGER="sukisuultra"
    else
        MANAGER="kernelsu"
    fi
elif [ -d "/data/adb/ap" ]; then
    MANAGER="apatch"
elif [ -d "/data/adb/magisk" ]; then
    MANAGER="magisk"
fi
ui_print "- 管理器: $MANAGER"

# v3.5.10+: keep the WebUI choice outside the module tree so module updates do
# not force the user through the volume-key prompt again.
PERSIST_DIR="/data/adb/rescuex_data"
MAX_MANUAL_SNAPSHOTS=12
HAD_PERSISTED_INSTALL=false
[ -f "$PERSIST_DIR/config.conf" ] && HAD_PERSISTED_INSTALL=true
[ -f "$PERSIST_DIR/ota_build_baseline" ] && HAD_PERSISTED_INSTALL=true
[ -f "$PERSIST_DIR/boot_status" ] && HAD_PERSISTED_INSTALL=true
mkdir -p "$PERSIST_DIR" 2>/dev/null
RX_WEBUI_CHOICE_FILE="$PERSIST_DIR/webui_install_preference"
export PERSIST_DIR RX_WEBUI_CHOICE_FILE
if [ -f "$MODPATH/webui-choice.sh" ]; then
    . "$MODPATH/webui-choice.sh"
    rx_webui_set_locale
    ui_print "- $(rx_webui_text locale)"
    ui_print "- $(rx_webui_text timezone)"
fi

# Find the previous installation before deciding whether a volume-down choice
# may remove the WebUI. Existing users must not lose their recovery UI because
# of one accidental key press during an update.
OLD_STATE_DIR=""
for old_base in /data/adb/modules /data/adb/ksu/modules /data/adb/ap/modules /data/adb/ap_modules; do
    if [ -d "$old_base/$MODID/webroot/state" ]; then
        OLD_STATE_DIR="$old_base/$MODID/webroot/state"
        break
    fi
done
HAS_PREVIOUS_WEBUI=false
for old_base in /data/adb/modules /data/adb/ksu/modules /data/adb/ap/modules /data/adb/ap_modules; do
    if [ -f "$old_base/$MODID/webroot/index.html" ]; then
        HAS_PREVIOUS_WEBUI=true
        break
    fi
done
IS_UPGRADE_PRECHECK=false
[ -n "$OLD_STATE_DIR" ] && IS_UPGRADE_PRECHECK=true
[ "$HAD_PERSISTED_INSTALL" = true ] && IS_UPGRADE_PRECHECK=true

# === WebUI 安装选择 ===
# A confirmed preference skips the key listener. Without one, the first choice
# is recorded as pending and the WebUI asks for confirmation on first entry.
KSU_WEBUI_URL="https://github.com/5ec1cff/KsuWebUIStandalone"

webui_supported_manager() {
    case "$MANAGER" in
        kernelsu|sukisuultra|apatch) return 0 ;;
        magisk)
            # MMRL 等支持 WebUI 的第三方 Magisk 管理器视为支持
            pm list packages 2>/dev/null | grep -qi "dergoogler.mmrl" && return 0
            return 1
            ;;
        *) return 0 ;;
    esac
}

# Fallback copy is Chinese to match the rest of the installer output. It is only
# used if webui-choice.sh is missing, which would otherwise mix languages.
rx_webui_msg() {
    if command -v rx_webui_text >/dev/null 2>&1; then
        rx_webui_text "$1"
    else
        printf '%s' "$2"
    fi
}

prompt_webui_choice() {
    ui_print ""
    ui_print "============================================"
    ui_print "  $(rx_webui_msg title 'WebUI 安装选择')"
    ui_print "============================================"
    if webui_supported_manager; then
        ui_print "  $(rx_webui_msg supported '当前管理器支持 WebUI'): $MANAGER"
    else
        ui_print "  ! $(rx_webui_msg unsupported '当前管理器可能不支持原生 WebUI')"
        ui_print "  ! KsuWebUIStandalone:"
        ui_print "  $KSU_WEBUI_URL"
    fi
    ui_print ""
    ui_print "  $(rx_webui_msg install '[音量+] 安装 WebUI / Install WebUI')"
    ui_print "  $(rx_webui_msg skip '[音量-] 暂不安装 WebUI / Skip WebUI')"
    ui_print "  $(rx_webui_msg timeout '60 秒无操作将安装 WebUI / No input in 60s: install')"
    [ "$HAS_PREVIOUS_WEBUI" = true ] && ui_print "  ! $(rx_webui_msg legacy_warning '检测到已有 WebUI；本次音量下选择不会删除它')"
    ui_print "============================================"
}

wait_webui_volkey() {
    # Without getevent, keep the historical safe default: install WebUI.
    command -v getevent >/dev/null 2>&1 || return 0
    local i=0 ev
    while [ "$i" -lt 60 ]; do
        if command -v timeout >/dev/null 2>&1; then
            ev=$(timeout 1 getevent -lc 1 2>/dev/null)
        else
            ev=$(getevent -lc 1 2>/dev/null)
        fi
        ev=$(printf '%s' "$ev" | tr '[:lower:]' '[:upper:]')
        case "$ev" in
            *VOLUMEUP*|*KEY_VOLUMEUP*) return 0 ;;
            *VOLUMEDOWN*|*KEY_VOLUMEDOWN*) return 1 ;;
        esac
        i=$((i + 1))
    done
    return 0
}

INSTALL_WEBUI=true
WEBUI_SELECTED_CHOICE=install
WEBUI_PREF_CONFIRMED=false
if command -v rx_webui_choice_is_confirmed >/dev/null 2>&1 && rx_webui_choice_is_confirmed; then
    WEBUI_PREF_CONFIRMED=true
    WEBUI_SELECTED_CHOICE=$(rx_webui_choice_read CHOICE)
    if [ "$WEBUI_SELECTED_CHOICE" = install ]; then
        INSTALL_WEBUI=true
        ui_print "- $(rx_webui_msg auto_install '已按已确认偏好自动安装 WebUI')"
    else
        INSTALL_WEBUI=false
        ui_print "- $(rx_webui_msg auto_skip '已按已确认偏好跳过 WebUI')"
    fi
else
    prompt_webui_choice
    if wait_webui_volkey; then
        WEBUI_SELECTED_CHOICE=install
        INSTALL_WEBUI=true
        ui_print "- $(rx_webui_msg selected_install '已选择：安装 WebUI')"
    else
        WEBUI_SELECTED_CHOICE=skip
        INSTALL_WEBUI=false
        # On an update, never delete a known-good existing WebUI before the user
        # has confirmed the new persistent choice from inside the WebUI.
        if [ "$IS_UPGRADE_PRECHECK" = true ] && [ "$HAS_PREVIOUS_WEBUI" = true ]; then
            INSTALL_WEBUI=true
            WEBUI_SELECTED_CHOICE=install
            ui_print "- $(rx_webui_msg legacy_warning '检测到已有 WebUI；本次音量下选择不会删除它')"
        else
            ui_print "- $(rx_webui_msg selected_skip '已选择：暂不安装 WebUI')"
        fi
    fi
    if command -v rx_webui_choice_write_pending >/dev/null 2>&1; then
        rx_webui_choice_write_pending "$WEBUI_SELECTED_CHOICE" volume || ui_print "! WebUI 偏好保存失败，本次安装仍会继续"
    fi
fi

# === 创建状态目录 ===
STATE_DIR="$MODPATH/webroot/state"
SNAPSHOT_DIR="$STATE_DIR/snapshots"
PATCH_BACKUP_DIR="$STATE_DIR/patch_backup"
mkdir -p "$STATE_DIR" "$SNAPSHOT_DIR" "$PATCH_BACKUP_DIR"

# === 升级时保留旧版用户配置 ===
# OLD_STATE_DIR and PERSIST_DIR are prepared before the WebUI prompt so the
# choice can be applied without losing the previous installation context.

# v2.7.0: 持久化目录（模块更新不丢失）
# PERSIST_DIR is initialized above; keep the value visible for the migration
# and OTA sections below.

# Cross-OEM OTA detection keeps one system-build identity outside the module
# tree. A missing baseline is captured during installation and subsequently
# advances only after a confirmed successful boot in service.sh.
OTA_BASELINE_FILE="$PERSIST_DIR/ota_build_baseline"
OTA_DETECTION_STATUS_FILE="$STATE_DIR/ota_detection_status"
if [ -f "$MODPATH/ota-detection.sh" ]; then
    . "$MODPATH/ota-detection.sh"
    if ota_initialize_baseline_if_missing; then
        ui_print "- 系统 OTA 构建基线已就绪"
    else
        ui_print "! 未能建立 OTA 构建基线；将在首次成功启动后重试"
    fi
else
    ui_print "! OTA 检测扩展缺失，将使用兼容检测"
fi

CONFIG_PRESERVED=false
WHITELIST_PRESERVED=false
IS_UPGRADE=false

# v3.5.9: an old integrity daemon must be stopped before the module directory
# is replaced. Otherwise it can hash a half-updated tree and overwrite the new
# integrity status with a false COMPROMISED result.
stop_previous_integrity_daemon() {
    local pid_file pid cmdline waited
    for pid_file in "$OLD_STATE_DIR/integrity_pid" "$PERSIST_DIR/integrity_pid"; do
        [ -f "$pid_file" ] || continue
        pid=$(cat "$pid_file" 2>/dev/null)
        case "$pid" in ''|*[!0-9]*) continue ;; esac
        cmdline=$(tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null)
        case "$cmdline" in
            *integrity.sh*)
                kill "$pid" 2>/dev/null || true
                waited=0
                while [ "$waited" -lt 5 ] && kill -0 "$pid" 2>/dev/null; do
                    sleep 1
                    waited=$((waited + 1))
                done
                kill -0 "$pid" 2>/dev/null && kill -9 "$pid" 2>/dev/null || true
                ;;
        esac
    done
    [ -z "$OLD_STATE_DIR" ] || rm -f "$OLD_STATE_DIR/.integrity_start.lock" 2>/dev/null
    rm -f "$STATE_DIR/.integrity_start.lock" 2>/dev/null
}
if [ -n "$OLD_STATE_DIR" ] || [ -f "$PERSIST_DIR/integrity_pid" ]; then
    stop_previous_integrity_daemon
fi
# Mark every install/overlay as requiring one post-install baseline rebuild.
# This is intentionally outside the module directory so an overlay cannot
# preserve an old same-version manifest by accident.
printf 'VERSION_CODE=%s\n' "$(grep '^versionCode=' "$MODPATH/module.prop" 2>/dev/null | cut -d= -f2)" > "$PERSIST_DIR/integrity_upgrade_pending.tmp.$$"
chmod 0600 "$PERSIST_DIR/integrity_upgrade_pending.tmp.$$" 2>/dev/null
mv -f "$PERSIST_DIR/integrity_upgrade_pending.tmp.$$" "$PERSIST_DIR/integrity_upgrade_pending" 2>/dev/null || rm -f "$PERSIST_DIR/integrity_upgrade_pending.tmp.$$"

# v2.7.0: 优先从旧版模块目录迁移，其次从持久化目录恢复
if [ -n "$OLD_STATE_DIR" ]; then
    ui_print "- 检测到旧版安装，尝试保留用户配置"
    IS_UPGRADE=true
    # 配置
    if [ -f "$OLD_STATE_DIR/config.conf" ]; then
        cp "$OLD_STATE_DIR/config.conf" "$STATE_DIR/config.conf" 2>/dev/null && CONFIG_PRESERVED=true
    fi
    # 白名单
    if [ -f "$OLD_STATE_DIR/whitelist.conf" ]; then
        cp "$OLD_STATE_DIR/whitelist.conf" "$STATE_DIR/whitelist.conf" 2>/dev/null && WHITELIST_PRESERVED=true
    fi
    # 历史日志
    [ -f "$OLD_STATE_DIR/boot_history" ] && cp "$OLD_STATE_DIR/boot_history" "$STATE_DIR/boot_history" 2>/dev/null
    [ -f "$OLD_STATE_DIR/boot_duration_history" ] && cp "$OLD_STATE_DIR/boot_duration_history" "$STATE_DIR/boot_duration_history" 2>/dev/null
    [ -f "$OLD_STATE_DIR/rescue.log" ] && cp "$OLD_STATE_DIR/rescue.log" "$STATE_DIR/rescue.log" 2>/dev/null
    # v2.7.0: 保留 boot_status（累计统计不丢失）
    if [ -f "$OLD_STATE_DIR/boot_status" ]; then
        cp "$OLD_STATE_DIR/boot_status" "$STATE_DIR/boot_status" 2>/dev/null
        ui_print "- 已保留启动统计数据"
    fi
    # v2.7.0: 保留补丁相关文件
    [ -f "$OLD_STATE_DIR/patch_fail_count" ] && cp "$OLD_STATE_DIR/patch_fail_count" "$STATE_DIR/patch_fail_count" 2>/dev/null
    [ -f "$OLD_STATE_DIR/patch_update_flag" ] && cp "$OLD_STATE_DIR/patch_update_flag" "$STATE_DIR/patch_update_flag" 2>/dev/null
    [ -f "$OLD_STATE_DIR/auto_snapshot_session" ] && cp "$OLD_STATE_DIR/auto_snapshot_session" "$STATE_DIR/auto_snapshot_session" 2>/dev/null
    # v2.7.0: 保留救砖审计日志
    [ -f "$OLD_STATE_DIR/rescue_audit.log" ] && cp "$OLD_STATE_DIR/rescue_audit.log" "$STATE_DIR/rescue_audit.log" 2>/dev/null
    [ -f "$OLD_STATE_DIR/onboarding_ack" ] && cp "$OLD_STATE_DIR/onboarding_ack" "$STATE_DIR/onboarding_ack" 2>/dev/null
    # 快照迁移
    if [ -d "$OLD_STATE_DIR/snapshots" ]; then
        snap_count=0
        for snap in "$OLD_STATE_DIR/snapshots"/snap-*.txt "$OLD_STATE_DIR/snapshots"/auto-snap-*.txt; do
            [ -f "$snap" ] || continue
            snap_name=$(basename "$snap")
            if [ ! -f "$SNAPSHOT_DIR/$snap_name" ]; then
                cp "$snap" "$SNAPSHOT_DIR/" 2>/dev/null && snap_count=$((snap_count + 1))
            fi
        done
        prune_manual_snapshots_dir "$SNAPSHOT_DIR"
        ui_print "- 已迁移 $snap_count 个快照"
    fi
fi

# v2.7.0: 如果旧版目录迁移失败，从持久化目录恢复
if [ "$CONFIG_PRESERVED" != "true" ] && [ -d "$PERSIST_DIR" ]; then
    ui_print "- 从持久化目录恢复数据"
    IS_UPGRADE=true
    [ -f "$PERSIST_DIR/config.conf" ] && cp "$PERSIST_DIR/config.conf" "$STATE_DIR/config.conf" 2>/dev/null && CONFIG_PRESERVED=true
    [ -f "$PERSIST_DIR/whitelist.conf" ] && cp "$PERSIST_DIR/whitelist.conf" "$STATE_DIR/whitelist.conf" 2>/dev/null && WHITELIST_PRESERVED=true
    [ -f "$PERSIST_DIR/boot_history" ] && cp "$PERSIST_DIR/boot_history" "$STATE_DIR/boot_history" 2>/dev/null
    [ -f "$PERSIST_DIR/boot_duration_history" ] && cp "$PERSIST_DIR/boot_duration_history" "$STATE_DIR/boot_duration_history" 2>/dev/null
    [ -f "$PERSIST_DIR/boot_status" ] && cp "$PERSIST_DIR/boot_status" "$STATE_DIR/boot_status" 2>/dev/null && ui_print "- 已恢复启动统计"
    [ -f "$PERSIST_DIR/patch_fail_count" ] && cp "$PERSIST_DIR/patch_fail_count" "$STATE_DIR/patch_fail_count" 2>/dev/null
    [ -f "$PERSIST_DIR/auto_snapshot_session" ] && cp "$PERSIST_DIR/auto_snapshot_session" "$STATE_DIR/auto_snapshot_session" 2>/dev/null
    [ -f "$PERSIST_DIR/rescue_audit.log" ] && cp "$PERSIST_DIR/rescue_audit.log" "$STATE_DIR/rescue_audit.log" 2>/dev/null
    [ -f "$PERSIST_DIR/onboarding_ack" ] && cp "$PERSIST_DIR/onboarding_ack" "$STATE_DIR/onboarding_ack" 2>/dev/null
    [ -f "$PERSIST_DIR/good_modules.list" ] && cp "$PERSIST_DIR/good_modules.list" "$STATE_DIR/good_modules.list" 2>/dev/null
    if [ -d "$PERSIST_DIR/snapshots" ]; then
        for snap in "$PERSIST_DIR/snapshots"/snap-*.txt "$PERSIST_DIR/snapshots"/auto-snap-*.txt; do
            [ -f "$snap" ] || continue
            snap_name=$(basename "$snap")
            [ ! -f "$SNAPSHOT_DIR/$snap_name" ] && cp "$snap" "$SNAPSHOT_DIR/" 2>/dev/null
        done
        prune_manual_snapshots_dir "$SNAPSHOT_DIR"
    fi
fi

# v3.5.9: reconcile the watchdog choice across old module state and the
# external persistence mirror. If either preserved copy explicitly requested
# Native, do not silently downgrade it because the other copy is stale Shell.
preserve_watchdog_engine_choice() {
    local source value native_seen=0 tmp
    for source in "$OLD_STATE_DIR/config.conf" "$PERSIST_DIR/config.conf" "$STATE_DIR/config.conf"; do
        [ -f "$source" ] || continue
        value=$(awk -F= '$1 == "WATCHDOG_ENGINE" && NF == 2 && ($2 == "native" || $2 == "shell") { v=$2 } END { print v }' "$source" 2>/dev/null)
        [ "$value" = native ] && native_seen=1
    done
    [ -f "$STATE_DIR/config.conf" ] || return 0
    tmp="$STATE_DIR/config.conf.engine.$$"
    awk -F= '$1 != "WATCHDOG_ENGINE" { print }' "$STATE_DIR/config.conf" > "$tmp" 2>/dev/null || { rm -f "$tmp"; return 1; }
    if [ "$native_seen" -eq 1 ]; then
        printf 'WATCHDOG_ENGINE=native\n' >> "$tmp"
    else
        printf 'WATCHDOG_ENGINE=shell\n' >> "$tmp"
    fi
    chmod 0600 "$tmp" 2>/dev/null
    sync "$tmp" 2>/dev/null
    mv -f "$tmp" "$STATE_DIR/config.conf" 2>/dev/null || { rm -f "$tmp"; return 1; }
    chmod 0600 "$STATE_DIR/config.conf" 2>/dev/null
    return 0
}
preserve_watchdog_engine_choice || ui_print "! 看门狗后端配置协调失败，将使用安全默认值"

# === 写入默认配置（仅在未保留时）===
if [ "$CONFIG_PRESERVED" != "true" ]; then
    cat > "$STATE_DIR/config.conf" << 'CONF'
REBOOT_THRESHOLD=3
BOOT_TIMEOUT_SEC=90
OTA_TIMEOUT_SEC=900
ENABLED=true
LOG_ENABLED=true
# The installer status line in v3.5.9 was inconsistent with the actual default
# above. Keep first install in rehearsal mode so no unverified rescue can mutate
# third-party modules; users can explicitly disable DRY_RUN after validation.
DRY_RUN=true
PROGRESSIVE_RESCUE=true
AUTO_REENABLE=false
USER_REBOOT_GRACE_SEC=30
PATCH_UPDATE_TIMEOUT_SEC=180
PATCH_FAIL_THRESHOLD=2
PATCH_AUTO_ROLLBACK=true
WATCHDOG_POLL_INTERVAL_SEC=2
WATCHDOG_ENGINE=shell
INTEGRITY_CHECK_ENABLED=true
INTEGRITY_INTERVAL_MIN_SEC=60
CONF
    ui_print "- 默认配置已写入"
else
    ui_print "- 已保留旧版配置"
    # 为旧版配置补全新增字段
    if ! grep -q "^PATCH_UPDATE_TIMEOUT_SEC=" "$STATE_DIR/config.conf" 2>/dev/null; then
        echo "PATCH_UPDATE_TIMEOUT_SEC=180" >> "$STATE_DIR/config.conf"
    fi
    if ! grep -q "^PATCH_FAIL_THRESHOLD=" "$STATE_DIR/config.conf" 2>/dev/null; then
        echo "PATCH_FAIL_THRESHOLD=2" >> "$STATE_DIR/config.conf"
    fi
    if ! grep -q "^PATCH_AUTO_ROLLBACK=" "$STATE_DIR/config.conf" 2>/dev/null; then
        echo "PATCH_AUTO_ROLLBACK=true" >> "$STATE_DIR/config.conf"
    fi
    if ! grep -q "^WATCHDOG_POLL_INTERVAL_SEC=" "$STATE_DIR/config.conf" 2>/dev/null; then
        echo "WATCHDOG_POLL_INTERVAL_SEC=2" >> "$STATE_DIR/config.conf"
    fi
    if ! grep -q "^WATCHDOG_ENGINE=" "$STATE_DIR/config.conf" 2>/dev/null; then
        echo "WATCHDOG_ENGINE=shell" >> "$STATE_DIR/config.conf"
    fi
    if ! grep -q "^INTEGRITY_CHECK_ENABLED=" "$STATE_DIR/config.conf" 2>/dev/null; then
        echo "INTEGRITY_CHECK_ENABLED=true" >> "$STATE_DIR/config.conf"
    fi
    if ! grep -q "^INTEGRITY_INTERVAL_MIN_SEC=" "$STATE_DIR/config.conf" 2>/dev/null; then
        echo "INTEGRITY_INTERVAL_MIN_SEC=60" >> "$STATE_DIR/config.conf"
    fi
    ui_print "- 已补全新增配置项"
fi

# === 写入白名单（仅在未保留时）===
if [ "$WHITELIST_PRESERVED" != "true" ]; then
    cat > "$STATE_DIR/whitelist.conf" << 'WL'
# 救砖时保留的模块（一行一个 ID，# 开头为注释）
# 只允许字母数字 . _ -
# 示例：
# font_module
# audio_mod
WL
    ui_print "- 默认白名单已写入"
else
    ui_print "- 已保留旧版白名单"
fi

# v2.7.0: boot_status 处理
# 升级时保留旧版 boot_status（含 RESCUE_COUNT 等累计数据）
# 首次安装时写入初始状态
if [ "$IS_UPGRADE" != "true" ] || [ ! -f "$STATE_DIR/boot_status" ]; then
    cat > "$STATE_DIR/boot_status" << 'STATUS'
BOOT_START=0
BOOT_END=0
SERVICE_STARTED=0
FAIL_COUNT=0
LAST_BOOT_RESULT=INIT
OTA_DETECTED=false
RESCUE_COUNT=0
LAST_RESCUE_TIME=0
BOOT_DURATION=0
UPTIME_START=0
UPTIME_END=0
PATCH_DETECTED=false
STATUS
fi

# === 初始化历史和日志（仅首次安装时清空，升级时一律保留）===
if [ "$IS_UPGRADE" != "true" ]; then
    : > "$STATE_DIR/boot_history"
    : > "$STATE_DIR/rescue.log"
fi
rm -f "$STATE_DIR/watchdog_pid"
rm -f "$STATE_DIR/.boot_status.tmp"
rm -f "$STATE_DIR/boot_status.json.tmp"
rm -f "$STATE_DIR/.boot_status.tmp."*
rm -f "$STATE_DIR/boot_status.json.tmp."*
rm -f "$STATE_DIR/.report.tmp"
# v2.7.0: 清理残留的救砖禁用列表（升级后可能已无效）
# 不清理 patch_update_flag 和 patch_fail_count（跨重启保留）

# === 完整性基线迁移 ===
# 核心脚本会随模块 ZIP 一起更新，旧版本 manifest 的哈希不能用于校验新版本。
# 仅清掉派生的完整性状态/基线；用户配置、白名单、快照、启动统计均保留。
if [ "$IS_UPGRADE" = "true" ]; then
    rm -f "$STATE_DIR/integrity.manifest" "$STATE_DIR/integrity_status" "$STATE_DIR/integrity_pid" 2>/dev/null
    rm -f "$PERSIST_DIR/integrity.manifest" 2>/dev/null
    ui_print "- 模块已更新：将在首次启动后建立新的完整性基线"
fi

# === 首次使用引导标记 ===
if [ "$IS_UPGRADE" != "true" ]; then
    echo "1" > "$STATE_DIR/first_run"
    ui_print "- 首次安装：已写入引导标记"
else
    if [ ! -f "$OLD_STATE_DIR/first_run" ] && [ ! -f "$PERSIST_DIR/first_run" ]; then
        echo "2" > "$STATE_DIR/first_run"
        ui_print "- 检测到从旧版升级：将显示新功能介绍"
    else
        # 保留旧版标记
        if [ -f "$OLD_STATE_DIR/first_run" ]; then
            cp "$OLD_STATE_DIR/first_run" "$STATE_DIR/first_run" 2>/dev/null
        elif [ -f "$PERSIST_DIR/first_run" ]; then
            cp "$PERSIST_DIR/first_run" "$STATE_DIR/first_run" 2>/dev/null
        fi
    fi
fi

# v2.7.0: 创建持久化目录并同步
mkdir -p "$PERSIST_DIR" 2>/dev/null
    for f in config.conf whitelist.conf boot_status boot_history boot_duration_history patch_fail_count patch_update_flag first_run rescue_audit.log onboarding_ack good_modules.list rescue_level; do
    [ -f "$STATE_DIR/$f" ] && cp "$STATE_DIR/$f" "$PERSIST_DIR/$f" 2>/dev/null
done
if [ -d "$SNAPSHOT_DIR" ]; then
    mkdir -p "$PERSIST_DIR/snapshots" 2>/dev/null
    for snap in "$SNAPSHOT_DIR"/snap-*.txt "$SNAPSHOT_DIR"/auto-snap-*.txt; do
        [ -f "$snap" ] && cp "$snap" "$PERSIST_DIR/snapshots/" 2>/dev/null
    done
fi
chmod 0700 "$PERSIST_DIR" 2>/dev/null

# v3.5.10: 无 WebUI 模式移除页面文件
# 保留 webroot/state（配置/状态）与 webroot/arm64-v8a（原生看门狗二进制）。
if [ "$INSTALL_WEBUI" != "true" ]; then
    ui_print "- 无 WebUI 模式：移除 WebUI 页面文件"
    rm -f "$MODPATH/webroot/index.html" "$MODPATH/webroot/script.js" "$MODPATH/webroot/style.css" "$MODPATH/webroot/workspace-v2.css" "$MODPATH/webroot/md3-theme.css" 2>/dev/null
    rm -rf "$MODPATH/webroot/assets" 2>/dev/null
fi

# === 权限设置 ===
set_perm "$MODPATH" 0 0 0755
set_perm "$MODPATH/common.sh"        0 0 0700
set_perm "$MODPATH/ota-detection.sh" 0 0 0700
set_perm "$MODPATH/monet-palette.sh" 0 0 0700
set_perm "$MODPATH/post-fs-data.sh"  0 0 0700
set_perm "$MODPATH/service.sh"       0 0 0700
set_perm "$MODPATH/watchdog.sh"      0 0 0700
set_perm "$MODPATH/integrity.sh"     0 0 0700
set_perm "$MODPATH/uninstall.sh"     0 0 0700
set_perm "$MODPATH/customize.sh"     0 0 0700
# v3.5.10+: preference helper remains in no-WebUI mode so a later reinstall
# can still inspect/reset the external choice without losing the state schema.
set_perm "$MODPATH/webui-choice.sh" 0 0 0700
set_perm "$MODPATH/module.prop" 0 0 0644

# v3.5.9: remove the obsolete backup that could roll metadata back after an overlay update.
rm -f "$MODPATH/module.prop.bak" "$MODPATH/module.prop.tmp."* 2>/dev/null
set_perm "$MODPATH/README.md" 0 0 0644
set_perm "$MODPATH/LICENSE"  0 0 0644
set_perm "$MODPATH/webroot"           0 0 0755
set_perm "$MODPATH/webroot/arm64-v8a" 0 0 0755
# v3.5.9: some KSU-compatible installers do not preserve the ZIP file mode.
# Set the executable bit on the native file itself, not only its directory.
set_perm "$MODPATH/webroot/arm64-v8a/rescuex-watchdog" 0 0 0755
chmod 0755 "$MODPATH/webroot/arm64-v8a/rescuex-watchdog" 2>/dev/null
set_perm "$MODPATH/webroot/assets"    0 0 0755
set_perm "$MODPATH/webroot/index.html" 0 0 0644
set_perm "$MODPATH/webroot/style.css"        0 0 0644
set_perm "$MODPATH/webroot/workspace-v2.css" 0 0 0644
set_perm "$MODPATH/webroot/md3-theme.css"   0 0 0644
set_perm "$MODPATH/webroot/script.js"         0 0 0644
set_perm "$STATE_DIR" 0 0 0700
set_perm "$SNAPSHOT_DIR" 0 0 0700
set_perm "$PATCH_BACKUP_DIR" 0 0 0700

# 状态文件权限
for f in config.conf whitelist.conf boot_status boot_history boot_duration_history rescue.log onboarding_ack; do
    [ -f "$STATE_DIR/$f" ] && set_perm "$STATE_DIR/$f" 0 0 0600
done

ui_print "- 权限设置完成（最小权限原则）"
ui_print ""
ui_print "  默认参数："
ui_print "  · 连续重启阈值: 3 次"
ui_print "  · 开机超时: 90 秒"
ui_print "  · OTA 超时: 900 秒 (15 分钟)"
ui_print "  · 补丁超时: 180 秒"
ui_print "  · 渐进式救砖: 启用"
ui_print "  · 启动模式感知: 启用"
  ui_print "  · 数据持久化: 启用 (v3.4.0)"
# v3.5.9-r1: first install remains rehearsal-only until explicitly changed.
ui_print "  · DRY_RUN: 开启（首次验证后可关闭）"
ui_print ""
if [ "$INSTALL_WEBUI" = "true" ]; then
ui_print "  通过 WebUI 可调整全部参数"
ui_print "  首次使用请在 WebUI 完成引导"
else
ui_print "  无 WebUI 模式：请手动修改配置文件"
ui_print "  配置路径: /data/adb/rescuex_data/config.conf"
fi
ui_print "  重启设备以生效"
ui_print "============================================"
