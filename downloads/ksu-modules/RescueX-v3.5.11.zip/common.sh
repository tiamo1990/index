#!/system/bin/sh
# RescueX v3.5.9-r1 - common.sh
# 共享函数库，被 post-fs-data.sh / service.sh / watchdog.sh / uninstall.sh source
# 所有函数在此唯一定义，杜绝跨脚本重复实现导致的不一致
#
# v3.0.1 改进：
# - 修复已知良好模块数显示为总模块数的问题（改为仅统计启用模块）
# - WebUI saveGoodModules 与 common.sh 保存逻辑对齐（含禁用模块前缀）
#
# v3.0.0 改进（专业级升级）：
# - 嫌疑模块追踪：save_good_modules / detect_suspect_modules（BG 核心功能）
# - 三级渐进式救砖：嫌疑禁用 → 全量+脚本锁定 → APP 解冻
# - APP 解冻：unfreeze_apps（删除 package-restrictions.xml）
# - 安全文件 I/O：safe_write / safe_read

# 全局版本号（所有脚本统一引用）
RX_VERSION="v3.5.11"
RX_VERSION_CODE=350204

# ============================================================
# 路径初始化
# ============================================================
_rescuex_init_paths() {
    # MODDIR 可由调用者预设（如 watchdog.sh），否则从 $0 推断
    if [ -z "$MODDIR" ]; then
        MODDIR="$(cd "${0%/*}" 2>/dev/null && pwd)"
    fi
    # 兜底：尝试已知路径
    if [ -z "$MODDIR" ] || [ ! -d "$MODDIR" ]; then
        for d in /data/adb/modules/RescueX /data/adb/ksu/modules/RescueX /data/adb/ap/modules/RescueX /data/adb/ap_modules/RescueX; do
            if [ -d "$d" ]; then MODDIR="$d"; break; fi
        done
    fi

    SELF_ID="RescueX"
    STATE_DIR="$MODDIR/webroot/state"
    CONF_FILE="$STATE_DIR/config.conf"
    WHITELIST_FILE="$STATE_DIR/whitelist.conf"
    STATUS_FILE="$STATE_DIR/boot_status"
    STATUS_TMP="$STATE_DIR/.boot_status.tmp"
    JSON_FILE="$STATE_DIR/boot_status.json"
    LOG_FILE="$STATE_DIR/rescue.log"
    HISTORY_FILE="$STATE_DIR/boot_history"
    WATCHDOG_PID_FILE="$STATE_DIR/watchdog_pid"
    WATCHDOG_SCRIPT="$MODDIR/watchdog.sh"
    SNAPSHOT_DIR="$STATE_DIR/snapshots"
    AUTO_SNAPSHOT_FILE="$SNAPSHOT_DIR/auto-snap-latest.txt"
    AUTO_SNAPSHOT_SESSION_FILE="$STATE_DIR/auto_snapshot_session"
    MAX_MANUAL_SNAPSHOTS=5

    INTEGRITY_MANIFEST_FILE="$STATE_DIR/integrity.manifest"
    INTEGRITY_STATUS_FILE="$STATE_DIR/integrity_status"
    INTEGRITY_PID_FILE="$STATE_DIR/integrity_pid"
    INTEGRITY_SCRIPT="$MODDIR/integrity.sh"
    INTEGRITY_UPGRADE_PENDING_FILE="${PERSIST_DIR:-/data/adb/rescuex_data}/integrity_upgrade_pending"

    # v3.0.0: 嫌疑模块追踪
    GOOD_MODULES_FILE="$STATE_DIR/good_modules.list"   # 成功开机后的已知良好模块列表
    SUSPECT_LOG="$STATE_DIR/suspect_modules.log"         # 救砖时检测到的嫌疑模块日志

    # v3.0.0: 三级救砖 - 当前救砖级别追踪
    RESCUE_LEVEL_FILE="$STATE_DIR/rescue_level"          # 0=嫌疑禁用, 1=全量+脚本, 2=APP解冻


    # 补丁更新标记文件（持久化，跨重启保留）
    # 由 WebUI 或外部工具写入 "1" 表示处于补丁更新窗口期
    PATCH_FLAG_FILE="$STATE_DIR/patch_update_flag"
    PATCH_FAIL_COUNT_FILE="$STATE_DIR/patch_fail_count"
    PATCH_BACKUP_DIR="$STATE_DIR/patch_backup"

    # v2.7.0: 救砖禁用列表（记录救砖操作禁用的模块，供精确恢复）
    RESCUED_DISABLED_LIST="$STATE_DIR/rescued_disabled.list"

    # v2.7.0: 持久数据目录（模块更新时不会丢失）
    # 测试环境可显式隔离持久状态；生产环境仍使用既有默认目录。
    PERSIST_DIR="${RESCUEX_PERSIST_DIR:-/data/adb/rescuex_data}"

    # Shared WebUI installer preference reader. It is intentionally external to
    # the rescue state machine; sourcing it has no runtime side effects.
    WEBUI_CHOICE_SCRIPT="$MODDIR/webui-choice.sh"
    if [ -f "$WEBUI_CHOICE_SCRIPT" ]; then
        . "$WEBUI_CHOICE_SCRIPT"
    fi

    # 跨 Root 救砖事务 journal：每条目标绑定管理器、根目录和实际路径，
    # 恢复时只删除 RescueX 在该路径写入的 disable 标记。
    RESCUE_TXN_DIR="$PERSIST_DIR/rescue-transactions"
    RESCUE_TXN_CURRENT_FILE="$STATE_DIR/rescue-transaction-current"

    MODULE_BASE="/data/adb/modules"
    MODULE_BASE_KSU=""
    MODULE_BASE_AP=""
    [ -d "/data/adb/ksu/modules" ] && MODULE_BASE_KSU="/data/adb/ksu/modules"
    # APatch 兼容：新版本用 /data/adb/ap/modules，早期版本用 /data/adb/ap_modules
    for _ap_dir in /data/adb/ap/modules /data/adb/ap_modules; do
        if [ -d "$_ap_dir" ]; then
            MODULE_BASE_AP="$_ap_dir"
            break
        fi
    done
    unset _ap_dir

    SAFE_CUSTOM_DIR_PREFIXES="$PERSIST_DIR $STATE_DIR $SNAPSHOT_DIR /data/local/tmp/RescueX"
}

# ============================================================
# 时间工具：uptime 单调时钟 + 智能日志时间
# ============================================================

# 读取 /proc/uptime 的整数秒部分（内核启动后的单调递增时间）
# 不依赖 RTC、不依赖系统时钟同步，在 post-fs-data 阶段即可用
# 返回值通过 stdout，失败返回 0
get_uptime_sec() {
    local up
    up=$(cat /proc/uptime 2>/dev/null | cut -d' ' -f1 | cut -d'.' -f1)
    case "$up" in ''|*[!0-9]*) echo 0 ;; *) echo "$up" ;; esac
}

# v3.5.9: monotonic boot token. Wall-clock time is not valid for deciding
# whether a previous boot failed because Android may set RTC after post-fs-data.
get_boot_token() {
    local id btime
    id=$(cat /proc/sys/kernel/random/boot_id 2>/dev/null | tr -cd 'a-f0-9-')
    if [ -n "$id" ]; then printf '%s' "$id"; return 0; fi
    # Fallback must be stable throughout one boot. /proc/uptime changes on every
    # call and therefore must never be used as an identity token.
    btime=$(awk '$1 == "btime" { print $2; exit }' /proc/stat 2>/dev/null)
    case "$btime" in ''|*[!0-9]*) printf '' ;; *) printf 'btime-%s' "$btime" ;; esac
}

# Return a usable epoch only after RTC has a sane value. Do not persist 1970/1971
# timestamps as boot or rescue times; monotonic BOOT_TOKEN/uptime fields remain
# authoritative during early Android init.
get_valid_epoch() {
    local epoch
    epoch=$(date +%s 2>/dev/null)
    case "$epoch" in ''|*[!0-9]*) epoch=0 ;; esac
    [ "$epoch" -ge 1577836800 ] 2>/dev/null || epoch=0
    printf '%s' "$epoch"
}

# 智能日志时间：系统时钟正常时显示日期，异常时显示 uptime
# 解决 post-fs-data 阶段 RTC 未同步导致日志显示 1971 年的问题
# 阈值：1577836800 = 2020-01-01 00:00:00 UTC，小于此值视为时钟异常
#
# v2.6.0 兼容性修复（老牌遗留问题）：
# 原实现 `date '+%Y-%m-%d %H:%M:%S'` 输出含空格（如 "2026-07-16 12:34:56"），
# 写入 boot_history 后 [time] 字段被 compute_boot_stats 用 `${line%% *}` 切分时
# 只能取到 "[2026-07-16"，破坏统计解析。现统一输出无空格格式：
#   - 时钟正常：返回纯 epoch（无空格，可被 ${line%% *} 完整切出）
#   - 时钟异常：返回 uptime+Ns 格式（同样无空格）
# 日志可读性通过诊断报告的 date 转换保留（见 generate_report 内 date -d 调用）。
get_log_time() {
    local epoch up
    epoch=$(date +%s 2>/dev/null)
    case "$epoch" in ''|*[!0-9]*) epoch=0 ;; esac
    if [ "$epoch" -lt 1577836800 ]; then
        # 系统时钟异常（如 1971 年），用 uptime 显示相对时间
        up=$(get_uptime_sec)
        echo "uptime+${up}s"
    else
        # v2.6.0: 输出 epoch，无空格，便于 boot_history 字段解析
        echo "$epoch"
    fi
}

# ============================================================
# 日志（带自动轮转 + 智能时间戳）
# ============================================================
log() {
    # LOG_ENABLED 可能未被 read_config 设置（如 watchdog 触发前）
    if [ "${LOG_ENABLED:-true}" != "true" ]; then return; fi
    mkdir -p "${LOG_FILE%/*}" 2>/dev/null
    echo "[$(get_log_time)] $1" >> "$LOG_FILE"
    # 轮转：超 500KB 保留最后 200 行
    local sz
    sz=$(wc -c < "$LOG_FILE" 2>/dev/null)
    case "$sz" in
        ''|*[!0-9]*)
            # 极少数 toybox 不支持 wc -c，退回 stat -c%s，两者都不可用则跳过本次轮转检查
            sz=$(stat -c%s "$LOG_FILE" 2>/dev/null)
            case "$sz" in ''|*[!0-9]*) sz=0 ;; esac
            ;;
    esac
    if [ "$sz" -gt 512000 ]; then
        tail -n 200 "$LOG_FILE" > "${LOG_FILE}.tmp" 2>/dev/null
        mv "${LOG_FILE}.tmp" "$LOG_FILE"
        echo "[$(get_log_time)] [日志已轮转]" >> "$LOG_FILE"
    fi
}

# ============================================================
# 持久化同步（v2.7.0 新增）
# 关键数据同步到模块外部目录，模块更新/重装后自动恢复
# ============================================================

# 只同步配置到模块外持久目录；供 WebUI 保存和启动迁移使用。
# 配置是用户选择的权威输入，写入必须与模块内副本同样原子。
sync_config_to_persist() {
    local tmp="${PERSIST_DIR}/config.conf.tmp.$$"
    [ -f "$CONF_FILE" ] || return 1
    mkdir -p "$PERSIST_DIR" 2>/dev/null || return 1
    umask 077
    cat "$CONF_FILE" > "$tmp" 2>/dev/null || { rm -f "$tmp"; return 1; }
    chmod 0600 "$tmp" 2>/dev/null
    sync "$tmp" 2>/dev/null
    mv -f "$tmp" "$PERSIST_DIR/config.conf" 2>/dev/null || { rm -f "$tmp"; return 1; }
    chmod 0600 "$PERSIST_DIR/config.conf" 2>/dev/null
    return 0
}

# 同步关键持久数据到外部目录（模块更新时不会丢失）
sync_to_persist() {
    mkdir -p "$PERSIST_DIR" 2>/dev/null
    normalize_snapshot_storage
    sync_removable_persist_state_files
    for f in config.conf whitelist.conf boot_status boot_duration_history patch_fail_count patch_update_flag rescued_disabled.list rescue_audit.log onboarding_ack good_modules.list rescue_level auto_snapshot_session integrity.manifest integrity_upgrade_pending; do
        [ -f "$STATE_DIR/$f" ] && cp "$STATE_DIR/$f" "$PERSIST_DIR/$f" 2>/dev/null
    done
    merge_boot_history_persist 2>/dev/null || true
    # 快照目录
    if [ -d "$SNAPSHOT_DIR" ]; then
        mkdir -p "$PERSIST_DIR/snapshots" 2>/dev/null
        _sync_persist_snapshot_dir
        for snap in "$SNAPSHOT_DIR"/snap-*.txt "$SNAPSHOT_DIR"/auto-snap-*.txt; do
            [ -f "$snap" ] && cp "$snap" "$PERSIST_DIR/snapshots/" 2>/dev/null
        done
        prune_manual_snapshots_in_dir "$PERSIST_DIR/snapshots"
    fi
    # v3.5 observability and snapshot metadata are persisted as one private tree.
    if [ -d "$STATE_DIR/v35" ]; then
        rm -rf "$PERSIST_DIR/v35.tmp" 2>/dev/null
        cp -R "$STATE_DIR/v35" "$PERSIST_DIR/v35.tmp" 2>/dev/null && {
            rm -rf "$PERSIST_DIR/v35" 2>/dev/null
            mv "$PERSIST_DIR/v35.tmp" "$PERSIST_DIR/v35" 2>/dev/null
        }
    fi
    chmod 0700 "$PERSIST_DIR" 2>/dev/null
    [ ! -d "$PERSIST_DIR/v35" ] || chmod -R go-rwx "$PERSIST_DIR/v35" 2>/dev/null
}

# Merge append-only boot history from both copies. Lines are deduplicated,
# preserving order; this is safe across module overlays and reboot persistence.
merge_boot_history_persist() {
    local local_file="$HISTORY_FILE" persist_file="$PERSIST_DIR/boot_history" tmp
    local lock="${HISTORY_FILE}.lock" i=0 rc=0
    mkdir -p "$PERSIST_DIR" "${local_file%/*}" 2>/dev/null || return 1
    while ! mkdir "$lock" 2>/dev/null; do
        i=$((i + 1)); [ "$i" -ge 10 ] && return 1
        sleep 1
    done
    if [ ! -f "$local_file" ] && [ -f "$persist_file" ]; then
        cp "$persist_file" "$local_file" 2>/dev/null || rc=1
    elif [ -f "$local_file" ] && [ ! -f "$persist_file" ]; then
        cp "$local_file" "$persist_file" 2>/dev/null || rc=1
    elif [ -f "$local_file" ] && [ -f "$persist_file" ]; then
        tmp="${local_file}.merge.$$"
        cat "$persist_file" "$local_file" | awk 'NF && !seen[$0]++' > "$tmp" 2>/dev/null || rc=1
        if [ "$rc" -eq 0 ]; then
            mv -f "$tmp" "$local_file" 2>/dev/null || rc=1
            [ "$rc" -eq 0 ] && cp "$local_file" "$persist_file" 2>/dev/null || rc=1
        fi
        [ "$rc" -eq 0 ] || rm -f "$tmp" 2>/dev/null
    fi
    [ ! -f "$local_file" ] || chmod 0600 "$local_file" 2>/dev/null
    [ ! -f "$persist_file" ] || chmod 0600 "$persist_file" 2>/dev/null
    rmdir "$lock" 2>/dev/null
    return "$rc"
}

rescuex_v35_state_has_payload() {
    local item
    for item in "$STATE_DIR/v35"/* "$STATE_DIR/v35"/.[!.]* "$STATE_DIR/v35"/..?* \
        "$STATE_DIR/v35/health.d"/* "$STATE_DIR/v35/snapshot-meta"/*; do
        [ -f "$item" ] && return 0
    done
    return 1
}

# 从外部持久目录恢复数据（模块更新/重装后自动恢复）
restore_from_persist() {
    [ ! -d "$PERSIST_DIR" ] && return 1
    local restored=0
    for f in config.conf whitelist.conf boot_history boot_duration_history patch_fail_count patch_update_flag rescued_disabled.list rescue_audit.log good_modules.list rescue_level auto_snapshot_session integrity.manifest; do
        if [ -f "$PERSIST_DIR/$f" ] && [ ! -f "$STATE_DIR/$f" ]; then
            cp "$PERSIST_DIR/$f" "$STATE_DIR/$f" 2>/dev/null && restored=$((restored + 1))
        fi
    done
    # 快照恢复
    if [ -d "$PERSIST_DIR/snapshots" ]; then
        mkdir -p "$SNAPSHOT_DIR" 2>/dev/null
        for snap in "$PERSIST_DIR/snapshots"/snap-*.txt "$PERSIST_DIR/snapshots"/auto-snap-*.txt; do
            [ -f "$snap" ] || continue
            snap_name=$(basename "$snap")
            [ ! -f "$SNAPSHOT_DIR/$snap_name" ] && cp "$snap" "$SNAPSHOT_DIR/" 2>/dev/null && restored=$((restored + 1))
        done
        normalize_snapshot_storage
        prune_manual_snapshots_in_dir "$SNAPSHOT_DIR"
    fi
    # features-v35.sh creates its empty directory skeleton while common.sh is
    # sourced. Treat only real payload files as local state; otherwise restore
    # the prior private tree instead of overwriting it on the next sync.
    if [ -d "$PERSIST_DIR/v35" ] && ! rescuex_v35_state_has_payload; then
        rm -rf "$STATE_DIR/v35" 2>/dev/null
        cp -R "$PERSIST_DIR/v35" "$STATE_DIR/v35" 2>/dev/null && restored=$((restored + 1))
        chmod -R go-rwx "$STATE_DIR/v35" 2>/dev/null
    fi
    # boot_history 特殊处理：双向合并，避免旧模块副本隐藏新事件。
    merge_boot_history_persist 2>/dev/null || true
    # boot_status 特殊处理：合并累计字段
    if [ -f "$PERSIST_DIR/boot_status" ]; then
        _merge_persistent_boot_status
        restored=$((restored + 1))
    fi
    [ "$restored" -gt 0 ] && log "从持久目录恢复了 $restored 个文件"
    return 0
}

# 合并持久目录的 boot_status 累计字段到当前 boot_status
_merge_persistent_boot_status() {
    [ ! -f "$PERSIST_DIR/boot_status" ] && return
    [ ! -f "$STATUS_FILE" ] && return

    # 读取持久目录的累计值
    local persist_rescue_count=0 persist_last_rescue_time=0
    local k v
    while IFS='=' read -r k v; do
        [ -z "$k" ] && continue
        case "$k" in
            RESCUE_COUNT) persist_rescue_count="$v" ;;
            LAST_RESCUE_TIME) persist_last_rescue_time="$v" ;;
        esac
    done < "$PERSIST_DIR/boot_status"
    case "$persist_rescue_count" in ''|*[!0-9]*) persist_rescue_count=0 ;; esac
    case "$persist_last_rescue_time" in ''|*[!0-9]*) persist_last_rescue_time=0 ;; esac

    # 读取当前文件的值
    local cur_rescue_count=0 cur_last_rescue_time=0
    while IFS='=' read -r k v; do
        [ -z "$k" ] && continue
        case "$k" in
            RESCUE_COUNT) cur_rescue_count="$v" ;;
            LAST_RESCUE_TIME) cur_last_rescue_time="$v" ;;
        esac
    done < "$STATUS_FILE"
    case "$cur_rescue_count" in ''|*[!0-9]*) cur_rescue_count=0 ;; esac
    case "$cur_last_rescue_time" in ''|*[!0-9]*) cur_last_rescue_time=0 ;; esac

    # 取最大值合并
    local final_rescue_count=$cur_rescue_count
    local final_last_rescue_time=$cur_last_rescue_time
    [ "$persist_rescue_count" -gt "$cur_rescue_count" ] && final_rescue_count=$persist_rescue_count
    [ "$persist_last_rescue_time" -gt "$cur_last_rescue_time" ] && final_last_rescue_time=$persist_last_rescue_time

    # 如果有变化，更新当前文件
    if [ "$final_rescue_count" != "$cur_rescue_count" ] || [ "$final_last_rescue_time" != "$cur_last_rescue_time" ]; then
        # 读取所有字段并重写
        local boot_start=0 boot_token="" boot_end=0 service_started=0 fail_count=0 result=UNKNOWN
        local ota_detected=false boot_duration=0 uptime_start=0 uptime_end=0 patch_detected=false
        while IFS='=' read -r k v; do
            [ -z "$k" ] && continue
            case "$k" in
                BOOT_START) boot_start="$v" ;;
                BOOT_TOKEN) boot_token="$v" ;;
                BOOT_END) boot_end="$v" ;;
                SERVICE_STARTED) service_started="$v" ;;
                FAIL_COUNT) fail_count="$v" ;;
                LAST_BOOT_RESULT) result="$v" ;;
                OTA_DETECTED) ota_detected="$v" ;;
                BOOT_DURATION) boot_duration="$v" ;;
                UPTIME_START) uptime_start="$v" ;;
                UPTIME_END) uptime_end="$v" ;;
                PATCH_DETECTED) patch_detected="$v" ;;
            esac
        done < "$STATUS_FILE"

        [ -n "$boot_token" ] || boot_token=$(get_boot_token)
        local tmp="${STATUS_TMP}.$$"
        cat > "$tmp" << STATUS
BOOT_START=$boot_start
BOOT_TOKEN=$boot_token
BOOT_END=$boot_end
SERVICE_STARTED=$service_started
FAIL_COUNT=$fail_count
LAST_BOOT_RESULT=$result
OTA_DETECTED=$ota_detected
RESCUE_COUNT=$final_rescue_count
LAST_RESCUE_TIME=$final_last_rescue_time
BOOT_DURATION=$boot_duration
UPTIME_START=$uptime_start
UPTIME_END=$uptime_end
PATCH_DETECTED=$patch_detected
STATUS
        sync "$tmp" 2>/dev/null
        mv "$tmp" "$STATUS_FILE"
        chmod 0600 "$STATUS_FILE" 2>/dev/null
        log "合并持久数据: RESCUE_COUNT=$final_rescue_count, LAST_RESCUE_TIME=$final_last_rescue_time"
    fi
}

# ============================================================
# 救砖审计日志（v2.7.0 新增）
# ============================================================

# 记录救砖操作审计日志
# 参数: <action_type> <detail>
log_rescue_action() {
    local action_type="$1"
    local detail="$2"
    local audit_file="$STATE_DIR/rescue_audit.log"
    mkdir -p "${audit_file%/*}" 2>/dev/null
    echo "[$(get_log_time)] $action_type | $detail" >> "$audit_file"
    # 轮转审计日志到 200 行
    local lc
    lc=$(wc -l < "$audit_file" 2>/dev/null || echo 0)
    case "$lc" in ''|*[!0-9]*) lc=0 ;; esac
    if [ "$lc" -gt 200 ]; then
        tail -n 200 "$audit_file" > "${audit_file}.tmp"
        mv "${audit_file}.tmp" "$audit_file"
    fi
    # 同步到持久目录
    [ -d "$PERSIST_DIR" ] && cp "$audit_file" "$PERSIST_DIR/rescue_audit.log" 2>/dev/null
    if command -v v35_timeline_append >/dev/null 2>&1; then
        v35_timeline_append RESCUE warning "$action_type" "$detail"
    fi
}

# 列出救砖审计日志
list_rescue_audit() {
    local audit_file="$STATE_DIR/rescue_audit.log"
    [ -f "$audit_file" ] && cat "$audit_file" || echo "(无审计记录)"
}

# ============================================================
# 配置读取（一次性读入，避免多次 grep）
# ============================================================
_read_config_legacy() {
    # 默认值
    REBOOT_THRESHOLD=3
    BOOT_TIMEOUT_SEC=90
    OTA_TIMEOUT_SEC=900
    ENABLED=true
    LOG_ENABLED=true
    DRY_RUN=false
    PROGRESSIVE_RESCUE=true
    AUTO_REENABLE=false
    USER_REBOOT_GRACE_SEC=30
    # v2.4 新增：补丁更新专属配置
    PATCH_UPDATE_TIMEOUT_SEC=180
    PATCH_FAIL_THRESHOLD=2
    PATCH_AUTO_ROLLBACK=true
    # 看门狗轮询间隔（秒），原硬编码为 2，现可配置（尤其利于 OTA 900s 长超时场景减少轮询次数）
    WATCHDOG_POLL_INTERVAL_SEC=2
    INTEGRITY_CHECK_ENABLED=true
    INTEGRITY_INTERVAL_MIN_SEC=60

    [ ! -f "$CONF_FILE" ] && return

    local k v
    while IFS='=' read -r k v; do
        [ -z "$k" ] && continue
        case "$k" in
            REBOOT_THRESHOLD) REBOOT_THRESHOLD="${v:-3}" ;;
            BOOT_TIMEOUT_SEC) BOOT_TIMEOUT_SEC="${v:-90}" ;;
            OTA_TIMEOUT_SEC) OTA_TIMEOUT_SEC="${v:-900}" ;;
            ENABLED) ENABLED="${v:-true}" ;;
            LOG_ENABLED) LOG_ENABLED="${v:-true}" ;;
            DRY_RUN) DRY_RUN="${v:-false}" ;;
            PROGRESSIVE_RESCUE) PROGRESSIVE_RESCUE="${v:-true}" ;;
            AUTO_REENABLE) AUTO_REENABLE="${v:-false}" ;;
            USER_REBOOT_GRACE_SEC) USER_REBOOT_GRACE_SEC="${v:-30}" ;;
            PATCH_UPDATE_TIMEOUT_SEC) PATCH_UPDATE_TIMEOUT_SEC="${v:-180}" ;;
            PATCH_FAIL_THRESHOLD) PATCH_FAIL_THRESHOLD="${v:-2}" ;;
            PATCH_AUTO_ROLLBACK) PATCH_AUTO_ROLLBACK="${v:-true}" ;;
            WATCHDOG_POLL_INTERVAL_SEC) WATCHDOG_POLL_INTERVAL_SEC="${v:-2}" ;;
            INTEGRITY_CHECK_ENABLED) INTEGRITY_CHECK_ENABLED="${v:-true}" ;;
            INTEGRITY_INTERVAL_MIN_SEC) INTEGRITY_INTERVAL_MIN_SEC="${v:-60}" ;;
        esac
    done < "$CONF_FILE"

    # 数字校验
    case "$REBOOT_THRESHOLD" in ''|*[!0-9]*) REBOOT_THRESHOLD=3 ;; esac
    case "$BOOT_TIMEOUT_SEC" in ''|*[!0-9]*) BOOT_TIMEOUT_SEC=90 ;; esac
    case "$OTA_TIMEOUT_SEC" in ''|*[!0-9]*) OTA_TIMEOUT_SEC=900 ;; esac
    case "$USER_REBOOT_GRACE_SEC" in ''|*[!0-9]*) USER_REBOOT_GRACE_SEC=30 ;; esac
    case "$PATCH_UPDATE_TIMEOUT_SEC" in ''|*[!0-9]*) PATCH_UPDATE_TIMEOUT_SEC=180 ;; esac
    case "$PATCH_FAIL_THRESHOLD" in ''|*[!0-9]*) PATCH_FAIL_THRESHOLD=2 ;; esac
    case "$WATCHDOG_POLL_INTERVAL_SEC" in ''|*[!0-9]*) WATCHDOG_POLL_INTERVAL_SEC=2 ;; esac
    case "$INTEGRITY_INTERVAL_MIN_SEC" in ''|*[!0-9]*) INTEGRITY_INTERVAL_MIN_SEC=60 ;; esac

    case "$ENABLED" in true|1|yes) ENABLED=true ;; false|0|no) ENABLED=false ;; *) ENABLED=true ;; esac
    case "$LOG_ENABLED" in true|1|yes) LOG_ENABLED=true ;; false|0|no) LOG_ENABLED=false ;; *) LOG_ENABLED=true ;; esac
    case "$DRY_RUN" in true|1|yes) DRY_RUN=true ;; false|0|no) DRY_RUN=false ;; *) DRY_RUN=false ;; esac
    case "$PROGRESSIVE_RESCUE" in true|1|yes) PROGRESSIVE_RESCUE=true ;; false|0|no) PROGRESSIVE_RESCUE=false ;; *) PROGRESSIVE_RESCUE=true ;; esac
    case "$AUTO_REENABLE" in true|1|yes) AUTO_REENABLE=true ;; false|0|no) AUTO_REENABLE=false ;; *) AUTO_REENABLE=false ;; esac
    case "$PATCH_AUTO_ROLLBACK" in true|1|yes) PATCH_AUTO_ROLLBACK=true ;; false|0|no) PATCH_AUTO_ROLLBACK=false ;; *) PATCH_AUTO_ROLLBACK=true ;; esac
    case "$INTEGRITY_CHECK_ENABLED" in true|1|yes) INTEGRITY_CHECK_ENABLED=true ;; false|0|no) INTEGRITY_CHECK_ENABLED=false ;; *) INTEGRITY_CHECK_ENABLED=true ;; esac

    # 范围限制（2>/dev/null 防止非数字比较报错）
    [ "$REBOOT_THRESHOLD" -lt 1 ] 2>/dev/null && REBOOT_THRESHOLD=1
    [ "$REBOOT_THRESHOLD" -gt 10 ] 2>/dev/null && REBOOT_THRESHOLD=10
    [ "$BOOT_TIMEOUT_SEC" -lt 30 ] 2>/dev/null && BOOT_TIMEOUT_SEC=30
    [ "$BOOT_TIMEOUT_SEC" -gt 600 ] 2>/dev/null && BOOT_TIMEOUT_SEC=600
    [ "$OTA_TIMEOUT_SEC" -lt 60 ] 2>/dev/null && OTA_TIMEOUT_SEC=60
    [ "$OTA_TIMEOUT_SEC" -gt 1800 ] 2>/dev/null && OTA_TIMEOUT_SEC=1800
    [ "$USER_REBOOT_GRACE_SEC" -lt 5 ] 2>/dev/null && USER_REBOOT_GRACE_SEC=5
    [ "$USER_REBOOT_GRACE_SEC" -gt 300 ] 2>/dev/null && USER_REBOOT_GRACE_SEC=300
    # 补丁超时：60-600 秒（1-10 分钟），介于普通开机和完整 OTA 之间
    [ "$PATCH_UPDATE_TIMEOUT_SEC" -lt 60 ] 2>/dev/null && PATCH_UPDATE_TIMEOUT_SEC=60
    [ "$PATCH_UPDATE_TIMEOUT_SEC" -gt 600 ] 2>/dev/null && PATCH_UPDATE_TIMEOUT_SEC=600
    # 补丁失败阈值：1-5 次
    [ "$PATCH_FAIL_THRESHOLD" -lt 1 ] 2>/dev/null && PATCH_FAIL_THRESHOLD=1
    [ "$PATCH_FAIL_THRESHOLD" -gt 5 ] 2>/dev/null && PATCH_FAIL_THRESHOLD=5
    # 看门狗轮询间隔：1-10 秒（原硬编码 2，过小在 OTA 长超时下轮询次数过多，过大影响及时性）
    [ "$WATCHDOG_POLL_INTERVAL_SEC" -lt 1 ] 2>/dev/null && WATCHDOG_POLL_INTERVAL_SEC=1
    [ "$WATCHDOG_POLL_INTERVAL_SEC" -gt 10 ] 2>/dev/null && WATCHDOG_POLL_INTERVAL_SEC=10
    [ "$INTEGRITY_INTERVAL_MIN_SEC" -lt 60 ] 2>/dev/null && INTEGRITY_INTERVAL_MIN_SEC=60
    [ "$INTEGRITY_INTERVAL_MIN_SEC" -gt 300 ] 2>/dev/null && INTEGRITY_INTERVAL_MIN_SEC=300
    return 0
}

integrity_target_files() {
    printf '%s\n' common.sh watchdog.sh integrity.sh post-fs-data.sh service.sh
}

integrity_hash_file() {
    local file="$1" hash
    if command -v sha256sum >/dev/null 2>&1; then
        hash=$(sha256sum "$file" 2>/dev/null | cut -d' ' -f1)
    elif command -v toybox >/dev/null 2>&1; then
        hash=$(toybox sha256sum "$file" 2>/dev/null | cut -d' ' -f1)
    fi
    printf '%s' "$hash"
}

integrity_write_status() {
    local result="$1" detail="$2"
    mkdir -p "$STATE_DIR" 2>/dev/null
    {
        echo "RESULT=$result"
        echo "DETAIL=$detail"
        echo "CHECKED_AT=$(get_log_time)"
    } > "$INTEGRITY_STATUS_FILE.tmp.$$"
    chmod 0600 "$INTEGRITY_STATUS_FILE.tmp.$$" 2>/dev/null
    mv "$INTEGRITY_STATUS_FILE.tmp.$$" "$INTEGRITY_STATUS_FILE"
}

integrity_build_manifest() {
    local name hash version hashed=0 missing=0
    version=$(grep '^versionCode=' "$MODDIR/module.prop" 2>/dev/null | cut -d= -f2)
    case "$version" in ''|*[!0-9]*) version=0 ;; esac
    mkdir -p "$STATE_DIR" 2>/dev/null
    printf '#VERSION=%s\n' "$version" > "$INTEGRITY_MANIFEST_FILE.tmp.$$"
    while IFS= read -r name; do
        if [ ! -f "$MODDIR/$name" ]; then
            missing=$((missing + 1))
            continue
        fi
        hash=$(integrity_hash_file "$MODDIR/$name")
        case "$hash" in
            [0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F]* )
                [ "${#hash}" -eq 64 ] || continue
                printf '%s  %s\n' "$hash" "$name" >> "$INTEGRITY_MANIFEST_FILE.tmp.$$"
                hashed=$((hashed + 1))
                ;;
        esac
    done << EOF
$(integrity_target_files)
EOF
    [ "$missing" -eq 0 ] && [ "$hashed" -gt 0 ] || { rm -f "$INTEGRITY_MANIFEST_FILE.tmp.$$"; return 1; }
    chmod 0600 "$INTEGRITY_MANIFEST_FILE.tmp.$$" 2>/dev/null
    mv "$INTEGRITY_MANIFEST_FILE.tmp.$$" "$INTEGRITY_MANIFEST_FILE"
}

_integrity_check_once_legacy() {
    local name expected actual missing=0 changed=0 version manifest_version
    version=$(grep '^versionCode=' "$MODDIR/module.prop" 2>/dev/null | cut -d= -f2)
    case "$version" in ''|*[!0-9]*) version=0 ;; esac
    [ -f "$INTEGRITY_MANIFEST_FILE" ] || {
        integrity_build_manifest || { integrity_write_status ERROR "无法建立基线"; return 1; }
        integrity_write_status BASELINE_CREATED "已建立完整性基线"
        return 0
    }
    manifest_version=$(grep '^#VERSION=' "$INTEGRITY_MANIFEST_FILE" 2>/dev/null | cut -d= -f2)
    if [ "$manifest_version" != "$version" ]; then
        integrity_build_manifest || { integrity_write_status ERROR "无法更新版本基线"; return 1; }
        integrity_write_status BASELINE_CREATED "模块版本已更新，已重建基线"
        return 0
    fi
    while read -r expected name; do
        [ -n "$name" ] || continue
        if [ ! -f "$MODDIR/$name" ]; then missing=$((missing + 1)); continue; fi
        actual=$(integrity_hash_file "$MODDIR/$name")
        [ "$actual" = "$expected" ] || changed=$((changed + 1))
    done < "$INTEGRITY_MANIFEST_FILE"
    if [ "$missing" -gt 0 ] || [ "$changed" -gt 0 ]; then
        integrity_write_status COMPROMISED "缺失${missing}个，变更${changed}个"
        log "[INTEGRITY] 检测到 RescueX 文件完整性异常: 缺失=${missing}, 变更=${changed}"
        return 1
    fi
    integrity_write_status OK "核心文件校验通过"
    return 0
}

integrity_pid_is_alive() {
    local pid
    pid=$(cat "$INTEGRITY_PID_FILE" 2>/dev/null)
    case "$pid" in ''|*[!0-9]*) return 1 ;; esac
    kill -0 "$pid" 2>/dev/null
}

start_integrity_daemon() {
    read_config
    [ "$INTEGRITY_CHECK_ENABLED" = "true" ] || return 0
    integrity_pid_is_alive && return 0
    # 通过 sh 启动，不依赖 ZIP 解包后的可执行位；只要求脚本可读。
    [ -r "$INTEGRITY_SCRIPT" ] || return 1
    mkdir "$STATE_DIR/.integrity_start.lock" 2>/dev/null || return 0
    integrity_pid_is_alive && { rmdir "$STATE_DIR/.integrity_start.lock" 2>/dev/null; return 0; }
    sh "$INTEGRITY_SCRIPT" >/dev/null 2>&1 < /dev/null &
}

stop_integrity_daemon() {
    local pid cmdline
    pid=$(cat "$INTEGRITY_PID_FILE" 2>/dev/null)
    case "$pid" in ''|*[!0-9]*) pid=0 ;; esac
    if [ "$pid" != "0" ] && kill -0 "$pid" 2>/dev/null; then
        cmdline=$(cat "/proc/$pid/cmdline" 2>/dev/null | tr '\0' ' ')
        case "$cmdline" in
            *integrity.sh*) kill "$pid" 2>/dev/null ;;
        esac
    fi
    rm -f "$INTEGRITY_PID_FILE" "$INTEGRITY_STATUS_FILE" "$INTEGRITY_MANIFEST_FILE" 2>/dev/null
    rmdir "$STATE_DIR/.integrity_start.lock" 2>/dev/null
}

# ============================================================
# 白名单读取（安全过滤：只允许 [A-Za-z0-9._-]）
# ============================================================
read_whitelist() {
    WHITELIST=""
    [ ! -f "$WHITELIST_FILE" ] && return
    local line
    while IFS= read -r line || [ -n "$line" ]; do
        # 去注释
        line="${line%%#*}"
        line=$(printf '%s' "$line" | tr -d ' \t\r' 2>/dev/null)
        [ -z "$line" ] && continue
        # 安全校验：只允许字母数字 . _ -
        case "$line" in
            *[!A-Za-z0-9._-]*) continue ;;
        esac
        WHITELIST="${WHITELIST}${line}
"
    done < "$WHITELIST_FILE"
}

# 判断模块是否在白名单（用 printf + grep -Fxq，O(1) 命令调用）
is_whitelisted() {
    [ -z "$WHITELIST" ] && return 1
    [ -z "$1" ] && return 1
    printf '%s\n' "$WHITELIST" | grep -Fxq -- "$1" 2>/dev/null
}

# ============================================================
# 命令可用性检测（部分 toybox 精简版不含 timeout/pkill -f 等）
# ============================================================
_HAS_TIMEOUT=""
_check_has_timeout() {
    if [ -z "$_HAS_TIMEOUT" ]; then
        if command -v timeout >/dev/null 2>&1; then
            _HAS_TIMEOUT="1"
        else
            _HAS_TIMEOUT="0"
        fi
    fi
}

# 按 cmdline 子串杀进程，等价于 pkill -f 的最小兜底实现
# 部分设备的 busybox pkill 不支持 -f 选项，改为手动遍历 /proc 匹配 cmdline
_kill_by_cmdline() {
    local pattern="$1" pid cmdline
    for p in /proc/[0-9]*; do
        pid="${p#/proc/}"
        [ -f "$p/cmdline" ] || continue
        cmdline=$(tr '\0' ' ' < "$p/cmdline" 2>/dev/null)
        case "$cmdline" in
            *"$pattern"*) kill -9 "$pid" 2>/dev/null ;;
        esac
    done
}

# 停止当前启动周期中已经运行的目标模块脚本。
# disable 标记主要作用于下一次启动；模块禁用只影响下一次启动；当前启动过程不主动终止其他模块脚本。
_stop_module_script_processes() {
    # v3.4: Script interception was removed. Do not terminate other modules' processes.
    return 0
}

_dd_read_with_timeout() {
    local dev="$1" tmo="${2:-2}"
    _check_has_timeout
    if [ "$_HAS_TIMEOUT" = "1" ]; then
        timeout "$tmo" dd if="$dev" bs=64 count=1 2>/dev/null
        return
    fi
    # 手动超时兜底：后台执行 dd，输出到临时文件，轮询等待或强制终止
    local out="${STATE_DIR:-/data/local/tmp}/.dd_timeout_$$.tmp"
    mkdir -p "${out%/*}" 2>/dev/null
    ( dd if="$dev" bs=64 count=1 2>/dev/null > "$out" ) &
    local dd_pid=$!
    local waited=0
    while [ "$waited" -lt "$tmo" ]; do
        if ! kill -0 "$dd_pid" 2>/dev/null; then
            break
        fi
        sleep 1
        waited=$((waited + 1))
    done
    # 不论是超时还是自然结束，都先尝试 SIGKILL（若仍存活），再 wait 收割僵尸
    # 修复 Issue 1：原先仅在超时分支 kill，dd 在 kill -0 与 sleep 之间自然退出时会留下僵尸
    if kill -0 "$dd_pid" 2>/dev/null; then
        kill -9 "$dd_pid" 2>/dev/null
    fi
    wait "$dd_pid" 2>/dev/null  # 收割僵尸进程，避免子进程残留
    cat "$out" 2>/dev/null
    rm -f "$out" 2>/dev/null
}

# ============================================================
# OTA 检测（覆盖 A/B + BCB + update_engine + recovery）
# ============================================================
# Legacy OTA hints retained for compatibility. The cross-OEM wrapper in
# ota-detection.sh adds last-successful-build comparison and diagnostics.
detect_ota_legacy() {
    # 方法1: 系统属性
    local ota_state
    ota_state=$(getprop sys.ota.update_state 2>/dev/null)
    [ -n "$ota_state" ] && [ "$ota_state" != "0" ] && return 0

    # 方法2: /cache/recovery/command
    if [ -f "/cache/recovery/command" ] && grep -q "update_package" "/cache/recovery/command" 2>/dev/null; then
        return 0
    fi

    # 方法3: A/B BCB (Bootloader Control Block)
    # 兼容多厂商路径：高通 bootdevice、联发科 by-name、平台 platform/*/by-name 变体
    local misc_dev=""
    for p in /dev/block/by-name/misc /dev/block/bootdevice/by-name/misc /dev/block/platform/*/by-name/misc /dev/block/platform/*/*/by-name/misc; do
        if [ -b "$p" ]; then
            misc_dev="$p"
            break
        fi
    done
    if [ -n "$misc_dev" ]; then
        # 优先用 timeout 防止慢速 eMMC 阻塞（Perf-1）；toybox 不保证提供 timeout，
        # 不可用时改用后台 dd + 手动看门狗的方式兜底，避免无限期阻塞启动流程
        if _dd_read_with_timeout "$misc_dev" 2 | strings | grep -q "boot-recovery"; then
            return 0
        fi
    fi

    # 方法4: /metadata/ota 标志
    if [ -f "/metadata/ota" ] || [ -f "/metadata/ota/update" ] || [ -f "/metadata/ota/delta" ]; then
        return 0
    fi

    # 方法5: A/B update_engine（仅当 slot_suffix 非空时才检查）
    local slot_suffix
    slot_suffix=$(getprop ro.boot.slot_suffix 2>/dev/null)
    if [ -n "$slot_suffix" ]; then
        local ue_dir="/data/misc/update_engine/prefs"
        [ -f "$ue_dir/update-engine-running" ] && return 0
        if [ -f "$ue_dir/active-slot" ]; then
            local active_slot cur_slot
            active_slot=$(cat "$ue_dir/active-slot" 2>/dev/null | tr -d '_')
            cur_slot=$(getprop ro.boot.slot_suffix 2>/dev/null | tr -d '_')
            if [ -n "$active_slot" ] && [ -n "$cur_slot" ] && [ "$active_slot" != "$cur_slot" ]; then
                return 0
            fi
        fi
    fi

    # 方法6: recovery last_status
    if [ -f "/cache/recovery/last_status" ] 2>/dev/null; then
        if grep -qE "installing|updating" "/cache/recovery/last_status" 2>/dev/null; then
            return 0
        fi
    fi

    return 1
}

# ============================================================
# 补丁更新检测（v2.4 新增）
# 识别 ColorOS/MIUI/HyperOS/OnePlus/原生 System Update 等上层系统更新
# 与底层 OTA（detect_ota）隔离，互不干扰
# 返回 0=检测到补丁更新 1=未检测到
# ============================================================

# 判断路径是否为“近期”更新痕迹。时钟异常或时间戳过旧都不算更新窗口，
# 避免厂商常驻文件/目录让开机超时被永久拉长。
_patch_path_recent() {
    local path="$1" window="${2:-3600}" now mtime
    [ -e "$path" ] 2>/dev/null || return 1
    now=$(date +%s 2>/dev/null)
    mtime=$(stat -c %Y "$path" 2>/dev/null || stat -f %m "$path" 2>/dev/null || echo 0)
    case "$now" in ''|*[!0-9]*) return 1 ;; esac
    case "$mtime" in ''|*[!0-9]*|0) return 1 ;; esac
    [ "$now" -ge 1577836800 ] 2>/dev/null || return 1
    [ "$mtime" -le "$now" ] 2>/dev/null || return 1
    [ "$((now - mtime))" -lt "$window" ] 2>/dev/null
}

_patch_marker_recent() {
    [ -f "$1" ] 2>/dev/null || return 1
    _patch_path_recent "$1" "${2:-3600}"
}

_patch_dir_has_recent_payload() {
    local dir="$1" entry
    [ -d "$dir" ] 2>/dev/null || return 1
    for entry in "$dir"/*.zip "$dir"/payload.bin; do
        [ -f "$entry" ] 2>/dev/null || continue
        _patch_path_recent "$entry" 3600 && return 0
    done
    return 1
}

_patch_state_active() {
    local lower
    lower=$(printf '%s' "${1:-}" | tr -d ' \t\r\n' | tr '[:upper:]' '[:lower:]')
    case "$lower" in
        ''|0|false|none|unknown|idle|complete|completed|success|successful|failed|failure|error|cancel|cancelled|canceled)
            return 1
            ;;
    esac
    case "$lower" in
        *download*|*install*|*updat*|*verify*|*apply*|*pending*|*running*|*writing*|*prepar*) return 0 ;;
    esac
    return 1
}

_detect_patch_update_legacy() {
    # 优先级 1: 用户/外部工具手动设置的持久标记
    if [ -f "$PATCH_FLAG_FILE" ]; then
        local flag
        flag=$(cat "$PATCH_FLAG_FILE" 2>/dev/null | tr -d ' \t\r\n')
        [ "$flag" = "1" ] && return 0
    fi

    # 优先级 2: ColorOS / OPPO 系统更新
    # 只认“正在更新”的易失状态：常驻的状态文件或空的下载目录不能永久算作补丁窗口，
    # 否则装了模块的 ColorOS 机型每次开机都会被判定为更新中。
    if _patch_marker_recent "/data/oplus/ota/update_status"; then
        return 0
    fi
    if _patch_dir_has_recent_payload "/data/oplus/ota_package"; then
        return 0
    fi
    local oplus_state
    oplus_state=$(getprop sys.ota.update_state 2>/dev/null)
    if _patch_state_active "$oplus_state"; then
        return 0
    fi
    if _patch_state_active "$(getprop sys.oplus.ota.state 2>/dev/null)"; then
        return 0
    fi
    if getprop sys.oppo.update_state 2>/dev/null | grep -qi "updating\|installing"; then
        return 0
    fi

    # 优先级 3: MIUI / HyperOS 系统更新
    # 路径：/data/miui/ota、/cache/miui
    if _patch_marker_recent "/data/miui/ota/update.status"; then
        return 0
    fi
    if _patch_dir_has_recent_payload "/data/miui/ota_package"; then
        return 0
    fi
    if getprop sys.miui.update_state 2>/dev/null | grep -qi "updating\|installing"; then
        return 0
    fi

    # 优先级 4: vivo / OriginOS 系统更新
    if _patch_marker_recent "/data/bbk/ota/update_status"; then
        return 0
    fi
    if getprop sys.vivo.update_state 2>/dev/null | grep -qi "updating\|installing"; then
        return 0
    fi

    # 优先级 5: Samsung One UI 系统更新
    if _patch_marker_recent "/data/system/updates.xml"; then
        return 0
    fi

    # 优先级 6: 通用 Android System Update（Package Installer 上层更新）
    if _patch_marker_recent "/data/ota/last_install" 300; then
        return 0
    fi

    # 优先级 7: /cache 分区下的更新包残留
    if _patch_marker_recent "/cache/update.zip" || _patch_marker_recent "/cache/ota.zip"; then
        return 0
    fi

    return 1
}

# 读取补丁失败计数（独立于普通启动失败计数）
read_patch_fail_count() {
    PATCH_FAIL_COUNT=0
    if [ -f "$PATCH_FAIL_COUNT_FILE" ]; then
        local c
        c=$(cat "$PATCH_FAIL_COUNT_FILE" 2>/dev/null | tr -d ' \t\r\n')
        case "$c" in ''|*[!0-9]*) c=0 ;; esac
        PATCH_FAIL_COUNT=$c
    fi
}

# 写入补丁失败计数
write_patch_fail_count() {
    echo "$1" > "$PATCH_FAIL_COUNT_FILE" 2>/dev/null
    sync "$PATCH_FAIL_COUNT_FILE" 2>/dev/null
}

# 设置补丁更新标记（供 WebUI 调用）
set_patch_flag() {
    mkdir -p "$PATCH_BACKUP_DIR" 2>/dev/null
    local snapshot snapshot_name
    snapshot=$(take_snapshot auto 2>/dev/null)
    if [ -n "$snapshot" ] && [ -f "$snapshot" ]; then
        snapshot_name="snap-patch-$(date +%s)-$$.txt"
        cp "$snapshot" "$PATCH_BACKUP_DIR/$snapshot_name" 2>/dev/null || log "警告：补丁前快照保存失败"
    fi
    echo "1" > "$PATCH_FLAG_FILE" 2>/dev/null
    sync "$PATCH_FLAG_FILE" 2>/dev/null
    log "补丁更新标记已设置（手动）"
    log_rescue_action "PATCH_FLAG_SET" "manual"
}

# 清除补丁更新标记（启动成功后调用）
clear_patch_flag() {
    rm -f "$PATCH_FLAG_FILE" 2>/dev/null
    delete_persisted_state_file "patch_update_flag"
    write_patch_fail_count 0
    log "补丁更新标记已清除（启动成功）"
}

manual_clear_patch_flag() {
    clear_patch_flag
    log_rescue_action "PATCH_FLAG_CLEAR" "manual"
}

# ============================================================
# WebUI 手动入口与安全写入
# ============================================================

_write_file_atomic() {
    local target="$1"
    local content="$2"
    [ -z "$target" ] && return 1
    mkdir -p "${target%/*}" 2>/dev/null
    local tmp="${target}.tmp.$$"
    printf '%s' "$content" > "$tmp" 2>/dev/null || return 1
    sync "$tmp" 2>/dev/null
    mv -f "$tmp" "$target" 2>/dev/null || return 1
    return 0
}

_normalize_safe_dir() {
    local dir="$1"
    [ -z "$dir" ] && return 1
    case "$dir" in
        */) printf '%s' "${dir%/}" ;;
        *) printf '%s' "$dir" ;;
    esac
}

_is_safe_custom_dir_legacy() {
    local dir normalized prefix norm_prefix
    dir="$1"
    [ -z "$dir" ] && return 1
    case "$dir" in
        /*) ;;
        *) return 1 ;;
    esac
    case "$dir" in
        *".."*|*"*"*|*"?"*|*"["*|*"]"*|*" "*|*"\t"*) return 1 ;;
    esac

    normalized=$(_normalize_safe_dir "$dir") || return 1
    for prefix in $SAFE_CUSTOM_DIR_PREFIXES; do
        norm_prefix=$(_normalize_safe_dir "$prefix") || continue
        [ "$normalized" = "$norm_prefix" ] && return 0
        case "$normalized" in
            "$norm_prefix"/*) return 0 ;;
        esac
    done
    return 1
}

save_custom_dirs_file() {
    local input_file="$1"
    [ -z "$input_file" ] || [ ! -f "$input_file" ] && return 1

    local line dir perm normalized safe_count=0 reject_count=0
    local tmp_content="$STATE_DIR/.custom_dirs.content.$$"
    : > "$tmp_content" 2>/dev/null || return 1
    while IFS= read -r line || [ -n "$line" ]; do
        [ -z "$line" ] && continue
        dir=$(printf '%s' "$line" | awk '{print $1}')
        perm=$(printf '%s' "$line" | awk '{print $2}')
        [ -z "$dir" ] || [ -z "$perm" ] && { reject_count=$((reject_count + 1)); continue; }
        case "$perm" in 700|750|755|770) ;; *) reject_count=$((reject_count + 1)); continue ;; esac
        if is_safe_custom_dir "$dir"; then
            normalized=$(_normalize_safe_dir "$dir")
            printf '%s %s\n' "$normalized" "$perm" >> "$tmp_content"
            safe_count=$((safe_count + 1))
        else
            reject_count=$((reject_count + 1))
        fi
    done < "$input_file"

    if _write_file_atomic "$STATE_DIR/custom_dirs.conf" "$(cat "$tmp_content" 2>/dev/null)"; then
        chmod 0600 "$STATE_DIR/custom_dirs.conf" 2>/dev/null
        log_rescue_action "CUSTOM_DIRS_SAVE" "saved=$safe_count,rejected=$reject_count"
        rm -f "$tmp_content" 2>/dev/null
        printf 'SAVED=%s\nREJECTED=%s\n' "$safe_count" "$reject_count"
        return 0
    fi
    rm -f "$tmp_content" 2>/dev/null
    return 1
}

clear_suspect_log() {
    : > "$SUSPECT_LOG" 2>/dev/null || return 1
    chmod 0600 "$SUSPECT_LOG" 2>/dev/null
    log_rescue_action "SUSPECT_LOG_CLEAR" "manual"
    return 0
}

_list_current_module_ids() {
    local base mod_id mod_dir
    for base in "$MODULE_BASE" "$MODULE_BASE_KSU" "$MODULE_BASE_AP"; do
        [ -z "$base" ] || [ ! -d "$base" ] && continue
        for mod_dir in "$base"/*/; do
            [ ! -d "$mod_dir" ] && continue
            mod_id=$(basename "$mod_dir")
            [ "$mod_id" = "$SELF_ID" ] && continue
            [ -f "${mod_dir}remove" ] && continue
            case "$mod_id" in *[!A-Za-z0-9._-]*) continue ;; esac
            printf '%s\n' "$mod_id"
        done
    done
}

prune_suspect_log() {
    [ -f "$SUSPECT_LOG" ] || return 0

    local current_file="${STATE_DIR}/.current_modules.$$"
    local tmp_log="${SUSPECT_LOG}.tmp.$$"
    local line mod_id kept=0 removed=0

    _list_current_module_ids | sort -u > "$current_file" 2>/dev/null
    : > "$tmp_log" 2>/dev/null || {
        rm -f "$current_file" 2>/dev/null
        return 1
    }

    while IFS= read -r line || [ -n "$line" ]; do
        [ -z "$line" ] && continue
        case "$line" in
            \#*) continue ;;
            \?*) mod_id="${line#\?}" ;;
            +*) mod_id="${line#+}" ;;
            :*) mod_id="${line#:}" ;;
            *) mod_id="$line" ;;
        esac
        case "$mod_id" in ''|*[!A-Za-z0-9._-]*) removed=$((removed + 1)); continue ;; esac
        if grep -qx "$mod_id" "$current_file" 2>/dev/null; then
            printf '%s\n' "$line" >> "$tmp_log"
            kept=$((kept + 1))
        else
            removed=$((removed + 1))
            log "移除过期嫌疑记录: $mod_id"
        fi
    done < "$SUSPECT_LOG"

    mv -f "$tmp_log" "$SUSPECT_LOG"
    chmod 0600 "$SUSPECT_LOG" 2>/dev/null
    rm -f "$current_file" 2>/dev/null
    [ "$removed" -gt 0 ] && log_rescue_action "SUSPECT_LOG_PRUNE" "kept=$kept,removed=$removed"
    return 0
}

reset_rescue_level_state() {
    write_rescue_level 0
    log_rescue_action "RESCUE_LEVEL_RESET" "manual"
    return 0
}

manual_save_good_modules() {
    save_good_modules || return 1
    local enabled_count=0
    if [ -f "$GOOD_MODULES_FILE" ]; then
        enabled_count=$(grep -cv '^:' "$GOOD_MODULES_FILE" 2>/dev/null || echo 0)
    fi
    log_rescue_action "GOOD_MODULES_SAVE" "manual,enabled=$enabled_count"
    printf '%s\n' "$enabled_count"
    return 0
}

manual_unfreeze_apps() {
    app_unfreeze
    printf '%s\n' "${APP_UNFREEZE_LAST_RESULT:-SKIP}"
    return 0
}

manual_take_snapshot() {
    local mode="${1:-manual}"
    local snap
    snap=$(take_snapshot "$mode") || return 1
    case "$mode" in
        auto) log_rescue_action "AUTO_SNAPSHOT_SAVE" "$(basename "$snap")" ;;
        *) log_rescue_action "SNAPSHOT_SAVE" "$(basename "$snap")" ;;
    esac
    printf '%s\n' "$snap"
    return 0
}

get_manual_snapshot_limit() {
    local limit="${MAX_MANUAL_SNAPSHOTS:-12}"
    case "$limit" in ''|*[!0-9]*) limit=12 ;; esac
    [ "$limit" -lt 1 ] 2>/dev/null && limit=1
    echo "$limit"
}

prune_manual_snapshots_in_dir() {
    local dir="$1"
    local limit count snap
    [ -d "$dir" ] || return 0
    limit=$(get_manual_snapshot_limit)
    count=0
    for snap in $(ls -1 "$dir"/snap-*.txt 2>/dev/null | sort -r); do
        [ -f "$snap" ] || continue
        count=$((count + 1))
        if [ "$count" -gt "$limit" ]; then
            rm -f "$snap" 2>/dev/null
        fi
    done
    return 0
}

is_legacy_auto_snapshot_file() {
    local snap_file="$1"
    [ -f "$snap_file" ] || return 1
    grep -q '^# 类型: auto$' "$snap_file" 2>/dev/null
}

delete_persisted_state_file() {
    local file_name="$1"
    [ -n "$file_name" ] || return 0
    [ -d "$PERSIST_DIR" ] || return 0
    rm -f "$PERSIST_DIR/$file_name" 2>/dev/null
    return 0
}

sync_removable_persist_state_files() {
    local file_name
    for file_name in patch_update_flag rescued_disabled.list auto_snapshot_session; do
        [ -f "$STATE_DIR/$file_name" ] && continue
        delete_persisted_state_file "$file_name"
    done
    return 0
}

_sync_persist_snapshot_dir() {
    local persisted snap_name
    [ -d "$PERSIST_DIR/snapshots" ] || return 0
    for persisted in "$PERSIST_DIR/snapshots"/snap-*.txt "$PERSIST_DIR/snapshots"/auto-snap-*.txt; do
        [ -f "$persisted" ] || continue
        snap_name=$(basename "$persisted")
        [ -f "$SNAPSHOT_DIR/$snap_name" ] && continue
        rm -f "$persisted" 2>/dev/null
    done
    return 0
}

delete_persisted_snapshot() {
    local snap_name="$1"
    [ -n "$snap_name" ] || return 0
    [ -d "$PERSIST_DIR/snapshots" ] || return 0
    rm -f "$PERSIST_DIR/snapshots/$snap_name" 2>/dev/null
    return 0
}

normalize_snapshot_storage() {
    local snap latest_legacy_auto=""
    [ -d "$SNAPSHOT_DIR" ] || return 0

    for snap in $(ls -1 "$SNAPSHOT_DIR"/snap-*.txt 2>/dev/null | sort -r); do
        [ -f "$snap" ] || continue
        if is_legacy_auto_snapshot_file "$snap"; then
            [ -n "$latest_legacy_auto" ] || latest_legacy_auto="$snap"
        fi
    done

    if [ -n "$latest_legacy_auto" ] && [ ! -f "$AUTO_SNAPSHOT_FILE" ]; then
        mv -f "$latest_legacy_auto" "$AUTO_SNAPSHOT_FILE" 2>/dev/null
        chmod 0600 "$AUTO_SNAPSHOT_FILE" 2>/dev/null
    fi

    for snap in $(ls -1 "$SNAPSHOT_DIR"/snap-*.txt 2>/dev/null | sort -r); do
        [ -f "$snap" ] || continue
        is_legacy_auto_snapshot_file "$snap" && rm -f "$snap" 2>/dev/null
    done
    return 0
}

get_auto_snapshot_session_key() {
    local boot_start=0 uptime_start=0 last_result=""
    local k v
    if [ -f "$STATUS_FILE" ]; then
        while IFS='=' read -r k v || [ -n "$k$v" ]; do
            [ -z "$k" ] && continue
            case "$k" in
                BOOT_START) boot_start="$v" ;;
                UPTIME_START) uptime_start="$v" ;;
                LAST_BOOT_RESULT) last_result="$v" ;;
            esac
        done < "$STATUS_FILE"
    fi
    case "$boot_start" in ''|*[!0-9]*) boot_start=0 ;; esac
    case "$uptime_start" in ''|*[!0-9]*) uptime_start=0 ;; esac

    if [ "$boot_start" -gt 0 ] 2>/dev/null; then
        echo "boot:$boot_start"
        return 0
    fi
    if [ "$uptime_start" -gt 0 ] 2>/dev/null; then
        echo "uptime:$uptime_start"
        return 0
    fi
    if [ -n "$last_result" ]; then
        echo "result:$last_result"
        return 0
    fi
    echo "uptime:$(get_uptime_sec)"
}

auto_snapshot_already_taken() {
    local session_key existing_key
    [ -f "$AUTO_SNAPSHOT_FILE" ] || return 1
    [ -f "$AUTO_SNAPSHOT_SESSION_FILE" ] || return 1
    session_key=$(get_auto_snapshot_session_key)
    existing_key=$(cat "$AUTO_SNAPSHOT_SESSION_FILE" 2>/dev/null)
    [ -n "$session_key" ] || return 1
    [ "$existing_key" = "$session_key" ]
}

write_auto_snapshot_session() {
    local session_key="$1"
    [ -n "$session_key" ] || return 1
    printf '%s\n' "$session_key" > "$AUTO_SNAPSHOT_SESSION_FILE" 2>/dev/null || return 1
    chmod 0600 "$AUTO_SNAPSHOT_SESSION_FILE" 2>/dev/null
    return 0
}

manual_restore_snapshot() {
    local snap_file="$1"
    case "$snap_file" in
        "$SNAPSHOT_DIR"/snap-*.txt|"$AUTO_SNAPSHOT_FILE") ;;
        *) return 1 ;;
    esac
    restore_snapshot "$snap_file" || return 1
    log_rescue_action "SNAPSHOT_RESTORE" "$(basename "$snap_file")"
    printf 'OK\n'
    return 0
}

manual_delete_snapshot() {
    local snap_file="$1"
    case "$snap_file" in
        "$SNAPSHOT_DIR"/snap-*.txt) ;;
        *) return 1 ;;
    esac
    delete_snapshot "$snap_file"
    log_rescue_action "SNAPSHOT_DELETE" "$(basename "$snap_file")"
    printf 'OK\n'
    return 0
}

manual_restore_good_modules_baseline() {
    restore_good_modules_baseline
}

manual_generate_rescue_decision_report() {
    generate_rescue_decision_report
}

send_root_notification() {
    local title="$1"
    local text="$2"
    [ -z "$title" ] && return 1
    [ -z "$text" ] && return 1
    command -v cmd >/dev/null 2>&1 || return 1
    cmd notification post -S bigtext -t "$title" RescueX "$text" >/dev/null 2>&1 && return 0
    cmd notification post -t "$title" RescueX "$text" >/dev/null 2>&1 && return 0
    return 1
}

_disable_module_by_dir() {
    local module_dir="$1"
    [ -d "$module_dir" ] || return 1
    local module_id module_base shadow_dir
    module_id=$(basename "${module_dir%/}")
    disable_module_at_dir "$module_dir" "$module_id" || return 1

    # Some managers keep an implementation shadow; mark it disabled too, but never chmod or move scripts.
    module_base=${module_dir%/*}
    shadow_dir="$module_base/.$module_id"
    if [ -d "$shadow_dir" ]; then
        touch "$shadow_dir/disable" 2>/dev/null || return 1
        [ -f "$shadow_dir/disable" ] || return 1
        log "已同步禁用模块隐藏副本: $shadow_dir"
    fi
    return 0
}

_patch_rollback_unsafe_legacy() {
    log "===== 触发补丁回滚（轻量级）====="

    # 策略 1: 如果存在补丁前快照，恢复模块状态（不动用户数据）
    if [ -d "$PATCH_BACKUP_DIR" ]; then
        local snap
        snap=$(ls -t "$PATCH_BACKUP_DIR"/snap-*.txt 2>/dev/null | head -1)
        if [ -n "$snap" ] && [ -f "$snap" ]; then
            log "找到补丁前快照: $(basename "$snap")，恢复模块状态"
            restore_snapshot "$snap"
            log "补丁回滚完成（模块状态已恢复，用户数据保留）"
            # 清除补丁标记和失败计数
            clear_patch_flag
            return 0
        fi
    fi

    # 策略 2: 无快照时，仅禁用最近安装的非白名单模块（渐进式）
    log "无补丁前快照，执行渐进式禁用最近模块"
    read_whitelist
    progressive_rescue 5

    # 清除补丁标记，避免循环
    clear_patch_flag
    log "补丁回滚完成（已禁用最近模块，用户数据保留）"
    return 0
}

# ============================================================
# 启动失败判定
# ============================================================

# Conservative failure evidence: BOOT_TOKEN identifies a new kernel boot but
# cannot identify why the prior BOOTING transaction ended. Root-manager updates,
# OTA handoffs, user reboots, and module overlays can all change the token.
# Keep it for observability/ownership checks; require explicit FAILURE or the
# legacy valid-RTC grace-window evidence before counting a rescue failure.
is_real_boot_failure() {
    [ "$PREV_BOOT_RESULT" = "INIT" ] && return 1
    [ "$PREV_BOOT_RESULT" = "RESCUED" ] && return 1
    if [ "$PREV_BOOT_RESULT" = "FAILURE" ] || [ "$PREV_BOOT_RESULT" = "TEST_FAILURE" ]; then
        log "上一轮状态明确标记为 $PREV_BOOT_RESULT，计为真实失败"
        return 0
    fi
    [ "$PREV_BOOT_END" != "0" ] && return 1
    [ "$PREV_BOOT_START" = "0" ] && return 1

    local now elapsed
    now=$(get_valid_epoch)
    [ "$now" -gt 0 ] || {
        log "墙上时钟未就绪，保守不计失败（BOOT_TOKEN 仅作日志证据）"
        return 1
    }
    case "$PREV_BOOT_START" in ''|*[!0-9]*) return 1 ;; esac
    elapsed=$((now - PREV_BOOT_START))
    if [ "$elapsed" -lt 0 ] || [ "$elapsed" -gt 604800 ]; then
        log "墙上时钟异常（elapsed=$elapsed），保守不计失败"
        return 1
    fi
    if [ "$elapsed" -le "$USER_REBOOT_GRACE_SEC" ]; then
        log "上一轮仅 $elapsed 秒，疑似用户主动重启，不计入失败"
        return 1
    fi
    log "上一轮未完成且已超过用户重启宽限期（elapsed=${elapsed}s），计为真实失败"
    return 0
}

# ============================================================
# 状态文件原子写入
# ============================================================

# 全量写入状态（用于 post-fs-data 初始化）
# 参数: <result> <fail_count> <ota_detected> <service_started> <rescue_count> <last_rescue_time> [boot_start] [uptime_start] [patch_detected]
write_status() {
    local result="${1:-UNKNOWN}"
    local fail_count="${2:-0}"
    local ota_detected="${3:-false}"
    local service_started="${4:-0}"
    local rescue_count="${5:-0}"
    local last_rescue_time="${6:-0}"
    local boot_start="${7:-$(get_valid_epoch)}"
    local uptime_start="${8:-0}"
    local patch_detected="${9:-false}"
    local boot_token="${BOOT_TOKEN:-$(get_boot_token)}"

    mkdir -p "${STATUS_FILE%/*}" 2>/dev/null

    # 用 PID 后缀避免多进程并发写同一个临时文件
    # PATCH_DETECTED 现作为标准字段随主状态一起原子写入，不再靠事后 grep+append
    # 追加（那样会在 watchdog.sh 的 2 秒轮询窗口内造成短暂的状态不一致）
    local tmp="${STATUS_TMP}.$$"
    cat > "$tmp" << STATUS
BOOT_START=$boot_start
BOOT_TOKEN=$boot_token
BOOT_END=0
SERVICE_STARTED=$service_started
FAIL_COUNT=$fail_count
LAST_BOOT_RESULT=$result
OTA_DETECTED=$ota_detected
RESCUE_COUNT=$rescue_count
LAST_RESCUE_TIME=$last_rescue_time
BOOT_DURATION=0
UPTIME_START=$uptime_start
UPTIME_END=0
PATCH_DETECTED=$patch_detected
STATUS

    sync "$tmp" 2>/dev/null
    mv "$tmp" "$STATUS_FILE"
    # SEC-005: 运行时创建的文件显式设置权限
    chmod 0600 "$STATUS_FILE" 2>/dev/null
    _write_status_json "$boot_start" 0 "$service_started" "$fail_count" "$result" "$ota_detected" "$rescue_count" "$last_rescue_time" 0 "$uptime_start" 0 "$patch_detected" "$boot_token"

    # 记录历史
    append_boot_history "[$(get_log_time)] START | boot=$boot_token | fail=$fail_count | ota=$ota_detected | result=$result" || log "警告：启动 START 历史写入失败"

    # v2.7.0: 同步到持久目录
    sync_to_persist
}

# 增量更新状态（用于 service.sh 标记成功，保留其他字段）
# 参数: <boot_end> <service_started> <result> <fail_count> [uptime_end]
# boot_duration 由 uptime_end - uptime_start 计算（不依赖 RTC）
update_status_fields() {
    local boot_end="${1:-0}"
    local service_started="${2:-0}"
    local result="${3:-SUCCESS}"
    local fail_count="${4:-0}"
    local uptime_end="${5:-0}"
    local expected_token="${6:-}"
    local current_result="UNKNOWN"

    # 读取现有字段（含 PATCH_DETECTED，本函数不改变补丁检测状态，只是原样保留）
    local boot_start=0 boot_token="" ota_detected=false rescue_count=0 last_rescue_time=0 uptime_start=0 patch_detected=false
    if [ -f "$STATUS_FILE" ]; then
        local k v
        while IFS='=' read -r k v; do
            [ -z "$k" ] && continue
            case "$k" in
                BOOT_START) boot_start="$v" ;;
                BOOT_TOKEN) boot_token="$v" ;;
                LAST_BOOT_RESULT) current_result="$v" ;;
                OTA_DETECTED) ota_detected="$v" ;;
                RESCUE_COUNT) rescue_count="$v" ;;
                LAST_RESCUE_TIME) last_rescue_time="$v" ;;
                UPTIME_START) uptime_start="$v" ;;
                PATCH_DETECTED) patch_detected="$v" ;;
            esac
        done < "$STATUS_FILE"
    fi

    case "$boot_start" in ''|*[!0-9]*) boot_start=0 ;; esac
    [ -n "$boot_token" ] || boot_token=$(get_boot_token)
    if [ -n "$expected_token" ] && [ -n "$boot_token" ] && [ "$expected_token" != "$boot_token" ]; then
        log "拒绝提交启动成功：BOOT_TOKEN 已变化（旧=$expected_token 新=$boot_token）"
        return 2
    fi
    if [ "$result" = SUCCESS ] && [ "$current_result" != BOOTING ]; then
        log "拒绝提交启动成功：当前状态已是 $current_result，避免覆盖外部失败/救砖结果"
        return 3
    fi
    case "$rescue_count" in ''|*[!0-9]*) rescue_count=0 ;; esac
    case "$last_rescue_time" in ''|*[!0-9]*) last_rescue_time=0 ;; esac
    case "$uptime_start" in ''|*[!0-9]*) uptime_start=0 ;; esac
    case "$uptime_end" in ''|*[!0-9]*) uptime_end=0 ;; esac

    # 用 uptime 计算真实启动耗时（不依赖 RTC，即使时钟是 1971 年也准确）
    local boot_duration=0
    if [ "$uptime_start" -gt 0 ] && [ "$uptime_end" -gt 0 ] && [ "$uptime_end" -ge "$uptime_start" ]; then
        boot_duration=$((uptime_end - uptime_start))
        # 合理性校验：5 秒 ~ 1 小时
        if [ "$boot_duration" -lt 5 ] || [ "$boot_duration" -gt 3600 ]; then
            boot_duration=0
        fi
    fi

    # 用 PID 后缀避免多进程并发写同一个临时文件
    local tmp="${STATUS_TMP}.$$"
    cat > "$tmp" << STATUS
BOOT_START=$boot_start
BOOT_TOKEN=$boot_token
BOOT_END=$boot_end
SERVICE_STARTED=$service_started
FAIL_COUNT=$fail_count
LAST_BOOT_RESULT=$result
OTA_DETECTED=$ota_detected
RESCUE_COUNT=$rescue_count
LAST_RESCUE_TIME=$last_rescue_time
BOOT_DURATION=$boot_duration
UPTIME_START=$uptime_start
UPTIME_END=$uptime_end
PATCH_DETECTED=$patch_detected
STATUS

    sync "$tmp" 2>/dev/null
    mv "$tmp" "$STATUS_FILE"
    # SEC-005: 运行时创建的文件显式设置权限
    chmod 0600 "$STATUS_FILE" 2>/dev/null

    _write_status_json "$boot_start" "$boot_end" "$service_started" "$fail_count" "$result" "$ota_detected" "$rescue_count" "$last_rescue_time" "$boot_duration" "$uptime_start" "$uptime_end" "$patch_detected" "$boot_token"
}

# 内部：写 JSON 状态
# SEC-004: 归一化布尔字段（确保 JSON 中为 true/false 而非 True/False/1/0）
_write_status_json() {
    local boot_start="$1" boot_end="$2" service_started="$3" fail_count="$4"
    local result="$5" ota_detected="$6" rescue_count="$7" last_rescue_time="$8" boot_duration="$9"
    local uptime_start="${10}" uptime_end="${11}" patch_detected="${12:-false}" boot_token="${13:-$(get_boot_token)}"
    # SEC-004: 归一化布尔字段（确保 JSON 中为 true/false 而非 True/False/1/0）
    case "$ota_detected" in true|1|yes) ota_detected=true ;; *) ota_detected=false ;; esac
    case "$patch_detected" in true|1|yes) patch_detected=true ;; *) patch_detected=false ;; esac
    # 同步到持久目录
    sync_to_persist
    local jtmp="${JSON_FILE}.tmp.$$"
    cat > "$jtmp" << JSON
{
  "boot_start": $boot_start,
  "boot_token": "$boot_token",
  "boot_end": $boot_end,
  "service_started": $service_started,
  "fail_count": $fail_count,
  "last_boot_result": "$result",
  "ota_detected": $ota_detected,
  "rescue_count": $rescue_count,
  "last_rescue_time": $last_rescue_time,
  "boot_duration": $boot_duration,
  "uptime_start": $uptime_start,
  "uptime_end": $uptime_end,
  "patch_detected": $patch_detected,
  "updated_at": "$(get_log_time)"
}
JSON
    sync "$jtmp" 2>/dev/null
    mv "$jtmp" "$JSON_FILE"
    # SEC-005: 运行时创建的文件显式设置权限
    chmod 0600 "$JSON_FILE" 2>/dev/null
}

# 内部：截断历史文件到 100 行
_truncate_history() {
    local lc
    lc=$(wc -l < "$HISTORY_FILE" 2>/dev/null || echo 0)
    case "$lc" in ''|*[!0-9]*) lc=0 ;; esac
    if [ "$lc" -gt 100 ]; then
        tail -n 100 "$HISTORY_FILE" > "${HISTORY_FILE}.tmp"
        mv "${HISTORY_FILE}.tmp" "$HISTORY_FILE"
    fi
}

append_boot_history() {
    local line="$1" lock="${HISTORY_FILE}.lock" i=0
    mkdir -p "${HISTORY_FILE%/*}" 2>/dev/null || return 1
    while ! mkdir "$lock" 2>/dev/null; do
        i=$((i + 1)); [ "$i" -ge 10 ] && return 1
        sleep 1
    done
    printf '%s\n' "$line" >> "$HISTORY_FILE" 2>/dev/null || { rmdir "$lock" 2>/dev/null; return 1; }
    _truncate_history
    rmdir "$lock" 2>/dev/null
    return 0
}

# 读取上次状态（填充 PREV_* 变量）
read_previous_status() {
    PREV_BOOT_START=0
    PREV_BOOT_END=0
    PREV_SERVICE_STARTED=0
    PREV_FAIL_COUNT=0
    PREV_BOOT_RESULT="UNKNOWN"
    PREV_OTA_DETECTED="false"
    PREV_RESCUE_COUNT=0
    PREV_LAST_RESCUE_TIME=0
    PREV_PATCH_DETECTED="false"
    PREV_BOOT_TOKEN=""

    [ ! -f "$STATUS_FILE" ] && return

    local k v
    while IFS='=' read -r k v; do
        [ -z "$k" ] && continue
        case "$k" in
            BOOT_START) PREV_BOOT_START="$v" ;;
            BOOT_END) PREV_BOOT_END="$v" ;;
            SERVICE_STARTED) PREV_SERVICE_STARTED="$v" ;;
            FAIL_COUNT) PREV_FAIL_COUNT="$v" ;;
            LAST_BOOT_RESULT) PREV_BOOT_RESULT="$v" ;;
            OTA_DETECTED) PREV_OTA_DETECTED="$v" ;;
            RESCUE_COUNT) PREV_RESCUE_COUNT="$v" ;;
            LAST_RESCUE_TIME) PREV_LAST_RESCUE_TIME="$v" ;;
            PATCH_DETECTED) PREV_PATCH_DETECTED="$v" ;;
            BOOT_TOKEN) PREV_BOOT_TOKEN="$v" ;;
        esac
    done < "$STATUS_FILE"

    case "$PREV_FAIL_COUNT" in ''|*[!0-9]*) PREV_FAIL_COUNT=0 ;; esac
    case "$PREV_BOOT_START" in ''|*[!0-9]*) PREV_BOOT_START=0 ;; esac
    case "$PREV_BOOT_END" in ''|*[!0-9]*) PREV_BOOT_END=0 ;; esac
    case "$PREV_SERVICE_STARTED" in ''|*[!0-9]*) PREV_SERVICE_STARTED=0 ;; esac
    case "$PREV_RESCUE_COUNT" in ''|*[!0-9]*) PREV_RESCUE_COUNT=0 ;; esac
    case "$PREV_LAST_RESCUE_TIME" in ''|*[!0-9]*) PREV_LAST_RESCUE_TIME=0 ;; esac
}

# 读取当前状态（填充无 PREV_ 前缀的字段，供 WebUI 报告使用）
read_status() {
    BOOT_START=0
    BOOT_END=0
    SERVICE_STARTED=0
    FAIL_COUNT=0
    BOOT_RESULT="UNKNOWN"
    OTA_DETECTED="false"
    RESCUE_COUNT=0
    LAST_RESCUE_TIME=0
    BOOT_DURATION=0
    UPTIME_START=0
    UPTIME_END=0
    PATCH_DETECTED="false"
    BOOT_TOKEN=""

    [ -f "$STATUS_FILE" ] || return 0

    local k v
    while IFS='=' read -r k v || [ -n "$k$v" ]; do
        [ -z "$k" ] && continue
        case "$k" in
            BOOT_START) BOOT_START="$v" ;;
            BOOT_END) BOOT_END="$v" ;;
            SERVICE_STARTED) SERVICE_STARTED="$v" ;;
            FAIL_COUNT) FAIL_COUNT="$v" ;;
            LAST_BOOT_RESULT) BOOT_RESULT="$v" ;;
            OTA_DETECTED) OTA_DETECTED="$v" ;;
            RESCUE_COUNT) RESCUE_COUNT="$v" ;;
            LAST_RESCUE_TIME) LAST_RESCUE_TIME="$v" ;;
            BOOT_DURATION) BOOT_DURATION="$v" ;;
            UPTIME_START) UPTIME_START="$v" ;;
            UPTIME_END) UPTIME_END="$v" ;;
            PATCH_DETECTED) PATCH_DETECTED="$v" ;;
            BOOT_TOKEN) BOOT_TOKEN="$v" ;;
        esac
    done < "$STATUS_FILE"

    case "$BOOT_START" in ''|*[!0-9]*) BOOT_START=0 ;; esac
    case "$BOOT_END" in ''|*[!0-9]*) BOOT_END=0 ;; esac
    case "$SERVICE_STARTED" in ''|*[!0-9]*) SERVICE_STARTED=0 ;; esac
    case "$FAIL_COUNT" in ''|*[!0-9]*) FAIL_COUNT=0 ;; esac
    case "$RESCUE_COUNT" in ''|*[!0-9]*) RESCUE_COUNT=0 ;; esac
    case "$LAST_RESCUE_TIME" in ''|*[!0-9]*) LAST_RESCUE_TIME=0 ;; esac
    case "$BOOT_DURATION" in ''|*[!0-9]*) BOOT_DURATION=0 ;; esac
    case "$UPTIME_START" in ''|*[!0-9]*) UPTIME_START=0 ;; esac
    case "$UPTIME_END" in ''|*[!0-9]*) UPTIME_END=0 ;; esac
}

# 修正 post-fs-data 阶段因 NTP 未同步导致 LAST_RESCUE_TIME 为 1971 年异常值的问题
# 在 post-fs-data 和 service.sh 中均会调用（双保险）
# 仅当时钟已恢复正常时才执行修正，确保不引入错误值
fix_last_rescue_time() {
    local now lrt rc
    now=$(date +%s 2>/dev/null)
    case "$now" in ''|*[!0-9]*) return ;; esac
    [ "$now" -le 1577836800 ] && return

    if [ ! -f "$STATUS_FILE" ]; then return; fi
    lrt=$(grep "^LAST_RESCUE_TIME=" "$STATUS_FILE" 2>/dev/null | cut -d= -f2)
    case "$lrt" in ''|*[!0-9]*) return ;; esac

    # v3.5.10-r2: 早期 RTC 未同步时 commit_verified_rescue 写入 0。
    # 若确实发生过救砖（RESCUE_COUNT>0），0 表示"时间未知"而非"从未"，
    # 此时修正为当前时间（近似），避免 WebUI 显示"从未救砖"。
    if [ "$lrt" -eq 0 ]; then
        rc=$(grep "^RESCUE_COUNT=" "$STATUS_FILE" 2>/dev/null | cut -d= -f2)
        case "$rc" in ''|*[!0-9]*) rc=0 ;; esac
        [ "$rc" -gt 0 ] || return
        log "已修正 LAST_RESCUE_TIME: 0（已救砖 $rc 次，早期时钟未同步）→ $now"
    elif [ "$lrt" -ge 1577836800 ]; then
        return
    fi

    local tmp="${STATUS_TMP}.$$"
    while IFS='=' read -r k v; do
        [ -z "$k" ] && continue
        [ "$k" = "LAST_RESCUE_TIME" ] && echo "LAST_RESCUE_TIME=$now" || echo "$k=$v"
    done < "$STATUS_FILE" > "$tmp"
    sync "$tmp" 2>/dev/null
    mv "$tmp" "$STATUS_FILE"
    chmod 0600 "$STATUS_FILE" 2>/dev/null
    log "已修正 LAST_RESCUE_TIME: ${lrt:-0} → $now"
}

# ============================================================
# 模块操作
# ============================================================

# 统一写入 Root 管理器使用的 disable 标记。
# 所有自动救砖和手动操作都必须通过这里确认实际写入成功。
disable_module_at_dir() {
    local mod_dir="$1"
    local mod_id="$2"
    [ -n "$mod_dir" ] || return 1
    [ -d "$mod_dir" ] || return 1
    [ -n "$mod_id" ] || mod_id=$(basename "${mod_dir%/}")
    case "$mod_id" in ''|*[!A-Za-z0-9._-]*) return 1 ;; esac
    [ "$mod_id" = "$SELF_ID" ] && return 1
    [ -f "${mod_dir%/}/disable" ] && return 2
    touch "${mod_dir%/}/disable" 2>/dev/null || return 1
    [ -f "${mod_dir%/}/disable" ] || return 1
    return 0
}

# 禁用单个模块（考虑白名单 + DRY_RUN）
# 返回: 0=成功 1=参数错误 2=白名单 3=已禁用
disable_module_safe() {
    local mod_dir="$1" mod_id="$2" base manager started=false
    [ -z "$mod_dir" ] || [ -z "$mod_id" ] && return 1
    [ "$mod_id" = "$SELF_ID" ] && return 1
    is_whitelisted "$mod_id" && return 2
    [ -f "${mod_dir%/}/disable" ] && return 3

    if [ "$DRY_RUN" = "true" ]; then
        log "[DRY_RUN] 将禁用: $mod_id"
        return 0
    fi
    for base in "$MODULE_BASE" "$MODULE_BASE_KSU" "$MODULE_BASE_AP"; do
        [ -n "$base" ] && [ "$mod_dir" = "$base/$mod_id" -o "$mod_dir" = "$base/$mod_id/" ] && { manager=$(rescue_manager_for_base "$base") || return 1; break; }
    done
    [ -n "${manager:-}" ] || return 1
    if [ -z "${RESCUE_TRANSACTION_PATH:-}" ]; then
        rescue_transaction_begin_targets SUSPECT_DISABLE || return 1
        started=true
    fi
    if rescue_transaction_disable_target "$manager" "$base" "$mod_id" "${mod_dir%/}"; then
        [ "$started" = true ] && rescue_transaction_finish_targets || true
        return 0
    fi
    log "禁用失败: $mod_id"
    return 1
}

# 注意：reenable_all 内联了恢复逻辑，不再调用此函数
# 保留定义供未来使用
_enable_module_safe() {
    local mod_dir="$1"
    local mod_id="$2"
    [ -z "$mod_dir" ] || [ -z "$mod_id" ] && return 1
    [ "$mod_id" = "$SELF_ID" ] && return 1
    [ ! -f "${mod_dir}disable" ] && return 3
    if rm -f "${mod_dir}disable" 2>/dev/null; then
        log "已恢复: $mod_id"
        return 0
    fi
    log "恢复失败: $mod_id"
    return 1
}

# 渐进式救砖：禁用最近安装的 N 个模块（用 ls -t 替代 stat+sort，可移植）
progressive_rescue() {
    local count="${1:-3}"
    case "$count" in ''|*[!0-9]*) count=3 ;; esac
    [ "$count" -lt 1 ] 2>/dev/null && count=1
    [ "$count" -gt 20 ] 2>/dev/null && count=20

    read_whitelist  # 确保白名单已加载
    log "渐进式救砖：禁用最近 $count 个模块"

    # v2.7.0: 救砖前自动拍快照
    local auto_snap
    auto_snap=$(take_snapshot auto)
    [ -n "$auto_snap" ] && log "救砖前自动快照: $(basename "$auto_snap")"

    local disabled=0
    local base mod_id mod_dir modules manager
    if [ "$DRY_RUN" != true ]; then rescue_transaction_begin_targets PROGRESSIVE_RESCUE || return 1; fi
    for base in "$MODULE_BASE" "$MODULE_BASE_KSU" "$MODULE_BASE_AP"; do
        [ -z "$base" ] || [ ! -d "$base" ] && continue
        [ "$disabled" -ge "$count" ] && break
        # ls -t 按修改时间倒序，可移植（toybox/busybox 均支持）
        modules=$(ls -t "$base" 2>/dev/null)
        for mod_id in $modules; do
            [ -z "$mod_id" ] && continue
            [ "$disabled" -ge "$count" ] && break
            mod_dir="$base/$mod_id/"
            [ ! -d "$mod_dir" ] && continue
            if [ "$DRY_RUN" = true ]; then disable_module_safe "$mod_dir" "$mod_id" && disabled=$((disabled + 1));
            else manager=$(rescue_manager_for_base "$base") && rescue_transaction_disable_target "$manager" "$base" "$mod_id" "${mod_dir%/}" && disabled=$((disabled + 1)); fi
        done
    done
    [ "$DRY_RUN" != true ] && rescue_transaction_finish_targets || true
    log "渐进式救砖完成: 禁用 $disabled 个"
    log_rescue_action "PROGRESSIVE_RESCUE" "disabled=$disabled, count=$count"
}

# 全量救砖：禁用所有非白名单模块
full_rescue() {
    read_whitelist  # 确保白名单已加载
    log "全量救砖：禁用所有非白名单模块"

    # v2.7.0: 救砖前自动拍快照
    local auto_snap
    auto_snap=$(take_snapshot auto)
    [ -n "$auto_snap" ] && log "救砖前自动快照: $(basename "$auto_snap")"

    local disabled=0 skipped=0
    local base mod_id mod_dir manager
    [ "$DRY_RUN" = true ] || rescue_transaction_begin_targets FULL_RESCUE || return 1
    for base in "$MODULE_BASE" "$MODULE_BASE_KSU" "$MODULE_BASE_AP"; do
        [ -z "$base" ] || [ ! -d "$base" ] && continue
        for mod_dir in "$base"/*/; do
            [ ! -d "$mod_dir" ] && continue
            mod_id=$(basename "$mod_dir")
            [ "$mod_id" = "$SELF_ID" ] && { skipped=$((skipped + 1)); continue; }
            is_whitelisted "$mod_id" && { skipped=$((skipped + 1)); log "  跳过白名单: $mod_id"; continue; }
            [ -f "${mod_dir}disable" ] && { skipped=$((skipped + 1)); continue; }
            if [ "$DRY_RUN" = "true" ]; then
                log "[DRY_RUN] 将禁用: $mod_id"
                disabled=$((disabled + 1))
            else
                manager=$(rescue_manager_for_base "$base") && rescue_transaction_disable_target "$manager" "$base" "$mod_id" "${mod_dir%/}" && disabled=$((disabled + 1)) || log "禁用失败: $mod_id"
            fi
        done
    done
    [ "$DRY_RUN" = true ] || rescue_transaction_finish_targets || true
    log "全量救砖完成: 禁用 $disabled 个, 跳过 $skipped 个"
    log_rescue_action "FULL_RESCUE" "disabled=$disabled, skipped=$skipped"
}

# 恢复被救砖禁用的模块（仅恢复 rescued_disabled.list 中记录的）
# 历史恢复实现已在 v3.4 retire；安全恢复仅可依据明确的救砖清单。
_reenable_all_unsafe_legacy() {
    # Retired in v3.4: never scan or restore globally disabled modules.
    return 1
}

# ============================================================
# 看门狗管理
# ============================================================

# 安全停止看门狗（按 PID + cmdline 验证，防 PID 复用误杀）
stop_watchdog() {
    if [ -f "$WATCHDOG_PID_FILE" ]; then
        local wd_pid
        wd_pid=$(cat "$WATCHDOG_PID_FILE" 2>/dev/null)
        case "$wd_pid" in
            ''|*[!0-9]*) wd_pid=0 ;;
        esac
        if [ "$wd_pid" != "0" ] && kill -0 "$wd_pid" 2>/dev/null; then
            local cmdline
            cmdline=$(cat /proc/$wd_pid/cmdline 2>/dev/null | tr '\0' ' ')
            case "$cmdline" in
                *watchdog.sh*|*"${MODDIR}/watchdog"*)
                    kill "$wd_pid" 2>/dev/null
                    local i=0
                    while [ $i -lt 5 ] && kill -0 "$wd_pid" 2>/dev/null; do
                        sleep 1
                        i=$((i + 1))
                    done
                    # kill -9 前复查 cmdline，避免 PID 复用误杀
                    if kill -0 "$wd_pid" 2>/dev/null; then
                        local c2
                        c2=$(cat /proc/$wd_pid/cmdline 2>/dev/null | tr '\0' ' ')
                        case "$c2" in
                            *watchdog.sh*|*"${MODDIR}/watchdog"*) kill -9 "$wd_pid" 2>/dev/null ;;
                            *) log "警告：PID $wd_pid 已变为非看门狗进程，跳过 kill -9" ;;
                        esac
                    fi
                    log "看门狗已停止 (PID=$wd_pid)"
                    ;;
                *)
                    log "警告：PID $wd_pid cmdline='$cmdline' 非看门狗，跳过"
                    ;;
            esac
        fi
        rm -f "$WATCHDOG_PID_FILE"
    fi
    # 兜底：按脚本路径 pkill（部分 busybox pkill 不支持 -f，失败时手动兜底）
    if command -v pkill >/dev/null 2>&1 && pkill -f "${MODDIR}/watchdog.sh" 2>/dev/null; then
        :
    else
        _kill_by_cmdline "${MODDIR}/watchdog.sh"
    fi
}

# 提交已验证的救砖结果。只有模块 disable 标记已被三层救砖路径验证后才可调用。
# `requested_count` 供 post-fs-data 传入已计算的累计值；看门狗路径留空时递增当前值。
commit_verified_rescue() {
    local source="${1:-unknown}" requested_count="${2:-}" rescue_count=0 now token
    local boot_start=0 uptime_start=0 ota_detected=false patch_detected=false k v tmp

    if [ -f "$STATUS_FILE" ]; then
        while IFS='=' read -r k v; do
            [ -z "$k" ] && continue
            case "$k" in
                BOOT_START) boot_start="$v" ;;
                BOOT_TOKEN) token="$v" ;;
                UPTIME_START) uptime_start="$v" ;;
                OTA_DETECTED) ota_detected="$v" ;;
                PATCH_DETECTED) patch_detected="$v" ;;
                RESCUE_COUNT) rescue_count="$v" ;;
            esac
        done < "$STATUS_FILE"
    fi
    case "$boot_start" in ''|*[!0-9]*) boot_start=0 ;; esac
    case "$uptime_start" in ''|*[!0-9]*) uptime_start=0 ;; esac
    case "$rescue_count" in ''|*[!0-9]*) rescue_count=0 ;; esac
    case "$requested_count" in ''|*[!0-9]*) rescue_count=$((rescue_count + 1)) ;; *) rescue_count="$requested_count" ;; esac
    [ -n "$token" ] || token=$(get_boot_token)
    now=$(get_valid_epoch)
    # v3.5.10-r2: 早期 RTC 未同步时 get_valid_epoch 返回 0。
    # 保留旧 LAST_RESCUE_TIME，避免用 0 覆盖有效值；fix_last_rescue_time
    # 会在时钟恢复后把 0 修正为近似时间。
    if [ "$now" -le 0 ]; then
        now=$(grep "^LAST_RESCUE_TIME=" "$STATUS_FILE" 2>/dev/null | cut -d= -f2)
        case "$now" in ''|*[!0-9]*) now=0 ;; esac
    fi

    tmp="${STATUS_TMP}.rescue.$$"
    cat > "$tmp" << STAT
BOOT_START=$boot_start
BOOT_TOKEN=$token
BOOT_END=0
SERVICE_STARTED=0
FAIL_COUNT=0
LAST_BOOT_RESULT=RESCUED
OTA_DETECTED=$ota_detected
RESCUE_COUNT=$rescue_count
LAST_RESCUE_TIME=$now
BOOT_DURATION=0
UPTIME_START=$uptime_start
UPTIME_END=0
PATCH_DETECTED=$patch_detected
STAT
    sync "$tmp" 2>/dev/null
    mv -f "$tmp" "$STATUS_FILE" || { rm -f "$tmp"; return 1; }
    chmod 0600 "$STATUS_FILE" 2>/dev/null
    _write_status_json "$boot_start" 0 0 0 "RESCUED" "$ota_detected" "$rescue_count" "$now" 0 "$uptime_start" 0 "$patch_detected" "$token"
    append_boot_history "[$(get_log_time)] RESCUE | boot=$token | count=$rescue_count | source=$source | result=RESCUED" || log "警告：救砖历史写入失败"
    log_rescue_action "RESCUE_COMMIT" "source=$source,count=$rescue_count"
    sync_to_persist
    return 0
}

# A rescue action changes module enablement for the following boot. Request one
# normal reboot only after its durable status commit; if the request fails, leave
# the explicit RESCUED state and disabled markers for safe manual recovery.
request_reboot_after_verified_rescue() {
    log "[RX] 救砖状态已提交，请求一次普通重启"
    sync &
    local sync_pid=$!
    sleep 3
    kill -9 "$sync_pid" 2>/dev/null
    wait "$sync_pid" 2>/dev/null
    reboot 2>/dev/null || { log "[RX] 普通重启请求失败；保留 RESCUED 状态，等待人工重启"; return 1; }
    return 0
}

# 看门狗触发的救砖逻辑（在 watchdog.sh 子进程中调用）
_watchdog_trigger_unlocked() {
    log "[WD] 看门狗超时触发救砖"
    read_config
    read_whitelist
    if ! three_level_rescue; then
        log "[WD] 救砖动作未完成；保留 BOOTING 状态和事务记录，等待人工处理"
        return 1
    fi
    commit_verified_rescue watchdog || { log "[WD] 救砖动作已验证但状态提交失败"; return 1; }
    request_reboot_after_verified_rescue || true
    return 0
}

# ============================================================
# 模块列表扫描（供 WebUI 模块选择器使用）
# 输出格式：mod_id|enabled|manager
# ============================================================
list_all_modules() {
    local base manager mod_id mod_dir enabled
    for base in "$MODULE_BASE" "$MODULE_BASE_KSU" "$MODULE_BASE_AP"; do
        [ -z "$base" ] || [ ! -d "$base" ] && continue
        case "$base" in
            */ksu/modules) manager="KSU" ;;
            */ap/modules|*/ap_modules) manager="APatch" ;;
            *) manager="Magisk" ;;
        esac
        for mod_dir in "$base"/*/; do
            [ ! -d "$mod_dir" ] && continue
            mod_id=$(basename "$mod_dir")
            [ "$mod_id" = "$SELF_ID" ] && continue
            case "$mod_id" in *[!A-Za-z0-9._-]*) continue ;; esac
            # 跳过 update 目录、remove 标记
            [ -f "${mod_dir}remove" ] && continue
            if [ -f "${mod_dir}disable" ]; then
                enabled="0"
            else
                enabled="1"
            fi
            echo "${mod_id}|${enabled}|${manager}"
        done
    done
}

# 列出当前被禁用的模块（供 WebUI 展示）
list_disabled_modules() {
    local base mod_id mod_dir
    for base in "$MODULE_BASE" "$MODULE_BASE_KSU" "$MODULE_BASE_AP"; do
        [ -z "$base" ] || [ ! -d "$base" ] && continue
        for mod_dir in "$base"/*/; do
            [ ! -d "$mod_dir" ] && continue
            [ -f "${mod_dir}disable" ] || continue
            mod_id=$(basename "$mod_dir")
            [ "$mod_id" = "$SELF_ID" ] && continue
            case "$mod_id" in *[!A-Za-z0-9._-]*) continue ;; esac
            echo "$mod_id"
        done
    done
}

# ============================================================
# 模块快照与回滚（Feature-2）
# ============================================================

# 拍快照：记录当前所有模块的 enable/disable 状态
# 参数: [manual|auto]
take_snapshot() {
    mkdir -p "$SNAPSHOT_DIR" 2>/dev/null
    local mode="${1:-manual}"
    local snap_file tmp_file label session_key
    case "$mode" in
        auto)
            snap_file="$AUTO_SNAPSHOT_FILE"
            label="auto"
            if auto_snapshot_already_taken; then
                echo "$snap_file"
                return 0
            fi
            session_key=$(get_auto_snapshot_session_key)
            ;;
        *)
            snap_file="$SNAPSHOT_DIR/snap-$(date +%Y%m%d-%H%M%S 2>/dev/null || echo unknown).txt"
            label="manual"
            ;;
    esac
    tmp_file="${snap_file}.tmp.$$"
    {
        echo "# RescueX 模块快照 - $(date 2>/dev/null)"
        echo "# 类型: $label"
        echo "# 格式: mod_id=enabled|disabled"
        local base mod_id mod_dir
        for base in "$MODULE_BASE" "$MODULE_BASE_KSU" "$MODULE_BASE_AP"; do
            [ -z "$base" ] || [ ! -d "$base" ] && continue
            for mod_dir in "$base"/*/; do
                [ ! -d "$mod_dir" ] && continue
                mod_id=$(basename "$mod_dir")
                [ "$mod_id" = "$SELF_ID" ] && continue
                case "$mod_id" in *[!A-Za-z0-9._-]*) continue ;; esac
                if [ -f "${mod_dir}disable" ]; then
                    echo "${mod_id}=disabled"
                else
                    echo "${mod_id}=enabled"
                fi
            done
        done
    } > "$tmp_file" 2>/dev/null || return 1
    sync "$tmp_file" 2>/dev/null
    mv -f "$tmp_file" "$snap_file" 2>/dev/null || return 1
    chmod 0600 "$snap_file" 2>/dev/null
    [ "$label" = "auto" ] && write_auto_snapshot_session "$session_key"
    [ "$label" = "manual" ] && prune_manual_snapshots_in_dir "$SNAPSHOT_DIR"
    echo "$snap_file"
}

# 回滚到指定快照
# 参数: <snap_file>
restore_snapshot() {
    local snap_file="$1"
    [ ! -f "$snap_file" ] && return 1

    local mod_id state mod_dir
    while IFS='=' read -r mod_id state; do
        [ -z "$mod_id" ] && continue
        case "$mod_id" in \#*) continue ;; esac
        [ -z "$state" ] && continue
        # 安全校验
        case "$mod_id" in *[!A-Za-z0-9._-]*) continue ;; esac
        case "$state" in enabled|disabled) ;; *) continue ;; esac

        # 在三个 base 中查找模块
        local found_dir=""
        for base in "$MODULE_BASE" "$MODULE_BASE_KSU" "$MODULE_BASE_AP"; do
            [ -z "$base" ] || [ ! -d "$base" ] && continue
            if [ -d "$base/$mod_id" ]; then
                found_dir="$base/$mod_id"
                break
            fi
        done
        [ -z "$found_dir" ] && continue

        if [ "$state" = "enabled" ]; then
            rm -f "${found_dir}/disable" 2>/dev/null
        else
            disable_module_at_dir "$found_dir" "$mod_id" >/dev/null 2>&1 || true
        fi
    done < "$snap_file"
    return 0
}

# 列出所有快照
list_snapshots() {
    [ ! -d "$SNAPSHOT_DIR" ] && return
    normalize_snapshot_storage
    prune_manual_snapshots_in_dir "$SNAPSHOT_DIR"
    ls -1 "$SNAPSHOT_DIR"/snap-*.txt 2>/dev/null | sort -r
}

# 删除快照
# 参数: <snap_file>
delete_snapshot() {
    local snap_name=""
    case "$1" in
        "$SNAPSHOT_DIR"/snap-*.txt)
            [ -f "$1" ] || return 1
            snap_name=$(basename "$1")
            rm -f "$1" 2>/dev/null || return 1
            delete_persisted_snapshot "$snap_name"
            ;;
        *)
            return 1
            ;;
    esac
    return 0
}

restore_good_modules_baseline() {
    [ -f "$GOOD_MODULES_FILE" ] || return 1

    local line mod_id desired_state found_dir base changed=0 skipped=0
    while IFS= read -r line || [ -n "$line" ]; do
        [ -z "$line" ] && continue
        case "$line" in
            \#*) continue ;;
            :*) mod_id="${line#:}"; desired_state="disabled" ;;
            *) mod_id="$line"; desired_state="enabled" ;;
        esac
        case "$mod_id" in ''|*[!A-Za-z0-9._-]*) skipped=$((skipped + 1)); continue ;; esac
        [ "$mod_id" = "$SELF_ID" ] && continue

        found_dir=""
        for base in "$MODULE_BASE" "$MODULE_BASE_KSU" "$MODULE_BASE_AP"; do
            [ -z "$base" ] || [ ! -d "$base" ] && continue
            if [ -d "$base/$mod_id" ]; then
                found_dir="$base/$mod_id"
                break
            fi
        done
        [ -z "$found_dir" ] && { skipped=$((skipped + 1)); continue; }

        if [ "$desired_state" = "enabled" ]; then
            if [ -f "${found_dir}/disable" ]; then
                rm -f "${found_dir}/disable" 2>/dev/null && changed=$((changed + 1))
            fi
        else
            if [ ! -f "${found_dir}/disable" ]; then
                disable_module_at_dir "$found_dir" "$mod_id" >/dev/null 2>&1 && changed=$((changed + 1))
            fi
        fi
    done < "$GOOD_MODULES_FILE"
    log "已恢复稳定基线: changed=$changed skipped=$skipped"
    log_rescue_action "BASELINE_RESTORE" "changed=$changed,skipped=$skipped"
    printf 'CHANGED=%s\nSKIPPED=%s\n' "$changed" "$skipped"
    return 0
}

generate_rescue_decision_report() {
    local rescue_level=0 fail_count=0 threshold=0 boot_result="UNKNOWN" patch_detected="false"
    local baseline_total=0 baseline_enabled=0 suspect_new=0 suspect_reenabled=0 suspect_uncertain=0
    local suspect_lines=""
    local recommendation=""

    read_config
    read_status
    read_rescue_level

    fail_count="${FAIL_COUNT:-0}"
    threshold="${REBOOT_THRESHOLD:-0}"
    boot_result="${BOOT_RESULT:-UNKNOWN}"
    patch_detected="${PATCH_DETECTED:-false}"

    if [ -f "$GOOD_MODULES_FILE" ]; then
        baseline_total=$(grep -cve '^\s*$' "$GOOD_MODULES_FILE" 2>/dev/null || echo 0)
        baseline_enabled=$(grep -cve '^[:#]' "$GOOD_MODULES_FILE" 2>/dev/null || echo 0)
    fi

    if [ -f "$SUSPECT_LOG" ]; then
        while IFS= read -r line || [ -n "$line" ]; do
            [ -z "$line" ] && continue
            case "$line" in
                \#*) continue ;;
                +*) suspect_reenabled=$((suspect_reenabled + 1)) ;;
                \?*) suspect_uncertain=$((suspect_uncertain + 1)) ;;
                *) suspect_new=$((suspect_new + 1)) ;;
            esac
            suspect_lines="${suspect_lines}${line}\n"
        done < "$SUSPECT_LOG"
    fi

    case "$rescue_level" in
        0) rescue_level="0: 精准嫌疑禁用" ;;
        1) rescue_level="1: 全量模块禁用 + 脚本锁定" ;;
        2) rescue_level="2: APP 解冻" ;;
        *) rescue_level="0: 精准嫌疑禁用" ;;
    esac

    if [ "$baseline_total" -eq 0 ]; then
        recommendation="当前缺少稳定基线。设备稳定后先保存当前模块列表，再观察后续启动结果。"
    elif [ "$suspect_new" -gt 0 ]; then
        recommendation="优先保持新增嫌疑模块处于禁用状态，完成一次稳定启动后再逐个复核。"
    elif [ "$suspect_reenabled" -gt 0 ]; then
        recommendation="重点检查最近重新启用的模块，必要时回到稳定基线后逐个恢复。"
    elif [ "$patch_detected" = "true" ]; then
        recommendation="当前处于补丁相关窗口，优先核对补丁模块和 update 缓存恢复结果。"
    elif [ "$fail_count" -ge "$threshold" ] 2>/dev/null; then
        recommendation="失败计数已经达到阈值，建议立即恢复稳定基线并检查白名单。"
    else
        recommendation="当前适合先保留现状，继续观察下一次完整启动，并保留最新诊断报告。"
    fi

    {
        echo "=========================================="
        echo "  RescueX 救援决策报告"
        echo "  版本: $RX_VERSION (code=$RX_VERSION_CODE)"
        echo "  生成时间: $(get_log_time)"
        echo "=========================================="
        echo ""
        echo "=== 当前判断 ==="
        echo "启动结果: $boot_result"
        echo "连续失败次数: $fail_count / $threshold"
        echo "当前救砖级别: $rescue_level"
        echo "补丁窗口: $patch_detected"
        echo ""
        echo "=== 稳定基线 ==="
        echo "基线总数: $baseline_total"
        echo "基线启用模块: $baseline_enabled"
        echo ""
        echo "=== 嫌疑模块统计 ==="
        echo "新增嫌疑: $suspect_new"
        echo "重新启用嫌疑: $suspect_reenabled"
        echo "不确定参考: $suspect_uncertain"
        if [ -n "$suspect_lines" ]; then
            echo ""
            echo "=== 嫌疑清单 ==="
            printf '%b' "$suspect_lines"
        fi
        echo ""
        echo "=== 建议动作 ==="
        echo "$recommendation"
        echo "=========================================="
    }
}

# ============================================================
# 单模块操作（v2.7.0 新增，供 WebUI 使用）
# ============================================================

# 获取单个模块详细信息（供 WebUI 使用）
# 输出: name|version|author|description|enabled|manager
module_info() {
    local mod_id="$1"
    [ -z "$mod_id" ] && return 1
    case "$mod_id" in *[!A-Za-z0-9._-]*) return 1 ;; esac

    local found_dir="" manager=""
    for base in "$MODULE_BASE" "$MODULE_BASE_KSU" "$MODULE_BASE_AP"; do
        [ -z "$base" ] || [ ! -d "$base" ] && continue
        if [ -d "$base/$mod_id" ]; then
            found_dir="$base/$mod_id"
            case "$base" in
                */ksu/modules) manager="KSU" ;;
                */ap/modules|*/ap_modules) manager="APatch" ;;
                *) manager="Magisk" ;;
            esac
            break
        fi
    done
    [ -z "$found_dir" ] && return 1

    local name="" version="" author="" description=""
    if [ -f "$found_dir/module.prop" ]; then
        local k v
        while IFS='=' read -r k v; do
            [ -z "$k" ] && continue
            case "$k" in
                name) name="$v" ;;
                version) version="$v" ;;
                author) author="$v" ;;
                description) description="$v" ;;
            esac
        done < "$found_dir/module.prop"
    fi

    local enabled="1"
    [ -f "${found_dir}/disable" ] && enabled="0"

    echo "${name:-$mod_id}|${version:-?}|${author:-?}|${description:-?}|${enabled}|${manager}"
}

# 切换单个模块启用/禁用状态（供 WebUI 使用）
toggle_single_module() {
    local mod_id="$1"
    local action="$2"  # enable or disable
    [ -z "$mod_id" ] || [ -z "$action" ] && return 1
    case "$mod_id" in *[!A-Za-z0-9._-]*) return 1 ;; esac
    [ "$mod_id" = "$SELF_ID" ] && return 1

    local found_dir=""
    for base in "$MODULE_BASE" "$MODULE_BASE_KSU" "$MODULE_BASE_AP"; do
        [ -z "$base" ] || [ ! -d "$base" ] && continue
        if [ -d "$base/$mod_id" ]; then
            found_dir="$base/$mod_id"
            break
        fi
    done
    [ -z "$found_dir" ] && return 1

    case "$action" in
        enable)
            [ ! -f "${found_dir}/disable" ] && return 2  # already enabled
            rm -f "${found_dir}/disable" 2>/dev/null
            log "手动启用模块: $mod_id"
            log_rescue_action "MANUAL_ENABLE" "$mod_id"
            return 0
            ;;
        disable)
            [ -f "${found_dir}/disable" ] && return 2  # already disabled
            touch "${found_dir}/disable" 2>/dev/null
            log "手动禁用模块: $mod_id"
            log_rescue_action "MANUAL_DISABLE" "$mod_id"
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}

# ============================================================
# 完整状态导出（v2.7.0 新增，供 WebUI 导出功能使用）
# ============================================================

# 导出完整状态（供 WebUI 导出功能使用）
export_full_state() {
    local out_file="$1"
    [ -z "$out_file" ] && out_file="$STATE_DIR/rescuex_export.txt"

    {
        echo "# RescueX 完整状态导出 - $RX_VERSION"
        echo "# 导出时间: $(get_log_time)"
        echo ""
        echo "=== 配置 ==="
        [ -f "$CONF_FILE" ] && cat "$CONF_FILE"
        echo ""
        echo "=== 白名单 ==="
        [ -f "$WHITELIST_FILE" ] && cat "$WHITELIST_FILE"
        echo ""
        echo "=== 启动状态 ==="
        [ -f "$STATUS_FILE" ] && cat "$STATUS_FILE"
        echo ""
        echo "=== 补丁失败计数 ==="
        [ -f "$PATCH_FAIL_COUNT_FILE" ] && cat "$PATCH_FAIL_COUNT_FILE"
        echo ""
        echo "=== 救砖禁用列表 ==="
        [ -f "$RESCUED_DISABLED_LIST" ] && cat "$RESCUED_DISABLED_LIST" || echo "(无)"
        echo ""
        echo "=== 救砖审计 ==="
        [ -f "$STATE_DIR/rescue_audit.log" ] && tail -n 50 "$STATE_DIR/rescue_audit.log" || echo "(无)"
        echo ""
        echo "=== 已知良好模块列表 ==="
        [ -f "$GOOD_MODULES_FILE" ] && cat "$GOOD_MODULES_FILE" || echo "(无)"
        echo ""
        echo "=== 嫌疑模块日志 ==="
        [ -f "$SUSPECT_LOG" ] && cat "$SUSPECT_LOG" || echo "(无)"
        echo ""
        echo "=== 救砖级别 ==="
        [ -f "$RESCUE_LEVEL_FILE" ] && cat "$RESCUE_LEVEL_FILE" || echo "0"
    } > "$out_file" 2>/dev/null
    # SEC-006: 导出文件设 0644 权限（以免 MediaScanner 读不到）
    chmod 0644 "$out_file" 2>/dev/null
    echo "$out_file"
}

# ============================================================
# 启动模式检测（v2.5 新增）
# 识别 Recovery / Fastbootd / Charger 等非正常启动模式
# 这些模式不应被计入"启动失败"，避免救砖逻辑误触发
# 返回 0=正常启动模式  1=非正常启动模式（应跳过失败计数）
# ============================================================
detect_boot_mode() {
    # 检查 ro.bootmode 属性（不同厂商命名有差异）
    local mode=""
    mode=$(getprop ro.bootmode 2>/dev/null)
    [ -z "$mode" ] && mode=$(getprop ro.boot.mode 2>/dev/null)
    case "$mode" in
        recovery|recovery2) return 1 ;;
        fastboot|fastbootd) return 1 ;;
        charger) return 1 ;;
        meta|metamode) return 1 ;;
        safe) return 1 ;;
    esac

    # 检查 ro.bootmode 的等价属性
    if getprop ro.boot.bootmode 2>/dev/null | grep -qi "recovery\|fastboot\|charger"; then
        return 1
    fi

    # /cache/recovery/command 容易在 OTA/侧载后残留。这里仅依赖 boot 属性判断当前启动模式，
    # OTA 文件信号交由 detect_ota 处理，避免残留空文件静默关闭看门狗。
    # 部分厂商（Qualcomm / MTK）通过 ro.boot.bootreason 记录启动原因
    local bootreason
    bootreason=$(getprop ro.boot.bootreason 2>/dev/null)
    case "$bootreason" in
        recovery|recovery2|fastboot|fastbootd|charger|charger_mode)
            return 1
            ;;
    esac

    # sys.boot_completed 在 post-fs-data 阶段为空，不能用于判定

    return 0
}

# ============================================================
# LSPosed 禁用检测（v2.5 新增，用于诊断报告）
# 检测 LSPosed 模块是否被禁用
# 输出：禁用状态字符串
# ============================================================
detect_lsposed_state() {
    # 默认检查 Android 真实路径；测试可通过 LSPOSED_BASE_DIR 注入隔离目录。
    local lsposed_base
    lsposed_base="${LSPOSED_BASE_DIR:-/data/adb}"
    # 旧版 LSPosed：disable_config（目录/文件）或其 db 子文件。
    # 新版 LSPosed：lspd/disable 单文件标记。
    if [ -e "$lsposed_base/lsposed/disable_config" ] || [ -e "$lsposed_base/lsposed/disable_config/db" ]; then
        echo "disabled (legacy)"
        return
    fi
    if [ -f "$lsposed_base/lspd/disable" ]; then
        echo "disabled"
        return
    fi
    if [ -d "$lsposed_base/lspd" ] || [ -d "$lsposed_base/lsposed" ]; then
        if [ -f "$lsposed_base/lspd/config/manager.json" ]; then
            echo "enabled"
            return
        fi
        echo "enabled (unknown state)"
        return
    fi
    echo "not_installed"
}

# ============================================================
# 启动统计计算（v2.5 新增，供 WebUI 统计面板使用）
# 基于 boot_history 文件计算：
#   - 总启动次数
#   - 成功次数（result=SUCCESS）
#   - 救砖次数（result=RESCUED）
#   - 启动失败次数
#   - 成功率（百分比）
#   - 平均启动耗时（基于 BOOT_DURATION，仅成功启动计入）
# 输出格式：KEY=VALUE 多行
# ============================================================
compute_boot_stats() {
    local total=0 success=0 rescued=0 failed=0 pending=0
    local sum_duration=0 duration_count=0
    local last_rescue_time=0 last_success_time=0
    local status_last_rescue_time=0 status_rescued=0
    local status_boot_end=0

    [ ! -f "$HISTORY_FILE" ] && {
        echo "TOTAL=0"
        echo "SUCCESS=0"
        echo "RESCUED=0"
        echo "FAILED=0"
        echo "SUCCESS_RATE=0"
        echo "AVG_DURATION=0"
        echo "LAST_RESCUE_TIME=0"
        echo "LAST_SUCCESS_TIME=0"
        return
    }

    # v3.5.10-r2: 按 boot token 终态聚合（awk）。
    #  - START/RESCUE/FAILURE 行创建/记录 boot token（启动证据）
    #  - SERVICE 行仅将已存在 token 升级为 SUCCESS（孤儿 SERVICE 不计入）
    #  - 终态优先级：RESCUE(4) > FAILURE(3) > SUCCESS(2) > PENDING(1)
    #  - postfs 救砖只有 RESCUE 行无 START 行，仍计为一次启动（失败终态），
    #    因此救砖/失败会正确反映在成功率上，不再永远 100%。
    local out line k v
    out=$(awk '
{
    lines[NR]=$0
}
END {
    for (i=1;i<=NR;i++) {
        line=lines[i]
        type=""
        if (line ~ / START /) type="START"
        else if (line ~ / SERVICE /) type="SERVICE"
        else if (line ~ / RESCUE /) type="RESCUE"
        else if (line ~ / FAILURE /) type="FAILURE"
        else if (line ~ / STATE /) type="STATE"
        if (type=="") continue
        tok=""
        if (match(line, /boot=[A-Za-z0-9._-]+/)) tok=substr(line, RSTART+5, RLENGTH-5)
        if (tok=="") continue
        ts=0
        if (line ~ /^\[[0-9]+\]/) { ts=line; sub(/^\[/,"",ts); sub(/\].*/,"",ts); ts+=0 }
        dur=0
        if (type=="SERVICE" && match(line, /duration=[0-9]+/)) { dur=substr(line, RSTART+9, RLENGTH-9)+0 }
        if (type=="START") {
            if (st[tok]<1) st[tok]=1
        } else if (type=="RESCUE") {
            st[tok]=4
            if (ts>0 && ts>rtime[tok]) rtime[tok]=ts
        } else if (type=="FAILURE") {
            # 仅显式失败（FAILURE/TEST_FAILURE）计入失败终态；
            # STATUS_COMMIT_REJECTED/OWNERSHIP_LOST 是 service 与救砖竞争的
            # 结果，不代表真实失败，忽略。
            if (line ~ /result=(FAILURE|TEST_FAILURE)/) {
                if (!(tok in st) || st[tok]<3) st[tok]=3
            }
        } else if (type=="SERVICE") {
            if ((tok in st) && st[tok]<2) {
                st[tok]=2
                if (ts>0) stime[tok]=ts
                if (dur>0 && dur<3600) sdurac[tok]=dur
            }
        }
    }
    for (t in st) {
        total++
        if (st[t]==2) success++
        else if (st[t]==3) failcnt++
        else if (st[t]==4) rescuecnt++
        else pending++
        if (st[t]==2 && stime[t]>last_success) last_success=stime[t]
        if (st[t]==4 && rtime[t]>last_rescue) last_rescue=rtime[t]
        if (st[t]==2 && sdurac[t]>0) { dsum+=sdurac[t]; dcount++ }
    }
    printf "TOTAL=%d\nSUCCESS=%d\nRESCUED=%d\nFAILED=%d\nPENDING=%d\nDSUM=%d\nDCOUNT=%d\nLAST_SUCCESS=%d\nLAST_RESCUE=%d\n", total, success, rescuecnt, failcnt, pending, dsum, dcount, last_success, last_rescue
}
' "$HISTORY_FILE" 2>/dev/null)
    while IFS= read -r line || [ -n "$line" ]; do
        case "$line" in
            TOTAL=*) total=${line#TOTAL=} ;;
            SUCCESS=*) success=${line#SUCCESS=} ;;
            RESCUED=*) rescued=${line#RESCUED=} ;;
            PENDING=*) pending=${line#PENDING=} ;;
            DSUM=*) sum_duration=${line#DSUM=} ;;
            DCOUNT=*) duration_count=${line#DCOUNT=} ;;
            LAST_SUCCESS=*) last_success_time=${line#LAST_SUCCESS=} ;;
            LAST_RESCUE=*) last_rescue_time=${line#LAST_RESCUE=} ;;
        esac
    done << EOF
$out
EOF

    case "$total" in ''|*[!0-9]*) total=0 ;; esac
    case "$success" in ''|*[!0-9]*) success=0 ;; esac
    case "$rescued" in ''|*[!0-9]*) rescued=0 ;; esac
    case "$sum_duration" in ''|*[!0-9]*) sum_duration=0 ;; esac
    case "$duration_count" in ''|*[!0-9]*) duration_count=0 ;; esac
    case "$last_rescue_time" in ''|*[!0-9]*) last_rescue_time=0 ;; esac
    case "$last_success_time" in ''|*[!0-9]*) last_success_time=0 ;; esac

    # 状态文件兜底/下限：历史行被截断、写入失败或早期 RTC 无有效时间时，
    # 以 boot_status 的累计值与修正后的时间为准。
    if [ -f "$STATUS_FILE" ]; then
        status_last_rescue_time=$(grep "^LAST_RESCUE_TIME=" "$STATUS_FILE" 2>/dev/null | cut -d= -f2)
        case "$status_last_rescue_time" in ''|*[!0-9]*) status_last_rescue_time=0 ;; esac
        status_rescued=$(grep "^RESCUE_COUNT=" "$STATUS_FILE" 2>/dev/null | cut -d= -f2)
        case "$status_rescued" in ''|*[!0-9]*) status_rescued=0 ;; esac
        status_boot_end=$(grep "^BOOT_END=" "$STATUS_FILE" 2>/dev/null | cut -d= -f2)
        case "$status_boot_end" in ''|*[!0-9]*) status_boot_end=0 ;; esac

        # 救砖次数取下限补偿（历史可能被截断）
        [ "$status_rescued" -gt "$rescued" ] && rescued=$status_rescued
        # 最近救砖时间：历史无有效时间时用状态值
        [ "$last_rescue_time" -le 0 ] && last_rescue_time=$status_last_rescue_time
        # 最近成功时间：历史无有效时间时用 BOOT_END
        [ "$last_success_time" -le 0 ] && last_success_time=$status_boot_end
    fi

    # 失败次数按实际启动次数估算：总启动 - 成功启动
    # total 包含成功/失败/救砖/未完成 token，数学上恒 >= success
    failed=$((total - success))
    [ "$failed" -lt 0 ] && failed=0

    # v3.5.10-r2: 成功率分母排除 PENDING（进行中的启动不是失败）。
    # 救砖/失败终态仍计入分母，正确拉低成功率。
    local success_rate=0 avg_duration=0 rate_denom=0
    rate_denom=$((total - pending))
    if [ "$rate_denom" -gt 0 ]; then
        success_rate=$((success * 100 / rate_denom))
    fi
    if [ "$duration_count" -gt 0 ]; then
        avg_duration=$((sum_duration / duration_count))
    fi

    echo "TOTAL=$total"
    echo "SUCCESS=$success"
    echo "RESCUED=$rescued"
    echo "FAILED=$failed"
    echo "SUCCESS_RATE=$success_rate"
    echo "AVG_DURATION=$avg_duration"
    echo "LAST_RESCUE_TIME=$last_rescue_time"
    echo "LAST_SUCCESS_TIME=$last_success_time"
}

get_dashboard_snapshot() {
    local wd_pid wd_status wd_cmd

    if [ -f "$STATUS_FILE" ]; then
        cat "$STATUS_FILE"
    else
        cat << 'EOF'
BOOT_START=0
BOOT_TOKEN=
BOOT_END=0
SERVICE_STARTED=0
FAIL_COUNT=0
LAST_BOOT_RESULT=UNKNOWN
OTA_DETECTED=false
RESCUE_COUNT=0
LAST_RESCUE_TIME=0
BOOT_DURATION=0
UPTIME_START=0
UPTIME_END=0
PATCH_DETECTED=false
EOF
    fi

    if patch_flag_active; then
        echo "PATCH_FLAG_ACTIVE=true"
    else
        echo "PATCH_FLAG_ACTIVE=false"
    fi
    echo "PATCH_FAIL_COUNT=$(cat "$PATCH_FAIL_COUNT_FILE" 2>/dev/null || echo 0)"
    if command -v ota_dashboard_status >/dev/null 2>&1; then
        ota_dashboard_status
    else
        echo "OTA_DETECTION_SOURCE=none"
        echo "OTA_DETECTION_REASON=none"
        echo "OTA_DETECTION_ACTIVE=false"
        echo "OTA_BASELINE_READY=false"
        echo "OTA_MANUAL_PENDING=false"
        echo "OTA_VENDOR_SIGNAL=false"
        echo "OTA_VENDOR_REASON=none"
        echo "OTA_TIMEZONE=${TZ:-UTC}"
        echo "OTA_DETECTION_CHECKED_AT=0"
    fi
    if command -v rx_webui_choice_status >/dev/null 2>&1; then
        rx_webui_choice_status
    else
        echo "WEBUI_PREF_STATE=NONE"
        echo "WEBUI_PREF_CHOICE=none"
        echo "WEBUI_PREF_SOURCE=none"
        echo "WEBUI_PREF_PENDING=false"
        echo "WEBUI_PREF_CONFIRMED=false"
    fi

    wd_pid=$(cat "$WATCHDOG_PID_FILE" 2>/dev/null || echo 0)
    echo "WD_PID=$wd_pid"
    wd_status="nopid"
    if [ -n "$wd_pid" ] && echo "$wd_pid" | grep -qE '^[0-9]+$'; then
        if kill -0 "$wd_pid" 2>/dev/null; then
            wd_cmd=$(cat "/proc/$wd_pid/cmdline" 2>/dev/null | tr '\0' ' ')
            case "$wd_cmd" in
                *"${MODDIR}/watchdog.sh"*|*watchdog.sh*|*"${MODDIR}/watchdog"*) wd_status="alive_ours" ;;
                *) wd_status="alive_other" ;;
            esac
        else
            wd_status="dead"
        fi
    fi
    echo "WD_STATUS=$wd_status"

    echo "INTEGRITY_ENABLED=${INTEGRITY_CHECK_ENABLED:-true}"
    if [ -f "$INTEGRITY_STATUS_FILE" ]; then
        while IFS='=' read -r k v; do
            [ -n "$k" ] && echo "INTEGRITY_${k}=$v"
        done < "$INTEGRITY_STATUS_FILE"
    else
        echo "INTEGRITY_RESULT=NOT_INITIALIZED"
    fi
    if integrity_pid_is_alive; then echo "INTEGRITY_DAEMON=alive"; else echo "INTEGRITY_DAEMON=dead"; fi

    compute_boot_stats
}

# ============================================================
# 诊断报告生成（Feature-4）
# 收集设备信息 + 模块状态 + 日志，输出纯文本
# ============================================================
generate_report() {
    local tmp_report
    tmp_report=$(mktemp 2>/dev/null) || tmp_report="$STATE_DIR/.report.tmp"
    {
        echo "=========================================="
        echo "  RescueX 诊断报告"
        echo "  版本: $RX_VERSION (code=$RX_VERSION_CODE)"
        echo "  生成时间: $(get_log_time)"
        echo "=========================================="
        echo ""

        echo "=== 设备信息 ==="
        echo "型号: $(getprop ro.product.model 2>/dev/null)"
        echo "品牌: $(getprop ro.product.brand 2>/dev/null)"
        echo "Android 版本: $(getprop ro.build.version.release 2>/dev/null) (API $(getprop ro.build.version.sdk 2>/dev/null))"
        echo "内核: $(uname -r 2>/dev/null)"
        echo "构建号: $(getprop ro.build.display.id 2>/dev/null)"
        echo ""

        echo "=== 管理器检测 ==="
        [ -d /data/adb/magisk ] && echo "Magisk: 是 (版本 $(getprop magisk.version 2>/dev/null || echo 未知))"
        [ -d /data/adb/ksu ] && echo "KernelSU: 是"
        [ -d /data/adb/ap ] && echo "APatch: 是"
        echo ""

        echo "=== 启动模式检测（v2.5） ==="
        local boot_mode
        boot_mode=$(getprop ro.bootmode 2>/dev/null)
        [ -z "$boot_mode" ] && boot_mode=$(getprop ro.boot.mode 2>/dev/null)
        echo "ro.bootmode: ${boot_mode:-未知}"
        if getprop ro.boot.bootmode 2>/dev/null | grep -qi "recovery"; then
            echo "  → 检测到 Recovery 模式"
        elif getprop ro.boot.bootmode 2>/dev/null | grep -qi "fastboot"; then
            echo "  → 检测到 Fastboot/Fastbootd 模式"
        elif getprop ro.boot.bootmode 2>/dev/null | grep -qi "charger"; then
            echo "  → 检测到 Charger 模式"
        else
            echo "  → 正常启动模式"
        fi
        echo ""

        echo "=== LSPosed 状态（v2.5） ==="
        local lsposed_state
        lsposed_state=$(detect_lsposed_state)
        echo "LSPosed: $lsposed_state"
        echo ""

        echo "=== 启动统计（v2.5） ==="
        compute_boot_stats | while IFS='=' read -r k v; do
            [ -z "$k" ] && continue
            case "$k" in
                TOTAL) echo "  总启动次数: $v" ;;
                SUCCESS) echo "  成功次数: $v" ;;
                RESCUED) echo "  救砖次数: $v" ;;
                FAILED) echo "  失败次数: $v" ;;
                SUCCESS_RATE) echo "  成功率: ${v}%" ;;
                AVG_DURATION) echo "  平均启动耗时: ${v}s" ;;
                LAST_RESCUE_TIME)
                    if [ "$v" != "0" ]; then
                        echo "  最近救砖时间: $(date -d "@$v" '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo "$v")"
                    else
                        echo "  最近救砖时间: 无"
                    fi
                    ;;
            esac
        done
        echo ""

        echo "=== RescueX 配置 ==="
        [ -f "$CONF_FILE" ] && cat "$CONF_FILE" || echo "(配置文件不存在)"
        echo ""

        echo "=== 白名单 ==="
        [ -f "$WHITELIST_FILE" ] && cat "$WHITELIST_FILE" || echo "(白名单为空)"
        echo ""

        echo "=== 当前启动状态 ==="
        [ -f "$STATUS_FILE" ] && cat "$STATUS_FILE" || echo "(状态文件不存在)"
        echo ""

        echo "=== 救砖历史 (最近 20 条) ==="
        # v2.6.0: get_log_time 现输出 epoch（无空格），此处转换为可读时间显示
        if [ -f "$HISTORY_FILE" ]; then
            tail -n 20 "$HISTORY_FILE" | while IFS= read -r hist_line; do
                # 提取 [time] 中的 epoch 并转换为人类可读时间
                # 注：此处位于 pipeline 子 shell，变量天然隔离，无需 local
                # 注：参数展开 ${var#"["} 用引号包裹字面字符，避免 \\[ 转义在某些 shell 不兼容
                case "$hist_line" in
                    \[*\]*)
                        ts_part=${hist_line#"["}
                        ts_part=${ts_part%%"]"*}
                        rest_part=${hist_line#"["*"]"}
                        # 仅当 ts_part 是纯数字（epoch）时转换
                        case "$ts_part" in
                            ''|*[!0-9]*)
                                echo "$hist_line"
                                ;;
                            *)
                                human_ts=$(date -d "@$ts_part" '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo "@$ts_part")
                                echo "[$human_ts]$rest_part"
                                ;;
                        esac
                        ;;
                    *)
                        echo "$hist_line"
                        ;;
                esac
            done
        else
            echo "(无历史)"
        fi
        echo ""

        echo "=== 救砖日志 (最近 30 条) ==="
        # v2.6.0: rescue.log 中时间戳同样为 epoch，做相同转换
        if [ -f "$LOG_FILE" ]; then
            tail -n 30 "$LOG_FILE" | while IFS= read -r log_line; do
                case "$log_line" in
                    \[*\]*)
                        lts_part=${log_line#"["}
                        lts_part=${lts_part%%"]"*}
                        lrest_part=${log_line#"["*"]"}
                        case "$lts_part" in
                            ''|*[!0-9]*)
                                # uptime+Ns 格式或其他，原样输出
                                echo "$log_line"
                                ;;
                            *)
                                lhuman_ts=$(date -d "@$lts_part" '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo "@$lts_part")
                                echo "[$lhuman_ts]$lrest_part"
                                ;;
                        esac
                        ;;
                    *)
                        echo "$log_line"
                        ;;
                esac
            done
        else
            echo "(无日志)"
        fi
        echo ""

        echo "=== 已安装模块列表 ==="
        list_all_modules | while IFS='|' read -r mid ena mgr; do
            echo "  [$mgr] $mid ($([ "$ena" = "1" ] && echo 启用 || echo 禁用))"
        done
        echo ""

        echo "=== 当前被禁用的模块 ==="
        local disabled
        disabled=$(list_disabled_modules)
        if [ -n "$disabled" ]; then
            echo "$disabled" | while read -r m; do echo "  - $m"; done
        else
            echo "  (无)"
        fi
        echo ""

        echo "=== 手动快照列表 ==="
        local snaps
        snaps=$(list_snapshots)
        if [ -n "$snaps" ]; then
            echo "$snaps" | while read -r s; do echo "  - $(basename "$s")"; done
        else
            echo "  (无)"
        fi

        echo ""
        echo "=== 自动快照 ==="
        normalize_snapshot_storage
        if [ -f "$AUTO_SNAPSHOT_FILE" ]; then
            echo "  - $(basename "$AUTO_SNAPSHOT_FILE")"
        else
            echo "  (无)"
        fi

        echo ""
        echo "=========================================="
        echo "  报告结束"
        echo "=========================================="
    } > "$tmp_report" 2>/dev/null
    cat "$tmp_report"
    rm -f "$tmp_report"
}

# ============================================================
# v3.0.0: 脚本目录禁用
# 在救砖时锁定所有脚本目录的脚本权限，防止 service.d 等目录中的
# 第三方脚本在救砖模式下的"最后一口气"执行导致问题
# 覆盖 Magisk / KernelSU / APatch 的所有脚本目录
# ============================================================
save_good_modules() {
    log "保存已知良好模块列表..."
    local count=0
    local tmp_list="${GOOD_MODULES_FILE}.tmp"
    rm -f "$tmp_list"

    local base mod_id mod_dir
    for base in "$MODULE_BASE" "$MODULE_BASE_KSU" "$MODULE_BASE_AP"; do
        [ -z "$base" ] || [ ! -d "$base" ] && continue
        for mod_dir in "$base"/*/; do
            [ ! -d "$mod_dir" ] && continue
            mod_id=$(basename "$mod_dir")
            [ "$mod_id" = "$SELF_ID" ] && continue
            [ -f "${mod_dir}remove" ] && continue
            case "$mod_id" in *[!A-Za-z0-9._-]*) continue ;; esac
            # v3.0.0 FIX: 保存所有模块，用冒号前缀标记禁用状态
            if [ -f "${mod_dir}disable" ]; then
                echo ":${mod_id}" >> "$tmp_list"
            else
                echo "$mod_id" >> "$tmp_list"
            fi
            count=$((count + 1))
        done
    done

    if [ -f "$tmp_list" ]; then
        mv -f "$tmp_list" "$GOOD_MODULES_FILE"
        chmod 0600 "$GOOD_MODULES_FILE" 2>/dev/null
        log "已保存 $count 个已知良好模块"
    else
        # 没有任何模块，写空文件（表示初始状态）
        : > "$GOOD_MODULES_FILE"
        chmod 0600 "$GOOD_MODULES_FILE" 2>/dev/null
        log "已知良好模块列表为空（初始状态）"
    fi

    # v3.0.0: 启动成功后重置救砖级别为 0（下次救砖从嫌疑禁用开始）
    echo "0" > "$RESCUE_LEVEL_FILE" 2>/dev/null
    chmod 0600 "$RESCUE_LEVEL_FILE" 2>/dev/null
    prune_suspect_log
}

# 检测嫌疑模块：对比当前模块与已知良好列表
# 新安装的模块被标记为"确定嫌疑"，状态变化（禁用→启用）的模块被标记为"状态变化嫌疑"
# 返回 0=有明确嫌疑人, 1=无法定位（首次使用或全部已知）
# v3.0.0 BUG FIX: 适配新格式（含冒号前缀的禁用标记），同时检测状态变化
detect_suspect_modules() {
    log "开始检测嫌疑模块..."

    rm -f "$SUSPECT_LOG"

    # 没有已知良好列表 → 无法对比
    if [ ! -f "$GOOD_MODULES_FILE" ]; then
        log "无已知良好模块列表（首次使用），无法精准定位"
        echo "# 首次使用，无历史列表" > "$SUSPECT_LOG"
        return 1
    fi

    # 构建良好列表查找表：modname → "enabled" 或 "disabled"
    local good_table="/tmp/.rx_good_table.$$"
    rm -f "$good_table"
    while IFS= read -r line || [ -n "$line" ]; do
        [ -z "$line" ] && continue
        case "$line" in
            \#*) continue ;;
            :*) echo "${line#:}=disabled" >> "$good_table" ;;
            *) echo "${line}=enabled" >> "$good_table" ;;
        esac
    done < "$GOOD_MODULES_FILE"

    # 统计当前所有已安装模块并对比
    local suspect_count=0 state_change_count=0
    local base mod_id mod_dir
    for base in "$MODULE_BASE" "$MODULE_BASE_KSU" "$MODULE_BASE_AP"; do
        [ -z "$base" ] || [ ! -d "$base" ] && continue
        for mod_dir in "$base"/*/; do
            [ ! -d "$mod_dir" ] && continue
            mod_id=$(basename "$mod_dir")
            [ "$mod_id" = "$SELF_ID" ] && continue
            [ -f "${mod_dir}remove" ] && continue
            case "$mod_id" in *[!A-Za-z0-9._-]*) continue ;; esac

            local current_state="enabled"
            [ -f "${mod_dir}disable" ] && current_state="disabled"

            # 查找在良好列表中的状态
            local prev_state=""
            if [ -f "$good_table" ]; then
                prev_state=$(grep "^${mod_id}=" "$good_table" 2>/dev/null | head -1 | cut -d= -f2)
            fi

            if [ -z "$prev_state" ]; then
                # 全新安装的模块（不在良好列表中）→ 确定嫌疑
                echo "$mod_id" >> "$SUSPECT_LOG"
                log "嫌疑模块（全新安装）: $mod_id"
                suspect_count=$((suspect_count + 1))
            elif [ "$prev_state" = "disabled" ] && [ "$current_state" = "enabled" ]; then
                # 之前禁用现在启用的模块 → 状态变化嫌疑（用 + 前缀标记）
                echo "+${mod_id}" >> "$SUSPECT_LOG"
                log "嫌疑模块（状态变化：禁用→启用）: $mod_id"
                state_change_count=$((state_change_count + 1))
            fi
            # 之前启用现在仍启用 → 不是嫌疑（已知良好且状态未变）
            # 之前启用现在禁用 → 不可能造成启动失败（它没在运行）
            # 之前禁用现在仍禁用 → 不可能造成启动失败
        done
    done
    rm -f "$good_table"

    local total_suspect=$((suspect_count + state_change_count))
    if [ "$total_suspect" -eq 0 ]; then
        log "未发现新模块或状态变化，可能是已知模块更新导致启动失败"
        # 将所有非自身启用模块标记为参考（? 前缀表示"不确定的嫌疑人"）
        for base in "$MODULE_BASE" "$MODULE_BASE_KSU" "$MODULE_BASE_AP"; do
            [ -z "$base" ] || [ ! -d "$base" ] && continue
            for mod_dir in "$base"/*/; do
                [ ! -d "$mod_dir" ] && continue
                [ -f "${mod_dir}disable" ] && continue
                mod_id=$(basename "$mod_dir")
                [ "$mod_id" = "$SELF_ID" ] && continue
                case "$mod_id" in *[!A-Za-z0-9._-]*) continue ;; esac
                echo "?$mod_id" >> "$SUSPECT_LOG" 2>/dev/null
            done
        done
        log "无明确嫌疑人，已列出所有模块为参考"
        return 1
    fi

    log "共检测到 $suspect_count 个新安装嫌疑 + $state_change_count 个状态变化嫌疑"
    # 有确定嫌疑时返回 0
    [ "$suspect_count" -gt 0 ] && return 0
    # 仅有状态变化嫌疑时也返回 0（但这些优先级低于新安装嫌疑）
    return 0
}

# ============================================================
# v3.0.0: 三级渐进式救砖
# 级别 0: 嫌疑禁用 - 只禁用新出现的新安装/新启用模块（精准击中）
# 级别 1: 全量救砖 - 禁用所有非白名单模块并锁定脚本目录
# 级别 2: APP 解冻 - 删除 package-restrictions.xml 解冻被冻结的应用
# ============================================================

# 读取当前救砖级别（0/1/2）
read_rescue_level() {
    RESCUE_LEVEL=0
    if [ -f "$RESCUE_LEVEL_FILE" ]; then
        local lv
        lv=$(cat "$RESCUE_LEVEL_FILE" 2>/dev/null | tr -d ' \t\r\n')
        case "$lv" in
            0|1|2) RESCUE_LEVEL=$lv ;;
            *) RESCUE_LEVEL=0 ;;
        esac
    fi
}

# 写入当前救砖级别
write_rescue_level() {
    echo "$1" > "$RESCUE_LEVEL_FILE" 2>/dev/null
    chmod 0600 "$RESCUE_LEVEL_FILE" 2>/dev/null
}

# 级别 0: 精准嫌疑禁用（禁用 detect_suspect_modules 发现的模块）
# v3.0.1 BUG FIX: 修复三个导致嫌疑模块未被实际禁用的 Bug：
#   1. 目录查找使用 $suspect（含 + 前缀）而非 $mod_id → +Surfing 查找 /modules/+Surfing 不存在
#   2. found 路径缺少末尾 / → disable_module_safe 创建 /modules/ModNamedisable 而非 /modules/ModName/disable
#   3. disable_module_safe 参数使用 $suspect 而非 $mod_id → mod_id 校验失败
# 同时改进：不确定嫌疑人（?前缀）也执行禁用，而非跳过
suspect_rescue() {
    log "===== 级别 0: 精准嫌疑禁用 ====="
    read_whitelist

    # v3.0.0: 救砖前自动拍快照
    local auto_snap
    auto_snap=$(take_snapshot auto)
    [ -n "$auto_snap" ] && log "救砖前自动快照: $(basename "$auto_snap")"

    if ! detect_suspect_modules; then
        log "无法精准定位嫌疑模块（首次使用或无新模块），升级到级别 1"
        write_rescue_level 1
        return 1
    fi

    # 读取嫌疑列表，同时处理确定嫌疑、状态变化嫌疑和不确定嫌疑人
    local disabled=0
    local suspect mod_id mod_dir found
    while IFS= read -r suspect || [ -n "$suspect" ]; do
        [ -z "$suspect" ] && continue
        # v3.0.1 FIX: ? 前缀（不确定嫌疑人）也要禁用，不再跳过
        # 只跳过注释行（# 开头）
        case "$suspect" in
            \#*) continue ;;  # 跳过注释
        esac
        # v3.0.1 FIX: 统一提取 mod_id，使用 $mod_id（而非 $suspect）进行目录查找和禁用
        case "$suspect" in
            \?*) mod_id="${suspect#\?}" ; log "  不确定嫌疑（仍将禁用）: $mod_id" ;;  # 不确定但需禁用
            +*) mod_id="${suspect#+}" ;;   # 状态变化嫌疑（禁用→启用）
            *) mod_id="$suspect" ;;         # 确定嫌疑（新安装）
        esac
        case "$mod_id" in *[!A-Za-z0-9._-]*) continue ;; esac
        [ "$mod_id" = "$SELF_ID" ] && continue
        is_whitelisted "$mod_id" && { log "  跳过白名单嫌疑: $mod_id"; continue; }

        # v3.0.1 FIX: 使用 $mod_id 查找目录，添加末尾 / 确保 disable 文件路径正确
        found=""
        for base in "$MODULE_BASE" "$MODULE_BASE_KSU" "$MODULE_BASE_AP"; do
            [ -z "$base" ] || [ ! -d "$base" ] && continue
            if [ -d "$base/$mod_id" ]; then
                found="$base/$mod_id/"
                break
            fi
        done
        [ -z "$found" ] && { log "  嫌疑模块目录未找到: $mod_id"; continue; }

        # v3.0.1 FIX: 传 $mod_id（而非 $suspect）给 disable_module_safe
        if disable_module_safe "$found" "$mod_id"; then
            disabled=$((disabled + 1))
            log "  已禁用嫌疑模块: $mod_id"
        else
            log "  禁用嫌疑模块失败: $mod_id"
        fi
    done < "$SUSPECT_LOG"

    log "精准嫌疑禁用完成: 禁用 $disabled 个嫌疑模块"
    log_rescue_action "SUSPECT_RESCUE" "disabled=$disabled"

    # v3.0.1 FIX: 如果没有任何模块被禁用，视为嫌疑禁用失败，升级到级别 1
    if [ "$disabled" -eq 0 ]; then
        log "嫌疑禁用未能禁用任何模块，升级到全量救砖"
        write_rescue_level 1
        return 1
    fi

    # 升级救砖级别（下次启动若仍失败会执行级别 1）
    write_rescue_level 1
    return 0
}

# 级别 1: 全量救砖
full_rescue_with_scripts() {
    log "===== 级别 1: 全量救砖 ====="

    # 先执行常规全量救砖
    full_rescue


    log_rescue_action "FULL_RESCUE_SCRIPTS" "all_modules_and_scripts_locked"
    log "全量+脚本救砖完成"

    # 升级救砖级别（下次启动若失败会执行级别 2）
    write_rescue_level 2
    return 0
}

# 级别 2: APP 解冻（最后手段）
# 删除 package-restrictions.xml，解冻被 PM 冻结的应用
# 某些模块可能冻结了关键系统应用导致无法启动
_app_unfreeze_unsafe_legacy() {
    # Retired in v3.4: never delete Package Manager restriction files.
    return 1
}

# 三级救砖编排器：根据当前救砖级别自动选择策略
# 在 post-fs-data.sh 和 watchdog_trigger 中调用
# v3.0.0 BUG FIX: 当嫌疑禁用无法精准定位时，立即升级到全量救砖
# 原逻辑：suspect_rescue 失败后只升级级别号，等下次启动再全量救砖
# 问题：看门狗已触发说明系统无法启动，不应再等一轮重启
# 修复：suspect_rescue 失败后立即执行 full_rescue_with_scripts
_three_level_rescue_unlocked() {
    read_rescue_level

    case "$RESCUE_LEVEL" in
        0)
            log "当前救砖级别: 0 → 尝试精准嫌疑禁用"
            if suspect_rescue; then
                log "精准嫌疑禁用成功"
            else
                log "嫌疑禁用未能精准定位嫌疑人，立即升级到全量救砖"
                full_rescue_with_scripts
            fi
            ;;
        1)
            log "当前救砖级别: 1 → 执行全量救砖"
            full_rescue_with_scripts
            ;;
        2)
            log "当前救砖级别: 2 → 执行 APP 解冻（最后手段）"
            app_unfreeze
            ;;
        *)
            log "未知救砖级别 $RESCUE_LEVEL，回退到级别 1"
            write_rescue_level 1
            full_rescue_with_scripts
            ;;
    esac
}

# ============================================================
# 初始化
# ============================================================
_rescuex_init_paths


# ============================================================
# v3.4.0：安全状态机覆盖层
# 所有高风险自动路径默认 fail-closed。
# ============================================================
RX_STATE_SCHEMA_VERSION=2
RESCUE_LOCK_TTL_SEC=120

_rescuex_now_sec() {
    local now
    now=$(date +%s 2>/dev/null)
    case "$now" in ''|*[!0-9]*) now=$(get_uptime_sec) ;; esac
    printf '%s' "$now"
}

_rescuex_atomic_private_write() {
    local file="${1:-}" content="${2:-}" tmp="${1:-}.tmp.$$"
    [ -n "$file" ] || return 1
    mkdir -p "${file%/*}" 2>/dev/null || return 1
    # 调用方用 \n 构造键值内容；按转义写入，确保状态文件保持一行一个字段。
    printf '%b' "$content" > "$tmp" || return 1
    chmod 0600 "$tmp" 2>/dev/null
    sync "$tmp" 2>/dev/null
    mv "$tmp" "$file" || return 1
    chmod 0600 "$file" 2>/dev/null
}

_rescuex_atomic_private_write_stream() {
    local file="$1" tmp="${1}.tmp.$$"
    mkdir -p "${file%/*}" 2>/dev/null || return 1
    cat > "$tmp" || return 1
    chmod 0600 "$tmp" 2>/dev/null
    sync "$tmp" 2>/dev/null
    mv "$tmp" "$file" || return 1
    chmod 0600 "$file" 2>/dev/null
}

rescue_lock_acquire() {
    [ "${RESCUE_LOCK_HELD:-false}" = true ] && return 0
    local now lock owner pid born age
    now=$(_rescuex_now_sec); lock="$STATE_DIR/.rescue.lock"
    if mkdir "$lock" 2>/dev/null; then
        _rescuex_atomic_private_write "$lock/owner" "PID=$$\nCREATED_AT=$now\nROLE=${1:-unknown}\n" || { rmdir "$lock" 2>/dev/null; return 1; }
        RESCUE_LOCK_DIR="$lock"; RESCUE_LOCK_HELD=true; return 0
    fi
    owner="$lock/owner"; pid=$(grep '^PID=' "$owner" 2>/dev/null | cut -d= -f2); born=$(grep '^CREATED_AT=' "$owner" 2>/dev/null | cut -d= -f2)
    case "$pid" in ''|*[!0-9]*) pid=0 ;; esac
    case "$born" in ''|*[!0-9]*) born=0 ;; esac
    age=$((now-born)); [ "$age" -lt 0 ] 2>/dev/null && age=0
    # Only reclaim locks that are both expired and have no live owner.
    if [ "$age" -gt "$RESCUE_LOCK_TTL_SEC" ] && { [ "$pid" = 0 ] || ! kill -0 "$pid" 2>/dev/null; }; then
        rm -f "$owner" 2>/dev/null; rmdir "$lock" 2>/dev/null
        mkdir "$lock" 2>/dev/null || return 1
        _rescuex_atomic_private_write "$lock/owner" "PID=$$\nCREATED_AT=$now\nROLE=${1:-unknown}\n" || return 1
        RESCUE_LOCK_DIR="$lock"; RESCUE_LOCK_HELD=true
        log "已回收无活动证据的过期救砖锁（pid=$pid age=${age}s）"
        return 0
    fi
    log "拒绝并发高风险操作：救砖锁仍有效（pid=$pid age=${age}s）"
    return 1
}

rescue_lock_release() {
    [ "${RESCUE_LOCK_HELD:-false}" = true ] || return 0
    local pid
    pid=$(grep '^PID=' "$RESCUE_LOCK_DIR/owner" 2>/dev/null | cut -d= -f2)
    [ "$pid" = "$$" ] || return 1
    rm -f "$RESCUE_LOCK_DIR/owner" 2>/dev/null
    rmdir "$RESCUE_LOCK_DIR" 2>/dev/null
    RESCUE_LOCK_HELD=false
}

rescue_transaction_begin() {
    local action="$1" now
    now=$(_rescuex_now_sec); RESCUE_TRANSACTION_ID="rx-${now}-$$"
    _rescuex_atomic_private_write "$STATE_DIR/rescue.plan" "SCHEMA=$RX_STATE_SCHEMA_VERSION\nID=$RESCUE_TRANSACTION_ID\nACTION=$action\nPHASE=PLANNED\nCREATED_AT=$now\n" || return 1
    log_rescue_action TRANSACTION_PLAN "$RESCUE_TRANSACTION_ID|$action"
}

rescue_transaction_end() {
    local result="$1" now
    now=$(_rescuex_now_sec)
    _rescuex_atomic_private_write "$STATE_DIR/rescue.commit" "SCHEMA=$RX_STATE_SCHEMA_VERSION\nID=${RESCUE_TRANSACTION_ID:-unknown}\nRESULT=$result\nFINISHED_AT=$now\n" || return 1
    rm -f "$STATE_DIR/rescue.plan" 2>/dev/null
    log_rescue_action TRANSACTION_COMMIT "${RESCUE_TRANSACTION_ID:-unknown}|$result"
    sync_to_persist
}

rescue_transaction_fail() {
    local reason="$1" now
    now=$(_rescuex_now_sec)
    _rescuex_atomic_private_write "$STATE_DIR/rescue.rollback" "SCHEMA=$RX_STATE_SCHEMA_VERSION\nID=${RESCUE_TRANSACTION_ID:-unknown}\nREASON=$reason\nFINISHED_AT=$now\n" || true
    log_rescue_action TRANSACTION_ABORT "${RESCUE_TRANSACTION_ID:-unknown}|$reason"
}

# Cross-root transaction journal. The journal is intentionally line-based
# and only accepts validated module IDs and fixed manager roots; callers never
# supply arbitrary paths to restore.
rescue_manager_for_base() {
    case "$1" in
        /data/adb/modules|"$MODULE_BASE") echo MAGISK ;;
        /data/adb/ksu/modules|"$MODULE_BASE_KSU") [ -n "$MODULE_BASE_KSU" ] && echo KSU ;;
        /data/adb/ap/modules|/data/adb/ap_modules|"$MODULE_BASE_AP") [ -n "$MODULE_BASE_AP" ] && echo APATCH ;;
        *) return 1 ;;
    esac
}

_rescue_transaction_release_apply_lock() {
    [ "${RESCUE_TXN_LOCK_OWNED:-false}" = true ] && rescue_lock_release
    RESCUE_TXN_LOCK_OWNED=false
}

rescue_transaction_begin_targets() {
    local action="${1:-RESCUE}" now id dir lock_was_held=false
    case "$action" in ''|*[!A-Za-z0-9._-]*) return 1 ;; esac
    [ "${RESCUE_LOCK_HELD:-false}" = true ] && lock_was_held=true
    rescue_lock_acquire transaction-apply || return 1
    RESCUE_TXN_LOCK_OWNED=false
    [ "$lock_was_held" = true ] || RESCUE_TXN_LOCK_OWNED=true
    now=$(_rescuex_now_sec); id="rx-${now}-$$"; dir="$RESCUE_TXN_DIR/$id"
    mkdir -p "$dir" "$STATE_DIR" 2>/dev/null || { _rescue_transaction_release_apply_lock; return 1; }
    chmod 0700 "$RESCUE_TXN_DIR" "$dir" 2>/dev/null
    { printf 'SCHEMA=1\nID=%s\nACTION=%s\nSTATE=APPLYING\nCREATED_AT=%s\n' "$id" "$action" "$now"; } | _rescuex_atomic_private_write_stream "$dir/meta" || { _rescue_transaction_release_apply_lock; return 1; }
    : > "$dir/targets" || { _rescue_transaction_release_apply_lock; return 1; }
    chmod 0600 "$dir/targets" 2>/dev/null
    printf '%s\n' "$id" | _rescuex_atomic_private_write_stream "$RESCUE_TXN_CURRENT_FILE" || { _rescue_transaction_release_apply_lock; return 1; }
    RESCUE_TRANSACTION_ID="$id"; RESCUE_TRANSACTION_PATH="$dir"
    log_rescue_action TRANSACTION_PLAN "$id|$action"
}

rescue_transaction_disable_target() {
    local manager="$1" base="$2" id="$3" dir="$4" marker shadow
    [ -n "${RESCUE_TRANSACTION_PATH:-}" ] || return 1
    case "$manager" in MAGISK|KSU|APATCH) ;; *) return 1 ;; esac
    case "$id" in ''|*[!A-Za-z0-9._-]*|"$SELF_ID") return 1 ;; esac
    [ "$(rescue_manager_for_base "$base" 2>/dev/null)" = "$manager" ] || return 1
    [ "$dir" = "$base/$id" ] || return 1
    [ -d "$dir" ] || return 1
    marker="$dir/disable"; [ -e "$marker" ] && return 2
    shadow="$base/.$id/disable"; [ -f "$shadow" ] && shadow= || shadow=-
    # Persist recovery ownership *before* mutating the module. An INTENT record
    # with no marker is harmless after interruption; with a marker it is enough
    # evidence for precise recovery, so no module is stranded on journal I/O loss.
    printf 'MANAGER=%s|BASE=%s|MODULE_ID=%s|PATH=%s|MARKER=%s|SHADOW=%s|PREEXISTING=0|STATE=INTENT\n' "$manager" "$base" "$id" "$dir" "$marker" "$shadow" >> "$RESCUE_TRANSACTION_PATH/targets" || return 1
    # toybox supports `sync FILE`; some BusyBox/GNU variants only support a
    # global sync, which is still sufficient before touching the marker.
    sync "$RESCUE_TRANSACTION_PATH/targets" 2>/dev/null || sync 2>/dev/null || return 1
    grep -qxF "MANAGER=$manager|BASE=$base|MODULE_ID=$id|PATH=$dir|MARKER=$marker|SHADOW=$shadow|PREEXISTING=0|STATE=INTENT" "$RESCUE_TRANSACTION_PATH/targets" || return 1
    disable_module_at_dir "$dir" "$id" || return 1
    [ -f "$marker" ] || return 1
    printf '%s\n' "$id" >> "$RESCUED_DISABLED_LIST" 2>/dev/null || true
    log "事务 ${RESCUE_TRANSACTION_ID}: 已禁用 $manager/$id"
}

rescue_transaction_finish_targets() {
    [ -n "${RESCUE_TRANSACTION_PATH:-}" ] || return 1
    sed 's/^STATE=APPLYING$/STATE=APPLIED/' "$RESCUE_TRANSACTION_PATH/meta" | _rescuex_atomic_private_write "$RESCUE_TRANSACTION_PATH/meta" || { _rescue_transaction_release_apply_lock; return 1; }
    log_rescue_action TRANSACTION_COMMIT "$RESCUE_TRANSACTION_ID|targets-applied"
    _rescue_transaction_release_apply_lock
}

rescue_transaction_restore_current() {
    local id dir line manager base mod path marker shadow pre state restored=0 already_restored=0 unresolved=0 total=0 tmp
    rescue_lock_acquire transaction-restore || return 1
    [ -f "$RESCUE_TXN_CURRENT_FILE" ] || { rescue_lock_release; return 1; }
    id=$(cat "$RESCUE_TXN_CURRENT_FILE" 2>/dev/null | tr -d '\r\n')
    case "$id" in rx-[0-9]*-[0-9]* ) ;; *) rescue_lock_release; return 1 ;; esac
    dir="$RESCUE_TXN_DIR/$id"; [ -f "$dir/meta" ] && [ -f "$dir/targets" ] || { rescue_lock_release; return 1; }
    tmp="$dir/targets.restore.$$"; : > "$tmp" || { rescue_lock_release; return 1; }
    while IFS= read -r line || [ -n "$line" ]; do
        manager=$(printf '%s' "$line" | sed -n 's/.*MANAGER=\([^|]*\).*/\1/p')
        base=$(printf '%s' "$line" | sed -n 's/.*BASE=\([^|]*\).*/\1/p')
        mod=$(printf '%s' "$line" | sed -n 's/.*MODULE_ID=\([^|]*\).*/\1/p')
        path=$(printf '%s' "$line" | sed -n 's/.*PATH=\([^|]*\).*/\1/p')
        marker=$(printf '%s' "$line" | sed -n 's/.*MARKER=\([^|]*\).*/\1/p')
        pre=$(printf '%s' "$line" | sed -n 's/.*PREEXISTING=\([^|]*\).*/\1/p')
        state=$(printf '%s' "$line" | sed -n 's/.*STATE=\([^|]*\).*/\1/p')
        total=$((total + 1))
        if [ "$state" = RESTORED ]; then printf '%s\n' "$line" >> "$tmp"; already_restored=$((already_restored + 1)); continue; fi
        case "$manager:$mod:$pre" in MAGISK:*:0|KSU:*:0|APATCH:*:0) ;; *) printf '%s\n' "$line" >> "$tmp"; unresolved=$((unresolved + 1)); continue ;; esac
        [ "$(rescue_manager_for_base "$base" 2>/dev/null)" = "$manager" ] && [ "$path" = "$base/$mod" ] && [ "$marker" = "$path/disable" ] && [ -d "$path" ] || { printf '%s\n' "$line" >> "$tmp"; unresolved=$((unresolved + 1)); continue; }
        if [ -f "$marker" ] && rm -f "$marker" 2>/dev/null && [ ! -e "$marker" ]; then
            printf '%s\n' "${line%|STATE=*}|STATE=RESTORED" >> "$tmp" || { rm -f "$tmp"; rescue_lock_release; return 1; }
            restored=$((restored + 1))
        else
            printf '%s\n' "$line" >> "$tmp"; unresolved=$((unresolved + 1))
        fi
    done < "$dir/targets"
    chmod 0600 "$tmp" 2>/dev/null
    mv "$tmp" "$dir/targets" || { rm -f "$tmp"; rescue_lock_release; return 1; }
    if [ "$unresolved" -gt 0 ]; then
        sed 's/^STATE=.*/STATE=PARTIAL/' "$dir/meta" | _rescuex_atomic_private_write_stream "$dir/meta" || true
        printf 'RESULT=PARTIAL\nTXN_ID=%s\nRESTORED=%s\nALREADY_RESTORED=%s\nUNRESOLVED=%s\n' "$id" "$restored" "$already_restored" "$unresolved"
        log_rescue_action REENABLE_PARTIAL "$id|restored=$restored|unresolved=$unresolved"
        rescue_lock_release
        return 1
    fi
    [ "$total" -gt 0 ] || { rescue_lock_release; return 1; }
    sed 's/^STATE=.*/STATE=RESTORED/' "$dir/meta" | _rescuex_atomic_private_write_stream "$dir/meta" || { rescue_lock_release; return 1; }
    rm -f "$RESCUED_DISABLED_LIST" "$RESCUE_TXN_CURRENT_FILE" 2>/dev/null
    delete_persisted_state_file rescued_disabled.list
    printf 'RESULT=RESTORED\nTXN_ID=%s\nRESTORED=%s\nALREADY_RESTORED=%s\nUNRESOLVED=0\n' "$id" "$restored" "$already_restored"
    log_rescue_action REENABLE_EXACT "$id|restored=$restored"
    rescue_lock_release
    return 0
}

rescue_transaction_status() {
    local id dir state count
    [ -f "$RESCUE_TXN_CURRENT_FILE" ] || { printf 'STATE=NONE\n'; return 0; }
    id=$(cat "$RESCUE_TXN_CURRENT_FILE" 2>/dev/null | tr -d '\r\n'); dir="$RESCUE_TXN_DIR/$id"
    [ -f "$dir/meta" ] || { printf 'STATE=INVALID\n'; return 1; }
    state=$(sed -n 's/^STATE=//p' "$dir/meta" | head -n1); count=$(wc -l < "$dir/targets" 2>/dev/null || echo 0)
    printf 'STATE=%s\nTXN_ID=%s\nTARGETS=%s\n' "${state:-INVALID}" "$id" "$count"
}

read_config() {
    _read_config_legacy
    PATCH_FLAG_TTL_SEC=1800
    WATCHDOG_HEALTH_GRACE_SEC=30
    APP_UNFREEZE_MANUAL_ENABLED=false
    [ -f "$CONF_FILE" ] || return 0
    local k v
    while IFS='=' read -r k v; do
        case "$k" in
            PATCH_FLAG_TTL_SEC) PATCH_FLAG_TTL_SEC="$v" ;;
            WATCHDOG_HEALTH_GRACE_SEC) WATCHDOG_HEALTH_GRACE_SEC="$v" ;;
            APP_UNFREEZE_MANUAL_ENABLED) APP_UNFREEZE_MANUAL_ENABLED="$v" ;;
        esac
    done < "$CONF_FILE"
    case "$PATCH_FLAG_TTL_SEC" in ''|*[!0-9]*) PATCH_FLAG_TTL_SEC=1800 ;; esac
    case "$WATCHDOG_HEALTH_GRACE_SEC" in ''|*[!0-9]*) WATCHDOG_HEALTH_GRACE_SEC=30 ;; esac
    [ "$PATCH_FLAG_TTL_SEC" -lt 300 ] 2>/dev/null && PATCH_FLAG_TTL_SEC=300
    [ "$PATCH_FLAG_TTL_SEC" -gt 7200 ] 2>/dev/null && PATCH_FLAG_TTL_SEC=7200
    [ "$WATCHDOG_HEALTH_GRACE_SEC" -lt 10 ] 2>/dev/null && WATCHDOG_HEALTH_GRACE_SEC=10
    [ "$WATCHDOG_HEALTH_GRACE_SEC" -gt 120 ] 2>/dev/null && WATCHDOG_HEALTH_GRACE_SEC=120
    case "$APP_UNFREEZE_MANUAL_ENABLED" in true|1|yes) APP_UNFREEZE_MANUAL_ENABLED=true ;; *) APP_UNFREEZE_MANUAL_ENABLED=false ;; esac
}

# 为 patch 窗口提供过期机制；旧版纯“1”标记不再永久有效。
set_patch_flag() {
    local now expiry
    now=$(_rescuex_now_sec); expiry=$((now + ${PATCH_FLAG_TTL_SEC:-1800}))
    _rescuex_atomic_private_write "$PATCH_FLAG_FILE" "SCHEMA=$RX_STATE_SCHEMA_VERSION\nSTATE=PENDING\nSET_AT=$now\nEXPIRES_AT=$expiry\n" || return 1
    sync_to_persist
}

patch_flag_active() {
    [ -f "$PATCH_FLAG_FILE" ] || return 1
    local now expiry
    now=$(_rescuex_now_sec); expiry=$(grep '^EXPIRES_AT=' "$PATCH_FLAG_FILE" 2>/dev/null | cut -d= -f2)
    case "$expiry" in
        ''|*[!0-9]*)
            [ "${RESCUEX_READ_ONLY:-false}" = true ] || clear_patch_flag
            return 1
            ;;
    esac
    [ "$now" -le "$expiry" ] && return 0
    [ "${RESCUEX_READ_ONLY:-false}" = true ] && return 1
    log "补丁窗口已过期，清理标记"
    clear_patch_flag
    return 1
}

detect_patch_update() { patch_flag_active && return 0; _detect_patch_update_legacy; }

clear_patch_flag() {
    rm -f "$PATCH_FLAG_FILE" "$PATCH_FAIL_COUNT_FILE" 2>/dev/null
    delete_persisted_state_file patch_update_flag
    delete_persisted_state_file patch_fail_count
}

# 不能解析真实路径或遇到符号链接时拒绝 chmod/chown 目标。
is_safe_custom_dir() {
    local d="$1" real prefix
    _is_safe_custom_dir_legacy "$d" || return 1
    command -v readlink >/dev/null 2>&1 || return 1
    real=$(readlink -f "$d" 2>/dev/null) || return 1
    [ "$real" = "$d" ] || return 1
    for prefix in $SAFE_CUSTOM_DIR_PREFIXES; do case "$real" in "$prefix"|"$prefix"/*) return 0;; esac; done
    return 1
}

# 基线绑定模块 versionCode。正常模块更新会替换核心脚本，因此旧版哈希不再可信；
# 更新后应在本模块目录的当前文件上建立新基线，而非把版本变化误报为文件被篡改。
# 真正的篡改仍由同版本下的哈希比对报告为 COMPROMISED。
integrity_check_once() {
    local version manifest_version pending_file
    pending_file="$PERSIST_DIR/integrity_upgrade_pending"
    # A module overlay/update is allowed to replace several files at once.
    # Rebuild exactly once from the completed tree before any normal comparison;
    # this prevents a stale same-version manifest from calling a valid update
    # COMPROMISED.
    if [ -f "$pending_file" ]; then
        if integrity_build_manifest; then
            integrity_write_status BASELINE_CREATED "覆盖更新完成，已建立当前版本基线"
            rm -f "$pending_file" "$STATE_DIR/integrity_upgrade_pending" 2>/dev/null
            sync_to_persist
            return 0
        fi
        integrity_write_status ERROR "覆盖更新后无法建立完整性基线"
        return 1
    fi
    version=$(grep '^versionCode=' "$MODDIR/module.prop" 2>/dev/null | cut -d= -f2)
    case "$version" in ''|*[!0-9]*) version=0 ;; esac

    if [ ! -f "$INTEGRITY_MANIFEST_FILE" ]; then
        integrity_build_manifest || { integrity_write_status ERROR "无法建立完整性基线"; return 1; }
        integrity_write_status BASELINE_CREATED "首次安装建立基线"
        return 0
    fi

    manifest_version=$(grep '^#VERSION=' "$INTEGRITY_MANIFEST_FILE" 2>/dev/null | cut -d= -f2)
    case "$manifest_version" in ''|*[!0-9]*) manifest_version=-1 ;; esac
    if [ "$manifest_version" != "$version" ]; then
        integrity_build_manifest || { integrity_write_status ERROR "模块更新后无法重建完整性基线"; return 1; }
        integrity_write_status BASELINE_CREATED "模块已更新，已按当前版本重建基线"
        log "[INTEGRITY] 版本 ${manifest_version} -> ${version}，已建立新基线"
        sync_to_persist
        return 0
    fi

    _integrity_check_once_legacy
    local rc=$?
    command -v v35_integrity_details_update >/dev/null 2>&1 && v35_integrity_details_update
    command -v v35_health_touch >/dev/null 2>&1 && v35_health_touch integrity $([ "$rc" -eq 0 ] && echo healthy || echo error) "check_rc=$rc"
    return "$rc"
}

# 证据缺失时不恢复任何模块，也不删除用户/第三方写入的 disable 文件。
reenable_all() {
    local id base seen=0 enabled=0
    # 优先消费带路径归属的事务 journal；禁止按同名模块跨 Root 扫描。
    [ -f "$RESCUE_TXN_CURRENT_FILE" ] && { rescue_transaction_restore_current; return $?; }
    [ -s "$RESCUED_DISABLED_LIST" ] || { log "拒绝恢复：缺少救砖事务证据"; log_rescue_action REENABLE_REFUSED missing-evidence; return 1; }
    log "拒绝恢复：旧版模块 ID 清单无法验证跨 Root 路径归属"
    log_rescue_action REENABLE_REFUSED legacy-ambiguous-evidence
    return 1
    # Legacy code below is intentionally unreachable and retained only for source history.
    while IFS= read -r id || [ -n "$id" ]; do
        case "$id" in ''|\#*|*[!A-Za-z0-9._-]*|"$SELF_ID") continue;; esac
        seen=$((seen+1))
        for base in "$MODULE_BASE" "$MODULE_BASE_KSU" "$MODULE_BASE_AP"; do
            [ -n "$base" ] && [ -d "$base/$id" ] && [ -f "$base/$id/disable" ] && rm -f "$base/$id/disable" 2>/dev/null && enabled=$((enabled+1))
        done
    done < "$RESCUED_DISABLED_LIST"
    [ "$seen" -gt 0 ] || { log "拒绝恢复：清单没有有效模块"; return 1; }
    rm -f "$RESCUED_DISABLED_LIST"; delete_persisted_state_file rescued_disabled.list
    log_rescue_action REENABLE_EXACT "evidence=$seen,enabled=$enabled"
    return 0
}

# 没有可信 patch 快照时不猜测性禁用模块；回滚失败不清状态。
patch_rollback() {
    local snap
    rescue_transaction_begin PATCH_ROLLBACK || return 1
    snap=$(ls -t "$PATCH_BACKUP_DIR"/snap-*.txt 2>/dev/null | head -1)
    if [ -n "$snap" ] && [ -f "$snap" ] && restore_snapshot "$snap"; then
        rescue_transaction_end PATCH_ROLLBACK_SNAPSHOT || return 1
        clear_patch_flag
        return 0
    fi
    rescue_transaction_fail PATCH_SNAPSHOT_MISSING_OR_FAILED
    log "拒绝补丁自动回滚：缺少或无法恢复可信快照"
    return 1
}

# v3.4 beta：绝不自动删除 package-restrictions.xml；该操作不再提供绕过入口。
app_unfreeze() { APP_UNFREEZE_LAST_RESULT=MANUAL_CONFIRM_REQUIRED; write_rescue_level 2; log_rescue_action APP_UNFREEZE_REFUSED manual-review-required; return 1; }
manual_unfreeze_apps() { printf 'RESULT=MANUAL_CONFIRM_REQUIRED\nDETAIL=Beta 已禁用 package-restrictions.xml 删除操作\n'; return 1; }

three_level_rescue() {
    local rc
    if [ "${RESCUE_LOCK_HELD:-false}" != true ]; then
        rescue_lock_acquire auto-rescue || return 1; rescue_transaction_begin THREE_LEVEL_RESCUE || { rescue_lock_release; return 1; }
        _three_level_rescue_unlocked; rc=$?
        [ "$rc" -eq 0 ] && rescue_transaction_end THREE_LEVEL_RESCUE || rescue_transaction_fail THREE_LEVEL_RESCUE_FAILED
        rescue_lock_release; return "$rc"
    fi
    _three_level_rescue_unlocked
}

watchdog_trigger() {
    rescue_lock_acquire watchdog || { log "[WD] 锁被占用，拒绝重复救砖"; return 1; }
    rescue_transaction_begin WATCHDOG_RESCUE || { rescue_lock_release; return 1; }
    _watchdog_trigger_unlocked; local rc=$?
    [ "$rc" -eq 0 ] && rescue_transaction_end WATCHDOG_RESCUE || rescue_transaction_fail WATCHDOG_RESCUE_FAILED
    rescue_lock_release; return "$rc"
}

boot_health_confirmed() {
    local end started prop
    [ -f "$STATUS_FILE" ] || return 1
    end=$(grep '^BOOT_END=' "$STATUS_FILE" 2>/dev/null | cut -d= -f2); case "$end" in *[!0-9]*|'') end=0;; esac
    [ "$end" -gt 0 ] && return 0
    started=$(grep '^SERVICE_STARTED=' "$STATUS_FILE" 2>/dev/null | cut -d= -f2)
    prop=$(getprop sys.boot_completed 2>/dev/null); [ "$prop" = 1 ] || prop=$(getprop dev.bootcomplete 2>/dev/null); [ "$prop" = 1 ] || prop=$(getprop service.bootcomplete 2>/dev/null)
    [ "$prop" = 1 ] && [ "$started" = 1 ]
}


# RescueX v3.5 observability, snapshot and one-shot safe-mode extensions.
# Kept in a separate library so the proven rescue core remains independently testable.
if [ -f "$MODDIR/features-v35.sh" ]; then
    . "$MODDIR/features-v35.sh"
    v35_init_paths
fi

# v3.5.1 safety layer is loaded last so its fail-closed state machine and
# schema-aware compatibility overrides cannot be replaced by legacy helpers.
if [ -f "$MODDIR/v351-safety.sh" ]; then
    . "$MODDIR/v351-safety.sh"
fi

# System OTA detection is isolated from the rescue state machine. Load it last
# so its detect_ota wrapper can retain detect_ota_legacy as a fallback.
if [ -f "$MODDIR/ota-detection.sh" ]; then
    . "$MODDIR/ota-detection.sh"
else
    # A partially applied overlay must retain the proven compatibility detector
    # instead of leaving post-fs-data without a detect_ota function.
    detect_ota() { detect_ota_legacy "$@"; }
fi
