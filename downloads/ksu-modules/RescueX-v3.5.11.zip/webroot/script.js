/* RescueX v3.5.11 - WebUI controller
 * MD3 + i18n 中英切换 + 模块选择器 + 配置导入导出 + 快照 + 诊断报告
 * 兼容：KSU / Magisk v27+ / MMRL
 *
 * v3.0.1 新增（专业级升级）:
 * - 嫌疑模块追踪面板（已知良好模块列表对比）
 * - 三级救砖级别展示与手动重置
 * - APP 解冻功能（删除 package-restrictions.xml）
 */

(function () {
'use strict';

// === 安全校验常量 ===
const APP_VERSION = 'v3.5.11';
const APP_VERSION_CODE = 350204;
// v3.5.11: cross-OEM system OTA detection still compares the last confirmed
// successful build identity; vendor update signals are detection-only.
const ONBOARDING_NOTICE_REVISION = 'r7';
const ONBOARDING_COUNTDOWN_SECONDS = 8;
const REPO_URL = 'https://github.com/jiayuxuan123/RescueX';
const RELEASES_URL = `${REPO_URL}/releases`;
const UPDATE_JSON_URL = 'https://raw.githubusercontent.com/jiayuxuan123/RescueX/master/update.json';
const MODULE_ID_RE = /^[A-Za-z0-9._-]+$/;
const ALLOWED_BASES = ['/data/adb/modules', '/data/adb/ksu/modules', '/data/adb/ap/modules', '/data/adb/ap_modules'];
const DEFAULT_BASE_PATH = '/data/adb/modules/RescueX';
const EXEC_DEFAULT_TIMEOUT_MS = 15000;
const EXEC_STATS_TIMEOUT_MS = 20000;
const EXEC_REPORT_TIMEOUT_MS = 60000;

// UTF-8 安全的 base64 编码：用 TextEncoder 代替已弃用的 unescape() 组合写法
function utf8ToBase64(str) {
    const bytes = new TextEncoder().encode(str);
    let binary = '';
    for (let i = 0; i < bytes.length; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
}

// === i18n 多语言 ===
const I18N = {
    zh: {
        current_status: '当前状态',
        v35_tools_title: '诊断与一次性安全模式',
        v35_tools_desc: '模拟器只生成建议；一次性安全模式会记录精确恢复清单，并只在本次操作涉及的模块范围内恢复。',
        v35_simulate: '运行只读模拟',
        v35_status: '刷新安全模式状态',
        v35_arm: '仅下次启动安全模式',
        v35_cancel: '取消并精确恢复',
        v35_export: '导出脱敏诊断包',
        v35_ready: '等待操作。诊断包只包含脱敏后的状态与日志摘要。',
        workspace_overview: '概览',
        workspace_protection: '保护设置',
        workspace_modules: '模块管理',
        workspace_settings: '保护设置',
        workspace_recovery: '救援操作',
        workspace_logs: '日志与报告',
        workspace_tools: '工具与日志',
        module_search_label: '搜索模块',
        module_search: '搜索模块…',
        module_filter_all: '全部状态',
        module_filter_enabled: '已启用',
        module_filter_disabled: '已禁用',
        module_selected: '已选择 {n} 个',
        workspace_refresh: '刷新状态',
        workspace_check: '运行完整性检查',
        workspace_nav_label: 'RescueX 功能导航',
        boot_status: '启动状态',
        last_result: '上次启动结果',
        fail_count: '连续失败次数',
        boot_duration: '上次启动耗时',
        ota_mode: 'OTA 模式',
        watchdog: '看门狗',
        rescue_count: '救砖次数',
        system_timezone: '系统时区',
        webui_preference: 'WebUI 更新偏好',
        webui_preference_pending: '等待首次确认',
        webui_preference_install: '以后自动安装',
        webui_preference_skip: '以后自动跳过',
        webui_preference_deferred: '暂不决定',
        webui_preference_title: '保存 WebUI 安装偏好',
        webui_preference_desc_install: '本次安装选择了 WebUI。以后更新模块时是否自动保留 WebUI，不再要求按音量键？',
        webui_preference_desc_skip: '本次更新保留了已有 WebUI。以后更新模块时是否自动跳过 WebUI？',
        webui_preference_install_action: '以后自动安装 WebUI',
        webui_preference_skip_action: '以后自动跳过 WebUI',
        webui_preference_defer_action: '暂不决定',
        webui_preference_saved_install: '已保存：以后自动安装 WebUI',
        webui_preference_saved_skip: '已保存：以后自动跳过 WebUI',
        webui_preference_deferred_toast: '本次不保存，下一次更新时仍会询问',
        webui_preference_save_failed: 'WebUI 安装偏好保存失败',
        webui_preference_unsupported: '当前版本无法读取 WebUI 安装偏好',
        fail_progress: '失败进度',
        config: '救砖参数',
        reboot_threshold: '连续重启阈值',
        threshold_hint: '达到此次数后触发全量救砖',
        boot_timeout: '开机超时',
        timeout_hint: '超时未完成开机则判定失败',
        ota_timeout: 'OTA 升级超时',
        ota_hint: '检测到 OTA 时使用此超时',
        ota_detection: '系统 OTA 检测',
        ota_detection_ready: '构建基线已就绪',
        ota_detection_missing: '等待下一次成功启动建立基线',
        ota_detection_active: '本次已启用 OTA 长超时',
        ota_detection_inactive: '本次未检测到 OTA',
        ota_detection_manual_pending: '手动保护待确认',
        ota_detection_source_manual: '手动保护',
        ota_detection_source_build_baseline: '系统构建变化',
        ota_detection_source_vendor_signal: '厂商更新信号',
        ota_detection_vendor_reason: '厂商信号原因',
        ota_detection_source_legacy: '兼容更新信号',
        ota_detection_source_none: '未检测',
        ota_manual_guard: '设置/清除 OTA 手动保护',
        ota_manual_arm_title: '设置 OTA 手动保护',
        ota_manual_arm_desc: '下次启动将使用 OTA 超时；确认启动成功后会自动清除。是否继续？',
        ota_manual_clear_title: '清除 OTA 手动保护',
        ota_manual_clear_desc: '将取消下次启动的 OTA 长超时保护。是否继续？',
        ota_manual_armed: 'OTA 手动保护已设置',
        ota_manual_cleared: 'OTA 手动保护已清除',
        ota_manual_failed: 'OTA 手动保护操作失败',
        grace_period: '用户重启宽限期',
        grace_hint: '短时间内重启不计入失败',
        advanced: '高级选项',
        opt_log: '记录详细启动日志',
        opt_progressive: '渐进式救砖（先禁用最近安装的模块）',
        opt_autoreenable: '救砖后自动恢复模块（实验性）',
        opt_dryrun: 'DRY_RUN 模式（仅记录日志不真禁用）',
        save_config: '保存配置',
        export_config: '导出配置',
        import_config: '导入配置',
        // v2.4 补丁更新
        patch_update: '补丁更新',
        patch_detected: '检测到补丁更新',
        patch_fail_count: '补丁失败次数',
        patch_timeout: '补丁更新超时',
        patch_timeout_hint: '补丁更新时使用此超时（默认 180 秒）',
        patch_fail_threshold: '补丁失败阈值',
        patch_fail_threshold_hint: '达到此次数后回滚补丁（不清整机）',
        opt_patch_auto_rollback: '补丁失败自动回滚（保留用户数据）',
        toggle_patch_flag: '设置/清除补丁标记',
        whitelist: '白名单模块',
        whitelist_desc: '救砖时不会被禁用的模块。勾选要保留的模块，保存即可。',
        refresh_modules: '刷新模块列表',
        save_whitelist: '保存白名单',
        module_status: '模块状态',
        module_status_desc: '当前被禁用的模块列表（含非 RescueX 禁用的）。',
        snapshots: '快照管理',
        snapshot_desc: '记录当前所有模块的启用/禁用状态，出问题可一键回滚。',
        take_snapshot: '拍快照',
        restore_baseline: '恢复稳定基线',
        no_snapshots: '暂无快照',
        actions: '手动操作',
        disable_all: '禁用所有模块',
        enable_all: '恢复所有模块',
        test_watchdog: '测试看门狗',
        reboot: '重启设备',
        generate_decision_report: '生成救援决策报告',
        generate_report: '生成诊断报告',
        logs: '日志与历史',
        log: '日志',
        history: '历史',
        refresh: '刷新',
        copy: '复制',
        export: '导出',
        clear: '清空',
        about: '关于',
        appearance: '外观',
        appearance_title: '选择 WebUI 外观',
        appearance_desc: '选择只影响界面样式和页面组织，不会改变救砖逻辑。',
        appearance_miuix: 'MIUI X 工作区',
        appearance_miuix_desc: '当前 RescueX 默认界面',
        appearance_md3: 'Material Design 3',
        appearance_md3_desc: '分组设置、列表行和 MD3 组件风格',
        appearance_monet: '莫奈取色（动态配色）',
        appearance_monet_desc: '读取系统已生成的 Material You 色阶应用到 MD3 主题',
        appearance_monet_md3_only: '仅在 Material Design 3 主题下可用',
        appearance_monet_unavailable: '未能读取系统配色，已保持默认色板',
        appearance_monet_seed_only: '未能读取系统色阶，已改用主题种子色近似',
        appearance_monet_source_platform: '已启用：使用系统真实 Material You 色阶',
        appearance_monet_source_seed: '已启用：仅读到主题种子色，为近似配色',
        appearance_saved: '外观已切换',
        version: '版本',
        manager: '管理器',
        source_code: '源码',
        update_notice: '更新公告',
        update_notice_title: '手机端导航与 OTA 识别修复',
        update_notice_desc: 'v3.5.11 修复手机端底部导航无法切页、厂商 OTA 信号常驻误报，并新增 MIUI X / Material Design 3 外观选择、Monet 动态配色与持久化 WebUI 安装偏好。',
        check_update: '检查更新',
        checking_update: '正在检查更新...',
        update_available: '发现新版本',
        update_up_to_date: '当前已是最新版本',
        update_check_failed: '检查更新失败',
        open_source_repo: '开源仓库',
        view_releases: '版本发布',
        about_desc: 'RescueX 通过监控启动失败次数和开机超时，自动禁用问题模块以救砖。兼容 Magisk / KernelSU / APatch。v3.5.11 修复手机端导航与 OTA 信号误报，并新增可切换 WebUI 外观。',
        loading: '加载中...',
        // 状态文本
        status_ok: '系统正常',
        status_ok_meta: '上次启动成功',
        status_rescued: '已救砖',
        status_rescued_meta: '问题模块已被禁用',
        status_booting: '启动中',
        status_booting_meta: '系统正在启动',
        status_disabled: '模块已禁用',
        status_disabled_meta: 'RescueX 未生效',
        status_init: '初始化',
        status_init_meta: '首次运行',
        status_unknown: '未知',
        status_unknown_meta: '无状态数据',
        badge_ok: '正常',
        badge_rescued: '已救砖',
        badge_booting: '启动中',
        badge_disabled: '已禁用',
        badge_init: '初始化',
        badge_unknown: '未知',
        // 看门狗状态
        wd_running: '运行中',
        wd_idle: '未运行',
        // Toast
        saved: '已保存',
        save_failed: '保存失败',
        copied: '已复制到剪贴板',
        copy_failed: '复制失败',
        no_content: '无内容可复制',
        exported: '已导出',
        export_failed: '导出失败',
        refreshed: '已刷新',
        cleared: '已清空',
        // 模块状态
        mod_enabled: '启用',
        mod_disabled: '禁用',
        mod_no_modules: '未找到其他模块',
        mod_no_disabled: '当前没有被禁用的模块',
        // 快照
        snapshot_taken: '快照已创建',
        snapshot_restored: '快照已恢复，重启后生效',
        snapshot_deleted: '快照已删除',
        snapshot_failed: '操作失败',
        baseline_restored: '稳定基线已恢复，重启后生效',
        decision_report_title: '救援决策报告',
        // 确认对话框
        confirm_title: '确认操作',
        confirm_disable_all: '将禁用除 RescueX 和白名单外的全部模块，重启后生效。是否继续？',
        confirm_enable_all: '将移除所有模块的 disable 标记（不包括 RescueX）。是否继续？',
        confirm_test_wd: '将启动一个 10 秒短超时看门狗。10 秒后若 boot 未完成将触发救砖（禁用非白名单模块并重启）。建议先开启 DRY_RUN。是否继续？',
        confirm_reboot: '将立即重启设备。RescueX 会在下次启动时检查启动状态。是否继续？',
        confirm_clear: '此操作不可撤销。是否继续？',
        confirm_restore_baseline: '将按最近一次稳定基线恢复模块启用状态，重启后生效。是否继续？',
        btn_confirm: '确认',
        btn_cancel: '取消',
        // 操作结果
        disabled_count: '已禁用 N 个模块，重启后生效',
        enabled_count: '已恢复 N 个模块，重启后生效',
        // 报告
        report_title: '诊断报告',
        report_generated: '报告已生成',
        // 环境错误
        env_error_title: '不兼容的环境',
        env_error_desc: '当前未运行在 KernelSU / APatch / Magisk v27+ WebUI 容器中。',
        env_error_solution: '请在以下任意一个环境中打开本模块：',
        // 时钟
        clock_unsync: '时钟未同步',
        boot_error: '启动异常',
        // 单位
        seconds: '秒',
        // 配置导入导出
        config_exported: '配置已导出',
        config_imported: '配置已导入，重启后生效',
        config_import_failed: '配置文件格式错误',
        invalid_config: '配置文件无效',
        // 模块选择器
        select_all: '全选',
        deselect_all: '取消全选',
        // v2.5 新增
        stats_panel: '启动统计',
        success_rate: '启动成功率',
        avg_boot_time: '平均启动耗时',
        total_boots: '总启动次数',
        rescue_times: '救砖次数',
        success_count: '成功启动',
        failed_count: '失败启动',
        last_success: '最近成功',
        last_rescue: '最近救砖',
        watchdog_poll: '看门狗轮询间隔',
        watchdog_poll_hint: '长超时场景会自动放大（v2.5）',
        watchdog_engine: '看门狗后端',
        watchdog_engine_restart: '重启后生效',
        watchdog_engine_shell: 'Shell（兼容模式）',
        watchdog_engine_native: 'Native（原生模式）',
        watchdog_engine_hint: '原生模式仅在 arm64 且二进制自检通过时生效，失败自动回退 Shell。',
        watchdog_engine_status: '启动时后端',
        watchdog_engine_reason_shell_selected: '按配置使用 Shell',
        watchdog_engine_reason_not_arm64: '设备不是 arm64-v8a',
        watchdog_engine_reason_missing_binary: '原生二进制缺失',
        watchdog_engine_reason_not_executable: '原生二进制不可执行',
        watchdog_engine_reason_self_test_failed: '原生二进制自检失败',
        watchdog_engine_reason_ready: '原生二进制自检通过',
        opt_integrity: '启用轻量完整性自检（默认开启）',
        run_integrity_check: '立即检查完整性',
        integrity_title: 'RescueX 完整性自检',
        integrity_daemon: '自检守护',
        integrity_last_check: '最近检查',
        integrity_passed: '完整性检查通过',
        integrity_failed: '完整性检查发现异常',
        feature_intro: '功能介绍',
        privacy_policy: '隐私协议',
        usage_notice: '使用须知',
        // 引导
        onboarding_title: '欢迎使用 RescueX',
        onboarding_subtitle: '可靠的 Android 启动失败保护',
        onboarding_step1_title: '自动救砖',
        onboarding_step1_desc: '连续启动失败达到阈值（默认 3 次）或开机超时，自动禁用问题模块并重启，打破 bootloop。',
        onboarding_step2_title: '智能识别',
        onboarding_step2_desc: '区分 OTA 升级、系统补丁、用户主动重启，避免正常场景被误判为失败。Recovery/Fastboot 模式自动跳过计数。',
        onboarding_step3_title: '白名单保护',
        onboarding_step3_desc: '字体、音效等关键模块可加入白名单，救砖时不会被禁用。',
        onboarding_step4_title: 'DRY_RUN 验证',
        onboarding_step4_desc: '首次使用建议开启 DRY_RUN 模式，仅记录日志不实际禁用，验证逻辑符合预期后再正式启用。',
        onboarding_step5_title: 'WebUI 管理',
        onboarding_step5_desc: '所有参数、白名单、快照、诊断报告均可通过此 WebUI 管理。支持配置导入导出。',
        onboarding_ack: '我已了解，开始使用',
        onboarding_skip: '稍后再看',
        onboarding_new_features: 'v3.0 新功能',
        onboarding_new_features_desc: '三级渐进式救砖（嫌疑禁用→全量禁用→人工复核）、嫌疑模块精准追踪、保守 APP 状态保护',
        // 文档
        doc_close: '关闭',
        features_title: 'RescueX 功能介绍',
        privacy_title: 'RescueX 隐私协议',
        report_privacy_confirm: '诊断报告包含设备型号、系统版本、模块列表、配置、日志和启动历史。导出或分享前请确认你信任接收方。是否继续？',
        usage_title: 'RescueX 使用须知',
        // 其他
        never: '从未',
        just_now: '刚刚',
        minutes_ago: '分钟前',
        hours_ago: '小时前',
        days_ago: '天前',
        unknown_time: '未知',
        loading_failed: '加载失败，请刷新重试',
        stats_unavailable: '统计读取失败，请检查模块安装路径',
        // v2.7 新增
        audit_log: '救砖审计',
        audit_log_desc: '记录所有救砖操作的详细信息（操作类型、时间、影响的模块）。',
        no_audit: '暂无审计记录',
        toggle_enable: '启用',
        toggle_disable: '禁用',
        export_full: '导出完整状态',
        export_full_desc: '导出配置、白名单、启动状态、审计日志等全部数据。',
        boot_trend: '启动耗时趋势',
        custom_dirs_title: '自定义目录权限',
        custom_dirs_desc: '模块启动时自动对指定目录设置权限。默认仅对模块自身持久目录 /data/adb/rescuex_data 授予 770。',
        no_custom_dirs: '未设置自定义目录',
        add_custom_dir: '添加目录',
        save_custom_dirs: '保存',
        dir_path: '目录路径',
        dir_perms: '权限',
        // v3.0 新增
        suspect_panel: '嫌疑模块追踪',
        suspect_panel_desc: '启动成功后自动记录已知良好模块列表。下次启动失败时对比差异，精准定位新增/新启用的模块。',
        good_modules_count: '已知良好模块数',
        suspect_count: '最近检测嫌疑数',
        save_good_modules_now: '立即保存当前列表',
        clear_suspect_log: '清除嫌疑日志',
        reset_rescue_level: '重置救砖级别',
        unfreeze_apps: 'APP 解冻',
        rescue_level_label: '当前救砖级别',
        rescue_level_0: '级别 0: 精准嫌疑禁用',
        rescue_level_1: '级别 1: 全量+脚本锁定',
        rescue_level_2: '级别 2: APP 解冻（最后手段）',
        unfreeze_confirm: '将删除 package-restrictions.xml 来解冻所有被冻结的应用。操作后需重启。是否继续？',
        unfreeze_done: 'APP 解冻完成，请重启设备',
        unfreeze_skip: '未发现需要解冻的限制文件',
        good_modules_saved: '已知良好模块列表已保存',
        suspect_cleared: '嫌疑日志已清除',
        rescue_level_reset: '救砖级别已重置为 0',
        readiness_title: '救砖就绪度',
        readiness_baseline: '已知良好基线',
        readiness_policy: '目录权限策略',
        readiness_mode: '当前模式',
        readiness_level: '当前救砖级别',
        readiness_score_good: '就绪',
        readiness_score_warn: '关注',
        readiness_score_danger: '风险',
        readiness_mode_active: '正式保护',
        readiness_mode_dry: '演练模式',
        readiness_policy_clean: '安全',
        readiness_policy_risky: '待清理',
        readiness_baseline_missing: '未建立',
        readiness_baseline_ready: '已建立',
        readiness_item_baseline_ok_title: '基线已建立',
        readiness_item_baseline_ok_desc: '成功启动后会用它追踪新增和重新启用的模块。',
        readiness_item_baseline_missing_title: '缺少已知良好基线',
        readiness_item_baseline_missing_desc: '先在稳定状态下保存当前模块列表，后续才能精准命中嫌疑模块。',
        readiness_item_dry_title: '当前处于 DRY_RUN',
        readiness_item_dry_desc: '此模式只记录动作，适合验证逻辑。',
        readiness_item_mode_ok_title: '自动救砖已执行',
        readiness_item_mode_ok_desc: '启动失败达到条件后会实际禁用模块。',
        readiness_item_policy_ok_title: '目录权限范围安全',
        readiness_item_policy_ok_desc: '自定义目录限制在 RescueX 自身数据范围内。',
        readiness_item_policy_risky_title: '检测到历史目录配置超出安全范围',
        readiness_item_policy_risky_desc: '保存一次目录配置后会自动剔除超出白名单前缀的路径。',
        readiness_item_fail_warn_title: '失败计数已接近阈值',
        readiness_item_fail_warn_desc: '建议先拍快照并确认最近变更的模块。',
        readiness_item_level_warn_title: '当前处于升级救砖级别',
        readiness_item_level_warn_desc: '最近一轮救砖已经进入更激进的策略。',
        readiness_item_watchdog_warn_title: '启动中但看门狗未确认存活',
        readiness_item_watchdog_warn_desc: '建议检查 watchdog.sh 权限和宿主执行环境。',
        readiness_item_disabled_title: 'RescueX 当前处于禁用状态',
        readiness_item_disabled_desc: '禁用后不会执行自动救砖。',
        custom_dir_invalid: '目录不在允许范围内',
        custom_dir_rejected: '已过滤 N 条超出安全范围的目录配置',
    },
    en: {
        current_status: 'Current Status',
        v35_tools_title: 'Diagnostics & one-shot safe mode',
        v35_tools_desc: 'The simulator is read-only. One-shot safe mode journals the exact recovery set and restores only markers created by this operation.',
        v35_simulate: 'Run read-only simulation',
        v35_status: 'Refresh safe mode status',
        v35_arm: 'Safe mode for next boot only',
        v35_cancel: 'Cancel and restore exactly',
        v35_export: 'Export redacted diagnostic bundle',
        v35_ready: 'Ready. Diagnostic bundles contain only redacted status and log summaries.',
        workspace_overview: 'Overview',
        workspace_protection: 'Protection',
        workspace_modules: 'Modules',
        workspace_settings: 'Protection',
        workspace_recovery: 'Recovery',
        workspace_logs: 'Logs & reports',
        workspace_tools: 'Tools & logs',
        workspace_refresh: 'Refresh status',
        workspace_check: 'Run integrity check',
        workspace_nav_label: 'RescueX navigation',
        module_search_label: 'Search modules',
        module_search: 'Search modules…',
        module_filter_all: 'All states',
        module_filter_enabled: 'Enabled',
        module_filter_disabled: 'Disabled',
        module_selected: '{n} selected',
        boot_status: 'Boot Status',
        last_result: 'Last Result',
        fail_count: 'Fail Count',
        boot_duration: 'Boot Duration',
        ota_mode: 'OTA Mode',
        watchdog: 'Watchdog',
        rescue_count: 'Rescue Count',
        system_timezone: 'System time zone',
        webui_preference: 'WebUI update preference',
        webui_preference_pending: 'Awaiting first confirmation',
        webui_preference_install: 'Install automatically',
        webui_preference_skip: 'Skip automatically',
        webui_preference_deferred: 'Not decided',
        webui_preference_title: 'Save WebUI installation preference',
        webui_preference_desc_install: 'This install selected WebUI. Should future module updates keep WebUI automatically without asking for a volume key?',
        webui_preference_desc_skip: 'This update kept the existing WebUI. Should future module updates skip WebUI automatically?',
        webui_preference_install_action: 'Always install WebUI',
        webui_preference_skip_action: 'Always skip WebUI',
        webui_preference_defer_action: 'Decide later',
        webui_preference_saved_install: 'Saved: WebUI will be installed automatically',
        webui_preference_saved_skip: 'Saved: WebUI will be skipped automatically',
        webui_preference_deferred_toast: 'Not saved; the next update will ask again',
        webui_preference_save_failed: 'Could not save the WebUI installation preference',
        webui_preference_unsupported: 'This version cannot read the WebUI installation preference',
        fail_progress: 'Fail Progress',
        config: 'Configuration',
        reboot_threshold: 'Reboot Threshold',
        threshold_hint: 'Trigger full rescue after this many failures',
        boot_timeout: 'Boot Timeout',
        timeout_hint: 'Fail if boot not completed within this time',
        ota_timeout: 'OTA Timeout',
        ota_hint: 'Used when OTA update is detected',
        ota_detection: 'System OTA Detection',
        ota_detection_ready: 'Build baseline ready',
        ota_detection_missing: 'Baseline will be created after the next successful boot',
        ota_detection_active: 'OTA timeout active for this boot',
        ota_detection_inactive: 'No OTA detected for this boot',
        ota_detection_manual_pending: 'Manual guard pending confirmation',
        ota_detection_source_manual: 'Manual guard',
        ota_detection_source_build_baseline: 'System build changed',
        ota_detection_source_vendor_signal: 'Vendor update signal',
        ota_detection_vendor_reason: 'Vendor signal reason',
        ota_detection_source_legacy: 'Compatibility signal',
        ota_detection_source_none: 'Not detected',
        ota_manual_guard: 'Set/Clear OTA Manual Guard',
        ota_manual_arm_title: 'Set OTA Manual Guard',
        ota_manual_arm_desc: 'The next boot will use the OTA timeout and the guard clears after a confirmed successful boot. Continue?',
        ota_manual_clear_title: 'Clear OTA Manual Guard',
        ota_manual_clear_desc: 'This cancels the OTA timeout guard for the next boot. Continue?',
        ota_manual_armed: 'OTA manual guard set',
        ota_manual_cleared: 'OTA manual guard cleared',
        ota_manual_failed: 'OTA manual guard operation failed',
        grace_period: 'Reboot Grace Period',
        grace_hint: 'Short reboots not counted as failures',
        advanced: 'Advanced',
        opt_log: 'Enable detailed boot logging',
        opt_progressive: 'Progressive rescue (disable recently installed first)',
        opt_autoreenable: 'Auto re-enable modules after rescue (experimental)',
        opt_dryrun: 'DRY_RUN mode (log only, no actual disable)',
        save_config: 'Save Config',
        export_config: 'Export',
        import_config: 'Import',
        // v2.4 patch update
        patch_update: 'Patch Update',
        patch_detected: 'Patch Detected',
        patch_fail_count: 'Patch Fail Count',
        patch_timeout: 'Patch Update Timeout',
        patch_timeout_hint: 'Used when patch update is detected (default 180s)',
        patch_fail_threshold: 'Patch Fail Threshold',
        patch_fail_threshold_hint: 'Roll back patch after this many failures (no data wipe)',
        opt_patch_auto_rollback: 'Auto roll back patch on failure (preserve user data)',
        toggle_patch_flag: 'Set/Clear Patch Flag',
        whitelist: 'Whitelist',
        whitelist_desc: 'Modules that will NOT be disabled during rescue. Check the ones to keep.',
        refresh_modules: 'Refresh Module List',
        save_whitelist: 'Save Whitelist',
        module_status: 'Module Status',
        module_status_desc: 'Currently disabled modules (including those disabled by other tools).',
        snapshots: 'Snapshots',
        snapshot_desc: 'Record current enable/disable state of all modules. Roll back when something goes wrong.',
        take_snapshot: 'Take Snapshot',
        restore_baseline: 'Restore Baseline',
        no_snapshots: 'No snapshots yet',
        actions: 'Actions',
        disable_all: 'Disable All',
        enable_all: 'Enable All',
        test_watchdog: 'Test Watchdog',
        reboot: 'Reboot',
        generate_decision_report: 'Decision Report',
        generate_report: 'Generate Report',
        logs: 'Logs & History',
        log: 'Log',
        history: 'History',
        refresh: 'Refresh',
        copy: 'Copy',
        export: 'Export',
        clear: 'Clear',
        about: 'About',
        appearance: 'Appearance',
        appearance_title: 'Choose WebUI appearance',
        appearance_desc: 'This changes only the interface style and layout, not rescue behavior.',
        appearance_miuix: 'MIUI X workspace',
        appearance_miuix_desc: 'Current RescueX default interface',
        appearance_md3: 'Material Design 3',
        appearance_md3_desc: 'Grouped settings, list rows, and MD3 components',
        appearance_monet: 'Monet dynamic color',
        appearance_monet_desc: 'Use the Material You tonal palette the system already generated for the MD3 theme',
        appearance_monet_md3_only: 'Available only with the Material Design 3 theme',
        appearance_monet_unavailable: 'Could not read a system palette; keeping the default colors',
        appearance_monet_seed_only: 'Could not read the system tonal palette; using a seed-color approximation',
        appearance_monet_source_platform: 'On: using the real system Material You palette',
        appearance_monet_source_seed: 'On: only a theme seed color was readable, so colors are approximated',
        appearance_saved: 'Appearance changed',
        version: 'Version',
        manager: 'Manager',
        source_code: 'Source',
        update_notice: 'Update Notice',
        update_notice_title: 'Mobile navigation and OTA detection fixes',
        update_notice_desc: 'v3.5.11 fixes mobile bottom-navigation switching and a persistent vendor OTA false positive, and adds MIUI X / Material Design 3 appearance selection, Monet dynamic color, and a persisted WebUI install preference.',
        check_update: 'Check Updates',
        checking_update: 'Checking updates...',
        update_available: 'Update available',
        update_up_to_date: 'Already on the latest version',
        update_check_failed: 'Update check failed',
        open_source_repo: 'Open Repository',
        open_external_browser: 'Opened in the system browser',
        open_external_copied: 'Could not open a browser; link copied',
        open_external_failed: 'Could not open the link',
        view_releases: 'View Releases',
        about_desc: 'RescueX monitors boot failures and auto-disables problematic modules to break bootloops. Compatible with Magisk / KernelSU / APatch. v3.5.11 fixes mobile navigation and OTA signal false positives, and adds switchable WebUI appearances.',
        loading: 'Loading...',
        status_ok: 'OPERATIONAL',
        status_ok_meta: 'Last boot succeeded',
        status_rescued: 'RESCUED',
        status_rescued_meta: 'Problematic modules disabled',
        status_booting: 'BOOTING',
        status_booting_meta: 'System is booting',
        status_disabled: 'DISABLED',
        status_disabled_meta: 'RescueX inactive',
        status_init: 'INITIALIZING',
        status_init_meta: 'First run',
        status_unknown: 'UNKNOWN',
        status_unknown_meta: 'No status data',
        badge_ok: 'OK',
        badge_rescued: 'RESCUED',
        badge_booting: 'BOOTING',
        badge_disabled: 'DISABLED',
        badge_init: 'INIT',
        badge_unknown: 'UNKNOWN',
        wd_running: 'Running',
        wd_idle: 'Idle',
        saved: 'Saved',
        save_failed: 'Save failed',
        copied: 'Copied to clipboard',
        copy_failed: 'Copy failed',
        no_content: 'Nothing to copy',
        exported: 'Exported',
        export_failed: 'Export failed',
        refreshed: 'Refreshed',
        cleared: 'Cleared',
        mod_enabled: 'Enabled',
        mod_disabled: 'Disabled',
        mod_no_modules: 'No other modules found',
        mod_no_disabled: 'No disabled modules',
        snapshot_taken: 'Snapshot created',
        snapshot_restored: 'Snapshot restored, effective after reboot',
        snapshot_deleted: 'Snapshot deleted',
        snapshot_failed: 'Operation failed',
        baseline_restored: 'Known-good baseline restored, effective after reboot',
        decision_report_title: 'Rescue Decision Report',
        confirm_title: 'Confirm',
        confirm_disable_all: 'This will disable all modules except RescueX and whitelisted ones. Effective after reboot. Continue?',
        confirm_enable_all: 'This will remove all disable marks (except RescueX). Continue?',
        confirm_test_wd: 'This will start a 10s short-timeout watchdog. If boot not completed in 10s, rescue will be triggered (disable non-whitelisted modules and reboot). Consider enabling DRY_RUN first. Continue?',
        confirm_reboot: 'Device will reboot immediately. RescueX will check boot status on next boot. Continue?',
        confirm_clear: 'This cannot be undone. Continue?',
        confirm_restore_baseline: 'Restore module states from the last known-good baseline. Effective after reboot. Continue?',
        btn_confirm: 'Confirm',
        btn_cancel: 'Cancel',
        disabled_count: 'Disabled N modules, effective after reboot',
        enabled_count: 'Enabled N modules, effective after reboot',
        report_title: 'Diagnostic Report',
        report_generated: 'Report generated',
        env_error_title: 'Incompatible Environment',
        env_error_desc: 'Not running in KernelSU / APatch / Magisk v27+ WebUI container.',
        env_error_solution: 'Please open this module in one of these environments:',
        clock_unsync: 'Clock unsynced',
        boot_error: 'Boot error',
        seconds: 's',
        config_exported: 'Config exported',
        config_imported: 'Config imported, effective after reboot',
        config_import_failed: 'Invalid config file format',
        invalid_config: 'Invalid config',
        select_all: 'Select All',
        deselect_all: 'Deselect All',
        // v2.5 新增
        stats_panel: 'Boot Statistics',
        success_rate: 'Success Rate',
        avg_boot_time: 'Avg Boot Time',
        total_boots: 'Total Boots',
        rescue_times: 'Rescue Times',
        success_count: 'Successful Boots',
        failed_count: 'Failed Boots',
        last_success: 'Last Success',
        last_rescue: 'Last Rescue',
        watchdog_poll: 'Watchdog Poll Interval',
        watchdog_poll_hint: 'Auto-scales for long timeouts (v2.5)',
        watchdog_engine: 'Watchdog Backend',
        watchdog_engine_restart: 'Effective after reboot',
        watchdog_engine_shell: 'Shell (compatibility)',
        watchdog_engine_native: 'Native',
        watchdog_engine_hint: 'Native mode requires arm64 and a passing binary self-test; failures fall back to Shell.',
        watchdog_engine_status: 'Boot backend',
        watchdog_engine_reason_shell_selected: 'Shell selected by configuration',
        watchdog_engine_reason_not_arm64: 'Device is not arm64-v8a',
        watchdog_engine_reason_missing_binary: 'Native binary is missing',
        watchdog_engine_reason_not_executable: 'Native binary is not executable',
        watchdog_engine_reason_self_test_failed: 'Native binary self-test failed',
        watchdog_engine_reason_ready: 'Native binary self-test passed',
        opt_integrity: 'Enable lightweight integrity checks (enabled by default)',
        run_integrity_check: 'Check integrity now',
        integrity_title: 'RescueX integrity check',
        integrity_daemon: 'Integrity daemon',
        integrity_last_check: 'Last check',
        integrity_passed: 'Integrity check passed',
        integrity_failed: 'Integrity check found an issue',
        feature_intro: 'Features',
        privacy_policy: 'Privacy',
        usage_notice: 'Usage Notice',
        // 引导
        onboarding_title: 'Welcome to RescueX',
        onboarding_subtitle: 'Reliable Android bootloop protection',
        onboarding_step1_title: 'Auto Rescue',
        onboarding_step1_desc: 'After consecutive boot failures reach threshold (default 3) or boot timeout, problematic modules are auto-disabled and device reboots to break bootloop.',
        onboarding_step2_title: 'Smart Detection',
        onboarding_step2_desc: 'Distinguishes OTA updates, system patches, user-initiated reboots to avoid false positives. Recovery/Fastboot modes are skipped.',
        onboarding_step3_title: 'Whitelist Protection',
        onboarding_step3_desc: 'Critical modules (fonts, audio, etc.) can be whitelisted to survive rescue operations.',
        onboarding_step4_title: 'DRY_RUN Validation',
        onboarding_step4_desc: 'For first-time use, enable DRY_RUN mode to log-only without actually disabling. Verify logic before enabling for real.',
        onboarding_step5_title: 'WebUI Management',
        onboarding_step5_desc: 'All parameters, whitelist, snapshots, diagnostic reports are managed via this WebUI. Config import/export supported.',
        onboarding_ack: 'Got it, start using',
        onboarding_skip: 'Later',
        onboarding_new_features: 'New in v3.0',
        onboarding_new_features_desc: 'Three-level rescue (suspect disable → full+scripts lock → APP unfreeze), suspect module tracking, script directory locking, APP auto-unfreeze',
        // 文档
        doc_close: 'Close',
        features_title: 'RescueX Features',
        privacy_title: 'RescueX Privacy Policy',
        report_privacy_confirm: 'The diagnostic report contains device model, system version, module list, config, logs, and boot history. Confirm you trust the recipient before exporting or sharing. Continue?',
        usage_title: 'RescueX Usage Notice',
        // 其他
        never: 'Never',
        just_now: 'Just now',
        minutes_ago: 'min ago',
        hours_ago: 'h ago',
        days_ago: 'd ago',
        unknown_time: 'Unknown',
        loading_failed: 'Load failed, please refresh',
        stats_unavailable: 'Stats unavailable, check module path',
        // v2.7 new
        audit_log: 'Rescue Audit',
        audit_log_desc: 'Detailed records of all rescue operations (type, time, affected modules).',
        no_audit: 'No audit records',
        toggle_enable: 'Enable',
        toggle_disable: 'Disable',
        export_full: 'Export Full State',
        export_full_desc: 'Export all data including config, whitelist, boot status, audit log, etc.',
        boot_trend: 'Boot Duration Trend',
        custom_dirs_title: 'Custom Directory Permissions',
        custom_dirs_desc: 'Automatically set permissions on specified directories at boot. Default: 770 on /data/adb/rescuex_data.',
        no_custom_dirs: 'No custom directories configured',
        add_custom_dir: 'Add Directory',
        save_custom_dirs: 'Save',
        dir_path: 'Directory Path',
        dir_perms: 'Permissions',
        // v3.0 new
        suspect_panel: 'Suspect Module Tracking',
        suspect_panel_desc: 'Automatically saves known-good module list after successful boot. On next boot failure, compares differences to pinpoint newly installed/enabled modules.',
        good_modules_count: 'Known Good Modules',
        suspect_count: 'Recent Suspects',
        save_good_modules_now: 'Save Current List Now',
        clear_suspect_log: 'Clear Suspect Log',
        reset_rescue_level: 'Reset Rescue Level',
        unfreeze_apps: 'APP Unfreeze',
        rescue_level_label: 'Current Rescue Level',
        rescue_level_0: 'Level 0: Precise Suspect Disable',
        rescue_level_1: 'Level 1: Full Disable + Lock Scripts',
        rescue_level_2: 'Level 2: APP Unfreeze (Last Resort)',
        unfreeze_confirm: 'This will delete package-restrictions.xml to unfreeze all frozen apps. Reboot required. Continue?',
        unfreeze_done: 'Apps unfrozen. Please reboot.',
        unfreeze_skip: 'No restriction files found.',
        good_modules_saved: 'Known good module list saved.',
        suspect_cleared: 'Suspect log cleared.',
        rescue_level_reset: 'Rescue level reset to 0.',
        readiness_title: 'Rescue Readiness',
        readiness_baseline: 'Known-good baseline',
        readiness_policy: 'Directory policy',
        readiness_mode: 'Current mode',
        readiness_level: 'Current rescue level',
        readiness_score_good: 'Ready',
        readiness_score_warn: 'Watch',
        readiness_score_danger: 'Risk',
        readiness_mode_active: 'Active',
        readiness_mode_dry: 'Dry run',
        readiness_policy_clean: 'Safe',
        readiness_policy_risky: 'Needs cleanup',
        readiness_baseline_missing: 'Missing',
        readiness_baseline_ready: 'Ready',
        readiness_item_baseline_ok_title: 'Known-good baseline is present',
        readiness_item_baseline_ok_desc: 'Successful boots can use it to track newly added or re-enabled modules.',
        readiness_item_baseline_missing_title: 'Known-good baseline is missing',
        readiness_item_baseline_missing_desc: 'Save the current module list while the device is stable to unlock precise suspect targeting.',
        readiness_item_dry_title: 'DRY_RUN is active',
        readiness_item_dry_desc: 'Actions are logged only and the setup stays in rehearsal mode.',
        readiness_item_mode_ok_title: 'Automatic rescue is active',
        readiness_item_mode_ok_desc: 'Modules will be disabled when boot failures hit the configured threshold.',
        readiness_item_policy_ok_title: 'Custom directory scope is safe',
        readiness_item_policy_ok_desc: 'Directory permissions stay inside RescueX-owned data paths.',
        readiness_item_policy_risky_title: 'Legacy directory entries exceed the safe scope',
        readiness_item_policy_risky_desc: 'Save the directory settings once to remove paths outside the allowed prefixes.',
        readiness_item_fail_warn_title: 'Failure count is close to the threshold',
        readiness_item_fail_warn_desc: 'Take a snapshot and review recent module changes now.',
        readiness_item_level_warn_title: 'Rescue escalation level is active',
        readiness_item_level_warn_desc: 'Recent rescue activity already moved into a more aggressive strategy.',
        readiness_item_watchdog_warn_title: 'Boot is in progress and watchdog is not confirmed',
        readiness_item_watchdog_warn_desc: 'Check watchdog.sh permissions and the host execution container.',
        readiness_item_disabled_title: 'RescueX is disabled',
        readiness_item_disabled_desc: 'Automatic rescue does not run while the module is disabled.',
        custom_dir_invalid: 'Path is outside the allowed scope',
        custom_dir_rejected: 'Filtered N directory entries outside the safe scope',
    }
};

class RescueXUI {
    constructor() {
        this.selfId = 'RescueX';
        this.setBasePath(DEFAULT_BASE_PATH);
        this.moduleBases = ALLOWED_BASES;

        this.config = {};
        this.refreshTimer = null;
        this.currentTab = 'log';
        this.isLoading = false;
        this.lang = localStorage.getItem('rescuex_lang') || 'zh';
        this.systemTimezone = 'UTC';
        this.uiTheme = (() => {
            try { return localStorage.getItem('rescuex_ui_theme') === 'md3' ? 'md3' : 'miuix'; } catch (_) { return 'miuix'; }
        })();
        this.monetEnabled = (() => {
            try { return localStorage.getItem('rescuex_ui_monet') === 'on'; } catch (_) { return false; }
        })();
        this.monetPalette = null;
        this.monetSource = '';
        this._syncAppearanceMonetRow = null;
        this.webuiPreferenceChecked = false;
        this.modulesCache = []; // 模块列表缓存
        this.firstRun = 0;      // v2.5: 首次运行标记（0=已确认，1=首次安装，2=从旧版升级）
        this.onboardingShown = false;
        this.lastStatus = null;
        this.goodModuleStats = { enabled: 0, total: 0 };
        this.rescueLevel = 0;
        this._customDirs = [];
        this.dashboardSnapshot = null;
        this.dashboardSnapshotFetchedAt = 0;
        this.dashboardSnapshotPromise = null;
        this._easterTapCount = 0;
        this._easterTapTimer = null;
        this._easterLangHits = [];
        this._easterSubtitleTimer = null;
        this._refreshInFlight = false;
        this._refreshSequence = 0;

        this.init();
    }

    async init() {
        // 环境检测：支持 KSU / Magisk v27+ / MMRL
        const hasKsu = typeof ksu !== 'undefined' && ksu.exec;
        const hasMagisk = typeof magisk !== 'undefined' && magisk.exec;
        // APatch WebUI hosts commonly expose the Magisk-compatible bridge; use
        // it when present while the shell backend detects APatch paths itself.
        const hasApatch = typeof apatch !== 'undefined' && apatch.exec;
        if (!hasKsu && !hasMagisk && !hasApatch) {
            this.showEnvError();
            return;
        }
        this.bridge = hasKsu ? ksu : (hasMagisk ? magisk : apatch);
        this.isApatch = !!hasApatch && !hasKsu && !hasMagisk;
        // 记录标记而非在别处直接比较 `this.bridge === ksu`：
        // 若宿主容器压根未声明 ksu 变量（而非设为 undefined），直接引用会在严格模式下抛 ReferenceError
        this.isKsu = !!hasKsu;
        this.allowedActions = new Set([
            'addCustomDir', 'checkUpdate', 'clearLog',
            'clearSuspectLog', 'copyAuditLog', 'copyLog', 'deleteSnapshot',
            'deselectAllModules', 'disableAllModules', 'exportConfig', 'exportFullState',
            'exportLog', 'generateDecisionReport', 'generateReport', 'importConfig',
            'openReleases', 'openRepository', 'rebootDevice',
            'reenableAllModules', 'refreshRescueTransaction', 'restoreRescueTransaction', 'refreshAuditLog', 'refreshLog', 'refreshModules',
            'refreshStats', 'removeCustomDir', 'resetRescueLevel', 'restoreBaseline',
            'restoreSnapshot', 'runIntegrityCheck', 'saveConfig', 'saveCustomDirs', 'saveGoodModules',
            'saveWhitelist', 'selectAllModules', 'showFeatures', 'showPrivacy', 'showAppearance',
            'showUsage', 'takeSnapshot', 'testWatchdog', 'toggleEnabled',
            'togglePatchFlag', 'toggleOtaManualGuard', 'unfreezeApps', 'v35RunSimulation', 'v35RefreshStatus',
            'v35ArmOneShotSafeMode', 'v35CancelOneShotSafeMode', 'v35ExportDiagnostic'
        ]);

        // 应用初始语言
        this.applyLang(this.lang);
        this.applyUiTheme(this.uiTheme, false);
        // Monet needs the bridge, so resolve the seed after paths are known.
        this.setupMonetSchemeWatcher();
        this.setupWorkspaceShell();

        // 事件委托
        document.body.addEventListener('click', (e) => {
            const target = e.target.closest('[data-action]');
            if (target) {
                const action = target.dataset.action;
                if (target.matches('input[type="checkbox"]')) {
                    if (this.allowedActions.has(action) && typeof this[action] === 'function') {
                        queueMicrotask(() => this[action](e, target));
                    }
                    return;
                }
                e.preventDefault();
                if (this.allowedActions.has(action) && typeof this[action] === 'function') this[action](e, target);
                return;
            }
            // v2.7: 单模块切换按钮
            const modToggle = e.target.closest('.mod-toggle');
            if (modToggle) {
                e.preventDefault();
                e.stopPropagation();
                const modId = modToggle.dataset.modId;
                const enable = modToggle.dataset.modEnabled !== '1';
                this.toggleModule(modId, enable);
                return;
            }
            const tab = e.target.closest('.tab');
            if (tab) this.switchTab(tab.dataset.tab);
            const langBtn = e.target.closest('.lang-btn');
            if (langBtn) this.switchLang(langBtn.dataset.lang);
        });

        // 输入校验
        ['cfg-threshold', 'cfg-timeout', 'cfg-ota-timeout', 'cfg-grace', 'cfg-patch-timeout', 'cfg-patch-fail-threshold', 'cfg-watchdog-poll'].forEach(id => {
            const el = this.qs(`#${id}`);
            if (el) el.addEventListener('blur', () => this.clampInput(el));
        });

        // v2.5: 帮助按钮
        const helpBtn = this.qs('#btn-help');
        if (helpBtn) helpBtn.addEventListener('click', () => this.showFeatures());

        this.setupEasterEggs();
        const moduleSearch = this.qs('#module-search');
        const moduleFilter = this.qs('#module-filter');
        const moduleList = this.qs('#module-list');
        if (moduleSearch) moduleSearch.addEventListener('input', () => this.filterModules());
        if (moduleFilter) moduleFilter.addEventListener('change', () => this.filterModules());
        const watchdogEngineToggle = this.qs('#cfg-watchdog-engine');
        if (watchdogEngineToggle) watchdogEngineToggle.addEventListener('change', () => this.renderWatchdogEngineChoice(watchdogEngineToggle.checked ? 'native' : 'shell'));
        if (moduleList) moduleList.addEventListener('change', event => {
            if (event.target.matches('.module-checkbox')) this.filterModules();
        });

        await this.resolvePaths();
        await this.loadAll();
        this.refreshMonet({ force: true });
        this.startAutoRefresh();
        // v2.5: 加载完成后检查是否需要显示引导
        this.checkFirstRun();  // v3.0.1: 非阻塞，不 await
        // WebUI preference is checked after onboarding so two blocking dialogs
        // never overlap on first entry.
        this.scheduleWebUiPreferenceCheck();
    }

    setBasePath(basePath) {
        this.basePath = basePath;
        this.stateDir = `${this.basePath}/webroot/state`;
        this.confFile = `${this.stateDir}/config.conf`;
        this.whitelistFile = `${this.stateDir}/whitelist.conf`;
        this.statusFile = `${this.stateDir}/boot_status`;
        this.historyFile = `${this.stateDir}/boot_history`;
        this.logFile = `${this.stateDir}/rescue.log`;
        this.watchdogPidFile = `${this.stateDir}/watchdog_pid`;
        this.snapshotDir = `${this.stateDir}/snapshots`;
        this.customDirsFile = `${this.stateDir}/custom_dirs.conf`;
        this.onboardingAckFile = `${this.stateDir}/onboarding_ack`;
    }

    async resolvePaths() {
        // v2.6.0 F-BUG-5 加固：
        //   1. 优先从 localStorage 读取上次解析结果，加速二次加载
        //   2. 探测管理器类型并相应调整默认路径（避免 KSU/APatch 用户静默被指向 Magisk）
        //   3. 解析全失败时输出 console.warn 与可见 toast，避免静默失败
        // v3.0.1 PERF: 如果有缓存路径，直接使用并后台验证，不阻塞 loadAll
        const cached = (() => {
            try { return localStorage.getItem('rescuex_base_path'); } catch (_) { return null; }
        })();
        if (cached && ALLOWED_BASES.some(b => cached === `${b}/${this.selfId}`)) {
            this.setBasePath(cached);
            // v3.0.1: 后台异步验证缓存路径，不阻塞 UI
            this._validatePathAsync(cached);
            return;
        }
        // 无缓存时同步解析（仅首次启动）
        await this._resolvePathsNow();
    }

    // 后台验证缓存路径是否仍然有效
    async _validatePathAsync(cachedPath) {
        const script = `[ -f "${cachedPath}/common.sh" ] && echo "1" || echo "0"`;
        try {
            const result = (await this.exec(script, 3000)).trim();
            if (result !== '1') {
                // 缓存失效，重新解析
                console.warn('[RescueX] cached path invalid, re-resolving');
                await this._resolvePathsNow();
            }
        } catch (e) {
            // 验证失败不影响已设置的路径
        }
    }

    // 同步解析路径（首次启动或缓存失效时）
    async _resolvePathsNow() {
        const candidates = ALLOWED_BASES.map(base => `${base}/${this.selfId}`);
        const script = `for d in ${candidates.join(' ')}; do
  [ -f "$d/common.sh" ] && { echo "$d"; exit 0; }
done`;
        let resolved = '';
        try {
            resolved = (await this.exec(script, 5000)).trim();
        } catch (e) {
            console.warn('[RescueX] resolvePaths exec failed:', e);
        }
        if (candidates.includes(resolved)) {
            this.setBasePath(resolved);
            try { localStorage.setItem('rescuex_base_path', resolved); } catch (_) {}
        } else {
            console.warn(`[RescueX] resolvePaths: no valid module path found in ${JSON.stringify(candidates)}, falling back to ${this.basePath}`);
            if (this.t) {
                try { this.toast(this.t('stats_unavailable'), 'warn'); } catch (_) {}
            }
        }
    }

    // === UI theme ===
    // v3.5.11: Monet reads the palette the Android framework actually generated,
    // not an approximation of one seed color. Android 12+ publishes the Material
    // You tonal palettes as framework color resources, and `cmd overlay lookup`
    // resolves them for the current user. That needs shell/root privileges,
    // which this module has, so `monet-palette.sh` reads the same colors the
    // system UI uses. A single seed color remains only as a labeled fallback.
    async loadMonetPalette() {
        const empty = { source: 'none', colors: {}, seed: '', style: '' };
        try {
            const result = await this.execStrict(`sh "${this.basePath}/monet-palette.sh" status`, 8000);
            if (!result.ok) return empty;
            const parsed = this.parseKV(result.stdout || '');
            const colors = {};
            Object.keys(parsed).forEach(key => {
                const match = key.match(/^MONET_(system_[a-z0-9_]+)$/);
                if (!match) return;
                const value = String(parsed[key] || '').trim();
                if (/^#[0-9a-fA-F]{6}$/.test(value)) colors[match[1]] = value.toLowerCase();
            });
            const seedRaw = String(parsed.MONET_SEED || '').trim();
            const seed = /^#[0-9a-fA-F]{6}$/.test(seedRaw) ? seedRaw.toLowerCase() : '';
            let source = 'none';
            if (parsed.MONET_SOURCE === 'platform_palette' && Object.keys(colors).length >= 12) {
                source = 'platform_palette';
            } else if (seed) {
                source = 'seed_approx';
            }
            return { source, colors, seed, style: String(parsed.MONET_STYLE || '').trim() };
        } catch (_) {
            return empty;
        }
    }

    hexToHsl(hex) {
        const value = String(hex || '').replace('#', '');
        if (!/^[0-9a-fA-F]{6}$/.test(value)) return null;
        const r = parseInt(value.slice(0, 2), 16) / 255;
        const g = parseInt(value.slice(2, 4), 16) / 255;
        const b = parseInt(value.slice(4, 6), 16) / 255;
        const max = Math.max(r, g, b);
        const min = Math.min(r, g, b);
        const l = (max + min) / 2;
        let h = 0;
        let s = 0;
        if (max !== min) {
            const d = max - min;
            s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
            if (max === r) h = ((g - b) / d + (g < b ? 6 : 0));
            else if (max === g) h = (b - r) / d + 2;
            else h = (r - g) / d + 4;
            h *= 60;
        }
        return { h, s: s * 100, l: l * 100 };
    }

    // Tone values follow the Material tonal-palette convention (0 = black,
    // 100 = white). Chroma is clamped so a very saturated wallpaper cannot
    // produce unreadable surfaces. Only used for the seed-only fallback.
    monetTone(hsl, tone, saturationScale = 1) {
        const s = Math.max(0, Math.min(100, hsl.s * saturationScale));
        return `hsl(${hsl.h.toFixed(1)} ${s.toFixed(1)}% ${Math.max(0, Math.min(100, tone)).toFixed(1)}%)`;
    }

    // Framework resource names map to fixed Material tones, so this mapping is
    // the standard M3 light/dark role assignment rather than a guess.
    monetRolesFromPalette(colors, dark) {
        const pick = (...names) => {
            for (const name of names) {
                if (colors[name]) return colors[name];
            }
            return '';
        };
        const roles = dark ? {
            bg: pick('system_neutral1_900'),
            surface: pick('system_neutral1_900'),
            surfaceStrong: pick('system_neutral1_800'),
            container: pick('system_neutral1_800'),
            ink: pick('system_neutral1_100'),
            muted: pick('system_neutral2_200', 'system_neutral1_500'),
            border: pick('system_neutral2_700'),
            primary: pick('system_accent1_200'),
            primarySoft: pick('system_accent1_700'),
            onPrimary: pick('system_accent1_800')
        } : {
            bg: pick('system_neutral1_10'),
            surface: pick('system_neutral1_10'),
            surfaceStrong: pick('system_neutral2_100'),
            container: pick('system_accent2_100', 'system_neutral2_100'),
            ink: pick('system_neutral1_900'),
            muted: pick('system_neutral2_700', 'system_neutral1_500'),
            border: pick('system_neutral2_200'),
            primary: pick('system_accent1_600'),
            primarySoft: pick('system_accent1_100'),
            onPrimary: pick('system_accent1_0')
        };
        return Object.values(roles).every(Boolean) ? roles : null;
    }

    monetRolesFromSeed(seed, dark) {
        const hsl = this.hexToHsl(seed);
        if (!hsl) return null;
        return dark ? {
            bg: this.monetTone(hsl, 10, 0.35),
            surface: this.monetTone(hsl, 15, 0.3),
            surfaceStrong: this.monetTone(hsl, 22, 0.3),
            container: this.monetTone(hsl, 20, 0.32),
            ink: this.monetTone(hsl, 92, 0.18),
            muted: this.monetTone(hsl, 74, 0.16),
            border: this.monetTone(hsl, 34, 0.26),
            primary: this.monetTone(hsl, 80, 0.72),
            primarySoft: this.monetTone(hsl, 30, 0.5),
            onPrimary: this.monetTone(hsl, 18, 0.5)
        } : {
            bg: this.monetTone(hsl, 98, 0.3),
            surface: this.monetTone(hsl, 100, 0.2),
            surfaceStrong: this.monetTone(hsl, 92, 0.3),
            container: this.monetTone(hsl, 95, 0.32),
            ink: this.monetTone(hsl, 14, 0.35),
            muted: this.monetTone(hsl, 40, 0.22),
            border: this.monetTone(hsl, 80, 0.28),
            primary: this.monetTone(hsl, 40, 0.85),
            primarySoft: this.monetTone(hsl, 90, 0.6),
            onPrimary: this.monetTone(hsl, 100, 0.15)
        };
    }

    applyMonetPalette(palette) {
        const root = document.documentElement;
        const names = [
            '--rx-monet-bg', '--rx-monet-surface', '--rx-monet-surface-strong',
            '--rx-monet-container', '--rx-monet-ink', '--rx-monet-muted',
            '--rx-monet-border', '--rx-monet-primary', '--rx-monet-primary-soft',
            '--rx-monet-on-primary'
        ];
        const clear = () => {
            names.forEach(name => root.style.removeProperty(name));
            root.dataset.uiMonet = 'off';
            delete root.dataset.uiMonetSource;
        };
        if (!palette || palette.source === 'none') { clear(); return ''; }
        const dark = !!(window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
        let roles = null;
        let source = '';
        if (palette.source === 'platform_palette') {
            roles = this.monetRolesFromPalette(palette.colors || {}, dark);
            if (roles) source = 'platform_palette';
        }
        if (!roles && palette.seed) {
            roles = this.monetRolesFromSeed(palette.seed, dark);
            if (roles) source = 'seed_approx';
        }
        if (!roles) { clear(); return ''; }
        const set = (name, value) => root.style.setProperty(name, value);
        set('--rx-monet-bg', roles.bg);
        set('--rx-monet-surface', roles.surface);
        set('--rx-monet-surface-strong', roles.surfaceStrong);
        set('--rx-monet-container', roles.container);
        set('--rx-monet-ink', roles.ink);
        set('--rx-monet-muted', roles.muted);
        set('--rx-monet-border', roles.border);
        set('--rx-monet-primary', roles.primary);
        set('--rx-monet-primary-soft', roles.primarySoft);
        set('--rx-monet-on-primary', roles.onPrimary);
        root.dataset.uiMonet = 'on';
        root.dataset.uiMonetSource = source;
        return source;
    }

    async refreshMonet(options = {}) {
        // Monet only styles the MD3 theme; the classic MIUI X look is left alone.
        if (!this.monetEnabled || this.uiTheme !== 'md3') {
            this.applyMonetPalette(null);
            return '';
        }
        if (!this.monetPalette || options.force) {
            this.monetPalette = await this.loadMonetPalette();
        }
        const source = this.applyMonetPalette(this.monetPalette);
        this.monetSource = source;
        if (options.notifyFailure) {
            if (!source) {
                this.toast(this.t('appearance_monet_unavailable'), 'warn', 3500);
            } else if (source === 'seed_approx') {
                this.toast(this.t('appearance_monet_seed_only'), 'warn', 3500);
            }
        }
        if (this._syncAppearanceMonetRow) this._syncAppearanceMonetRow();
        return source;
    }

    applyUiTheme(theme, persist = true) {
        const normalized = theme === 'md3' ? 'md3' : 'miuix';
        this.uiTheme = normalized;
        document.documentElement.dataset.uiTheme = normalized;
        if (persist) {
            try { localStorage.setItem('rescuex_ui_theme', normalized); } catch (_) {}
        }
        this.updateAppearanceToggle();
        this.refreshMonet();
    }

    updateAppearanceToggle() {
        const button = this.qs('#btn-appearance');
        if (!button) return;
        button.title = this.t('appearance_title');
        button.setAttribute('aria-label', this.t('appearance_title'));
    }

    setMonetEnabled(enabled, persist = true) {
        this.monetEnabled = !!enabled;
        if (persist) {
            try { localStorage.setItem('rescuex_ui_monet', this.monetEnabled ? 'on' : 'off'); } catch (_) {}
        }
        return this.refreshMonet({ force: true, notifyFailure: this.monetEnabled });
    }

    // Light/dark switches change the tonal targets, so recompute instead of
    // leaving stale inline variables behind.
    setupMonetSchemeWatcher() {
        if (!window.matchMedia) return;
        const query = window.matchMedia('(prefers-color-scheme: dark)');
        const handler = () => { this.refreshMonet(); };
        if (typeof query.addEventListener === 'function') query.addEventListener('change', handler);
        else if (typeof query.addListener === 'function') query.addListener(handler);
    }

    showAppearance() {
        const overlay = document.createElement('div');
        overlay.className = 'modal-overlay appearance-overlay';
        const modal = document.createElement('div');
        modal.className = 'modal appearance-modal';
        modal.setAttribute('role', 'dialog');
        modal.setAttribute('aria-modal', 'true');
        const title = document.createElement('h3');
        title.textContent = this.t('appearance_title');
        const desc = document.createElement('p');
        desc.textContent = this.t('appearance_desc');
        const options = document.createElement('div');
        options.className = 'appearance-options';
        const makeOption = (theme, titleKey, descKey) => {
            const option = document.createElement('button');
            option.type = 'button';
            option.className = 'appearance-option';
            option.dataset.theme = theme;
            option.setAttribute('aria-pressed', String(this.uiTheme === theme));
            const label = document.createElement('strong');
            label.textContent = this.t(titleKey);
            const detail = document.createElement('span');
            detail.textContent = this.t(descKey);
            option.append(label, detail);
            option.addEventListener('click', () => {
                this.applyUiTheme(theme);
                options.querySelectorAll('.appearance-option').forEach(node => {
                    node.setAttribute('aria-pressed', String(node.dataset.theme === theme));
                });
                if (this._syncAppearanceMonetRow) this._syncAppearanceMonetRow();
                this.toast(this.t('appearance_saved'), 'success');
            });
            return option;
        };
        options.append(
            makeOption('miuix', 'appearance_miuix', 'appearance_miuix_desc'),
            makeOption('md3', 'appearance_md3', 'appearance_md3_desc')
        );

        // Monet is an MD3-only option, so keep it visually attached to the
        // theme list instead of hiding it in a separate settings page.
        const monetRow = document.createElement('label');
        monetRow.className = 'appearance-monet';
        const monetInput = document.createElement('input');
        monetInput.type = 'checkbox';
        monetInput.checked = !!this.monetEnabled;
        const monetCopy = document.createElement('span');
        const monetTitle = document.createElement('strong');
        monetTitle.textContent = this.t('appearance_monet');
        const monetDesc = document.createElement('span');
        monetDesc.textContent = this.t('appearance_monet_desc');
        monetCopy.append(monetTitle, monetDesc);
        monetRow.append(monetInput, monetCopy);
        const syncMonetRow = () => {
            const available = this.uiTheme === 'md3';
            monetInput.disabled = !available;
            monetRow.classList.toggle('is-disabled', !available);
            if (!available) {
                monetDesc.textContent = this.t('appearance_monet_md3_only');
                return;
            }
            if (this.monetEnabled && this.monetSource === 'platform_palette') {
                monetDesc.textContent = this.t('appearance_monet_source_platform');
            } else if (this.monetEnabled && this.monetSource === 'seed_approx') {
                monetDesc.textContent = this.t('appearance_monet_source_seed');
            } else {
                monetDesc.textContent = this.t('appearance_monet_desc');
            }
        };
        monetInput.addEventListener('change', async () => {
            const source = await this.setMonetEnabled(monetInput.checked);
            if (monetInput.checked && !source) monetInput.checked = false;
            syncMonetRow();
            this.toast(this.t('appearance_saved'), 'success');
        });
        syncMonetRow();
        this._syncAppearanceMonetRow = syncMonetRow;
        const actions = document.createElement('div');
        actions.className = 'modal-buttons';
        const close = document.createElement('button');
        close.type = 'button';
        close.className = 'btn btn-text';
        close.textContent = this.t('doc_close');
        close.addEventListener('click', () => {
            this._syncAppearanceMonetRow = null;
            overlay.remove();
        });
        actions.appendChild(close);
        modal.append(title, desc, options, monetRow, actions);
        overlay.appendChild(modal);
        document.body.appendChild(overlay);
        close.focus();
        overlay.addEventListener('click', event => {
            if (event.target === overlay) {
                this._syncAppearanceMonetRow = null;
                overlay.remove();
            }
        });
    }

    // === i18n ===
    t(key) {
        return (I18N[this.lang] && I18N[this.lang][key]) || key;
    }

    applyLang(lang) {
        this.lang = lang;
        localStorage.setItem('rescuex_lang', lang);
        document.documentElement.lang = lang === 'zh' ? 'zh-CN' : 'en';
        document.querySelectorAll('.lang-btn').forEach(b => b.classList.toggle('active', b.dataset.lang === lang));
        document.querySelectorAll('[data-i18n]').forEach(el => {
            const key = el.dataset.i18n;
            el.textContent = this.t(key);
        });
        document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
            el.placeholder = this.t(el.dataset.i18nPlaceholder);
        });
        document.querySelectorAll('[data-i18n-aria-label]').forEach(el => {
            el.setAttribute('aria-label', this.t(el.dataset.i18nAriaLabel));
        });
        this.setDefaultSubtitle();
        const refreshButton = this.qs('.workspace-menu-btn');
        if (refreshButton) { refreshButton.title = this.t('workspace_refresh'); refreshButton.setAttribute('aria-label', this.t('workspace_refresh')); }
        const appearanceButton = this.qs('#btn-appearance');
        if (appearanceButton) this.updateAppearanceToggle();
    }

    async switchLang(lang) {
        if (lang === this.lang) return;
        this.recordLangEasterEgg();
        this.applyLang(lang);
        this.showLoading(true);
        try {
            const dashboardSnapshot = await this.getDashboardSnapshot({ force: true });
            await Promise.all([
                this.loadStatus({ snapshot: dashboardSnapshot }),
                this.loadModules(),
                this.loadDisabledModules(),
                this.loadSnapshots(),
                this.loadStats({ silent: true, snapshot: dashboardSnapshot }),
                this.loadAuditLog(),
                this.loadBootTrend(),
            ]);
        } finally {
            this.showLoading(false);
        }
    }

    showEnvError() {
        document.body.innerHTML = `
            <div class="container">
                <div class="env-error">
                    <h2>${this.t ? this.t('env_error_title') : '不兼容的环境'}</h2>
                    <p>${this.t ? this.t('env_error_desc') : '当前未运行在 KernelSU / APatch / Magisk v27+ WebUI 容器中。'}</p>
                    <p>${this.t ? this.t('env_error_solution') : '请在以下任意一个环境中打开本模块：'}</p>
                    <p style="margin-top:16px;">
                        • <strong>KernelSU 管理器</strong>（内置 WebUI）<br>
                        • <strong>Magisk v27+</strong>（内置 WebUI）<br>
                        • <strong>KsuWebUI</strong> / <strong>MMRL</strong> 应用
                    </p>
                </div>
            </div>
        `;
    }

    setDefaultSubtitle() {
        const el = this.qs('#app-subtitle');
        if (!el) return;
        el.classList.remove('easter-note');
        el.textContent = this.lang === 'zh' ? '自动救砖守护 v3.5.11' : 'Automatic Boot Rescue v3.5.11';
    }

    // v3.5.11: openExternal previously called a copyText() helper that never
    // existed, so the last-resort branch threw instead of giving the user the
    // URL. Provide a real clipboard fallback with a shell-side backup.
    async copyText(text) {
        const value = String(text || '');
        if (!value) return false;
        try {
            if (navigator.clipboard && navigator.clipboard.writeText) {
                await navigator.clipboard.writeText(value);
                return true;
            }
        } catch (_) {}
        try {
            const helper = document.createElement('textarea');
            helper.value = value;
            helper.setAttribute('readonly', 'readonly');
            helper.style.cssText = 'position:fixed;top:-1000px;left:-1000px;opacity:0;';
            document.body.appendChild(helper);
            helper.select();
            const ok = document.execCommand && document.execCommand('copy');
            helper.remove();
            if (ok) return true;
        } catch (_) {}
        return false;
    }

    // v3.5.11: Root-manager WebUI containers render pages inside their own
    // WebView. window.open keeps GitHub inside that container, where downloads
    // and sign-in usually fail. Hand the URL to the system browser instead and
    // only fall back to in-container navigation when no Activity can be started.
    async openExternal(url) {
        if (!url) return;
        const safe = String(url);
        if (!/^https?:\/\/[A-Za-z0-9._~:/?#@!$&'()*+,;=%-]*$/.test(safe)) {
            this.toast(this.t('open_external_failed'), 'error');
            return;
        }
        const quoted = `'${safe.replace(/'/g, "'\\''")}'`;
        try {
            const result = await this.execStrict(
                `am start -a android.intent.action.VIEW -d ${quoted} >/dev/null 2>&1 && echo OK`,
                8000
            );
            if (result.ok && result.stdout.includes('OK')) {
                this.toast(this.t('open_external_browser'), 'success', 2500);
                return;
            }
        } catch (_) {}
        try {
            if (typeof window.open === 'function') {
                const win = window.open(safe, '_blank');
                if (win) return;
            }
        } catch (_) {}
        try {
            window.location.href = safe;
        } catch (_) {
            const copied = await this.copyText(safe);
            this.toast(this.t(copied ? 'open_external_copied' : 'open_external_failed'), 'warn', 4000);
        }
    }

    openRepository() {
        return this.openExternal(REPO_URL);
    }

    openReleases() {
        return this.openExternal(RELEASES_URL);
    }

    async checkUpdate() {
        this.toast(this.t('checking_update'), '', 5000);
        try {
            const response = await fetch(UPDATE_JSON_URL, { cache: 'no-store' });
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const meta = await response.json();
            const remoteCode = parseInt(meta.versionCode, 10) || 0;
            const remoteVersion = String(meta.version || '').trim() || '--';
            if (remoteCode > APP_VERSION_CODE) {
                const recommended = meta.recommended === true || meta.priority === 'critical';
                const reason = String(meta.updateMessage || meta.releaseNotes || '').trim();
                const message = this.lang === 'zh'
                    ? `${recommended ? '【强烈推荐更新】' : ''}当前版本 ${APP_VERSION}，发现新版本 ${remoteVersion}。${reason ? `\n\n${reason}` : ''}\n\n是否前往 Releases 页面查看？`
                    : `${recommended ? '[Strongly Recommended] ' : ''}Current version ${APP_VERSION}. New version ${remoteVersion} is available.${reason ? `\n\n${reason}` : ''}\n\nOpen the Releases page?`;
                const confirm = await this.confirmDialog(this.t('update_available'), message, this.t('btn_confirm'), recommended ? 'btn-danger' : 'btn-filled');
                if (confirm) this.openExternal(RELEASES_URL);
                return;
            }
            this.toast(this.t('update_up_to_date'), 'success', 3500);
        } catch (_) {
            this.toast(this.t('update_check_failed'), 'error', 5000);
        }
    }

    setupEasterEggs() {
        const logo = this.qs('.logo-icon');
        if (logo) {
            logo.addEventListener('click', () => {
                this._easterTapCount += 1;
                clearTimeout(this._easterTapTimer);
                this._easterTapTimer = setTimeout(() => {
                    this._easterTapCount = 0;
                }, 3200);
                if (this._easterTapCount >= 5) {
                    this._easterTapCount = 0;
                    this.triggerLogoEasterEgg();
                }
            });
        }
    }

    triggerLogoEasterEgg() {
        const logo = this.qs('.logo-icon');
        const subtitle = this.qs('#app-subtitle');
        if (logo) {
            logo.classList.remove('easter-glow');
            void logo.offsetWidth;
            logo.classList.add('easter-glow');
            setTimeout(() => logo.classList.remove('easter-glow'), 1400);
        }
        if (subtitle) {
            clearTimeout(this._easterSubtitleTimer);
            subtitle.classList.add('easter-note');
            subtitle.textContent = this.lang === 'zh' ? '本次启动，先保平安。' : 'Keep this boot clean.';
            this._easterSubtitleTimer = setTimeout(() => this.setDefaultSubtitle(), 12000);
        }
        this.toast(this.lang === 'zh' ? '隐藏巡检模式已点亮' : 'Hidden inspection mode enabled', 'success', 2500);
    }

    recordLangEasterEgg() {
        const now = Date.now();
        this._easterLangHits = this._easterLangHits.filter(ts => now - ts < 4500);
        this._easterLangHits.push(now);
        if (this._easterLangHits.length >= 4) {
            this._easterLangHits = [];
            this.toast(this.lang === 'zh' ? '双语巡检完成' : 'Bilingual check complete', '', 2200);
        }
    }

    // === 桥接执行（统一 KSU / Magisk v27）===
    // v3.5.9: execStrict preserves exit code, timeout and exception state.
    // The legacy exec() wrapper remains for read-only calls that only need stdout.
    execStrict(cmd, timeoutMs = EXEC_DEFAULT_TIMEOUT_MS) {
        return new Promise(resolve => {
            const cb = `_rx_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
            let done = false;
            const timer = setTimeout(() => {
                if (done) return;
                done = true;
                delete window[cb];
                resolve({ ok: false, code: -1, stdout: '', timedOut: true, errorKind: 'timeout' });
            }, timeoutMs);
            window[cb] = (code, out) => {
                if (done) return;
                done = true;
                clearTimeout(timer);
                delete window[cb];
                const rc = parseInt(code, 10);
                resolve({ ok: rc === 0, code: isNaN(rc) ? -1 : rc, stdout: (out || '').trim(), timedOut: false, errorKind: null });
            };
            try {
                if (this.isKsu) { this.bridge.exec(cmd, '{}', cb); }
                else { this.bridge.exec(cmd, cb); }
            } catch (e) {
                if (done) return;
                done = true;
                clearTimeout(timer);
                delete window[cb];
                resolve({ ok: false, code: -1, stdout: '', timedOut: false, errorKind: 'exception' });
            }
        });
    }

    exec(cmd, timeoutMs = EXEC_DEFAULT_TIMEOUT_MS) {
        return this.execStrict(cmd, timeoutMs).then(r => r.stdout);
    }

    setupWorkspaceShell() {
        const root = this.qs('.container');
        const menuButton = this.qs('.workspace-menu-btn');
        const hero = this.qs('.status-hero');
        const tabs = root?.querySelector('.workspace-tabs');
        const homeActions = root?.querySelector('.workspace-home-actions');
        if (!root || !hero || !tabs) return;

        // Group membership is declared in index.html. JS only controls visibility.
        const setView = view => {
            const validViews = new Set(['overview', 'protection', 'modules', 'recovery', 'logs']);
            const next = validViews.has(view) ? view : 'overview';
            root.dataset.workspaceView = next;
            hero.classList.toggle('workspace-hidden', next !== 'overview');
            tabs.querySelectorAll('[data-workspace-view]').forEach(button => {
                const active = button.dataset.workspaceView === next;
                button.classList.toggle('active', active);
                button.setAttribute('aria-current', active ? 'page' : 'false');
            });
            root.querySelectorAll('.card[data-workspace-group]').forEach(card => {
                card.classList.toggle('workspace-hidden', card.dataset.workspaceGroup !== next);
            });
            if (homeActions) homeActions.hidden = next !== 'overview';
            window.scrollTo({ top: 0, behavior: 'auto' });
        };
        tabs.querySelectorAll('[data-workspace-view]').forEach(button => {
            button.addEventListener('click', () => setView(button.dataset.workspaceView));
        });
        homeActions?.querySelectorAll('[data-workspace-command]').forEach(button => {
            button.addEventListener('click', () => {
                const command = button.dataset.workspaceCommand;
                if (command === 'refresh') this.refreshWorkspace();
                if (command === 'check') this.runIntegrityCheck();
                if (command === 'settings') setView('protection');
            });
        });
        if (menuButton) {
            menuButton.textContent = '↻';
            menuButton.title = this.t('workspace_refresh');
            menuButton.setAttribute('aria-label', this.t('workspace_refresh'));
            menuButton.addEventListener('click', () => this.refreshWorkspace());
        }
        this._workspaceSetView = setView;
        setView(root.dataset.workspaceView || 'overview');
    }

    async refreshWorkspace() {
        if (this._refreshInFlight) return;
        this._refreshInFlight = true;
        try {
            await this.loadAll();
            this.toast(this.lang === 'zh' ? '状态已更新' : 'Status updated', 'success');
        } catch (error) {
            this.toast(this.lang === 'zh' ? '状态刷新失败，请重试' : 'Status refresh failed. Try again.', 'error');
        } finally {
            this._refreshInFlight = false;
        }
    }

    qs(s) { return document.querySelector(s); }
    setText(s, t) { const e = this.qs(s); if (e) e.textContent = t; }
    setVal(s, v) { const e = this.qs(s); if (e) e.value = v; }
    setChecked(s, v) { const e = this.qs(s); if (e) e.checked = v; }

    showLoading(yes) {
        const bar = this.qs('#loading-bar');
        if (bar) bar.classList.toggle('show', yes);
        this.isLoading = yes;
    }

    toast(msg, type = '', duration) {
        const t = this.qs('#toast');
        t.textContent = msg;
        t.className = `toast show ${type}`;
        const dur = duration || (type === 'error' ? 5000 : (type === 'warn' ? 3500 : 2500));
        clearTimeout(this._toastTimer);
        this._toastTimer = setTimeout(() => { t.className = 'toast'; }, dur);
    }

    clampInput(el) {
        const min = parseInt(el.min);
        const max = parseInt(el.max);
        let v = parseInt(el.value) || min;
        v = Math.max(min, Math.min(max, v));
        el.value = v;
    }

    parseKV(raw) {
        const obj = {};
        if (!raw) return obj;
        raw.split('\n').forEach(line => {
            const idx = line.indexOf('=');
            if (idx <= 0) return;
            const k = line.slice(0, idx).trim();
            const v = line.slice(idx + 1).trim();
            if (k) obj[k] = v;
        });
        return obj;
    }

    escapeHtml(s) {
        return String(s).replace(/[&<>"']/g, c => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
        })[c]);
    }

    getSafeCustomDirPrefixes() {
        return [
            '/data/adb/rescuex_data',
            `${this.stateDir}`,
            `${this.snapshotDir}`,
            '/data/local/tmp/RescueX'
        ].map(p => p.replace(/\/+$/, ''));
    }

    normalizeCustomDirPath(path) {
        return String(path || '').trim().replace(/\/+$/, '');
    }

    isSafeCustomDirPath(path) {
        const normalized = this.normalizeCustomDirPath(path);
        if (!normalized.startsWith('/')) return false;
        if (!normalized || /\s/.test(normalized) || normalized.includes('..')) return false;
        if (/[*?\[\]]/.test(normalized)) return false;
        return this.getSafeCustomDirPrefixes().some(prefix => normalized === prefix || normalized.startsWith(`${prefix}/`));
    }

    renderReadiness() {
        const list = this.qs('#readiness-list');
        const scoreEl = this.qs('#readiness-score');
        if (!list || !scoreEl) return;

        const status = this.lastStatus || {};
        const goodStats = this.goodModuleStats || { enabled: 0, total: 0 };
        const entries = this._customDirs || [];
        const unsafeCount = entries.filter(item => item && item.valid === false).length;
        const result = status.result || 'UNKNOWN';
        const failCount = status.failCount || 0;
        const threshold = parseInt(this.config.REBOOT_THRESHOLD || '3', 10) || 3;
        const enabled = this.config.ENABLED !== 'false';
        const dryRun = this.config.DRY_RUN === 'true';

        let score = 100;
        const items = [];
        const pushItem = (type, titleKey, descKey) => {
            items.push({ type, title: this.t(titleKey), desc: this.t(descKey) });
        };

        if (goodStats.total > 0) {
            pushItem('ok', 'readiness_item_baseline_ok_title', 'readiness_item_baseline_ok_desc');
        } else {
            score -= 30;
            pushItem('danger', 'readiness_item_baseline_missing_title', 'readiness_item_baseline_missing_desc');
        }

        if (enabled) {
            if (dryRun) {
                score -= 10;
                pushItem('warn', 'readiness_item_dry_title', 'readiness_item_dry_desc');
            } else {
                pushItem('ok', 'readiness_item_mode_ok_title', 'readiness_item_mode_ok_desc');
            }
        } else {
            score -= 45;
            pushItem('danger', 'readiness_item_disabled_title', 'readiness_item_disabled_desc');
        }

        if (unsafeCount > 0) {
            score -= 25;
            pushItem('danger', 'readiness_item_policy_risky_title', 'readiness_item_policy_risky_desc');
        } else {
            pushItem('ok', 'readiness_item_policy_ok_title', 'readiness_item_policy_ok_desc');
        }

        if (failCount >= Math.max(1, threshold - 1)) {
            score -= 20;
            pushItem('warn', 'readiness_item_fail_warn_title', 'readiness_item_fail_warn_desc');
        }

        if (this.rescueLevel > 0) {
            score -= 10 + (this.rescueLevel * 5);
            pushItem('warn', 'readiness_item_level_warn_title', 'readiness_item_level_warn_desc');
        }

        if (result === 'BOOTING' && !status.watchdogAlive) {
            score -= 15;
            pushItem('warn', 'readiness_item_watchdog_warn_title', 'readiness_item_watchdog_warn_desc');
        }

        score = Math.max(0, Math.min(100, score));
        const scoreLabel = score >= 85 ? this.t('readiness_score_good') : (score >= 60 ? this.t('readiness_score_warn') : this.t('readiness_score_danger'));
        scoreEl.textContent = `${score} ${scoreLabel}`;
        scoreEl.className = `badge ${score >= 85 ? 'badge-ok' : (score >= 60 ? 'badge-warn' : 'badge-err')}`;

        this.setText('#readiness-baseline', goodStats.total > 0 ? `${this.t('readiness_baseline_ready')} (${goodStats.enabled}/${goodStats.total})` : this.t('readiness_baseline_missing'));
        this.setText('#readiness-policy', unsafeCount > 0 ? `${this.t('readiness_policy_risky')} (${unsafeCount})` : this.t('readiness_policy_clean'));
        this.setText('#readiness-mode', enabled ? (dryRun ? this.t('readiness_mode_dry') : this.t('readiness_mode_active')) : this.t('badge_disabled'));
        this.setText('#readiness-level', this.t(`rescue_level_${Math.min(2, Math.max(0, this.rescueLevel))}`));

        list.innerHTML = items.map(item => `
            <div class="readiness-item ${item.type}">
                <div>
                    <strong>${this.escapeHtml(item.title)}</strong>
                    <span>${this.escapeHtml(item.desc)}</span>
                </div>
            </div>
        `).join('');
    }

    isSafeSnapshotPath(path) {
        if (!path || !path.startsWith(`${this.snapshotDir}/snap-`) || !path.endsWith('.txt')) return false;
        const name = path.slice(this.snapshotDir.length + 1);
        return /^snap-[A-Za-z0-9._-]+\.txt$/.test(name);
    }

    // === 加载 ===
    async loadAll() {
        this.showLoading(true);
        document.body.classList.add('app-loading');
        try {
            await this.loadConfig();
            const dashboardSnapshot = await this.getDashboardSnapshot({ force: true });
            // v3.0.1 PERF: 并行加载所有面板数据（10个并发请求）
            await Promise.all([
                this.loadStatus({ snapshot: dashboardSnapshot }),
                this.loadWhitelist(),
                this.loadModules(),
                this.loadDisabledModules(),
                this.loadSnapshots(),
                this.loadStats({ snapshot: dashboardSnapshot }),
                this.loadAuditLog(),
                this.loadCustomDirs(),
                this.loadSuspectModules(),
                this.loadRescueLevel(),
            ]);
            // v3.0.1 PERF: 日志、历史、趋势图、管理器检测也并行
            await Promise.all([
                this.loadLog(),
                this.loadHistory(),
                this.loadBootTrend(),
                this.detectManager()
            ]);
            this.renderReadiness();
        } catch (e) {
            this.toast(this.t('loading_failed'), 'error');
        } finally {
            document.body.classList.remove('app-loading');
            this.showLoading(false);
        }
    }
    formatTimeValue(value) {
        const text = String(value || '').trim();
        if (/^[0-9]+$/.test(text)) {
            return this.formatTime(parseInt(text, 10));
        }
        return text || '--';
    }

    formatOtaSource(source) {
        const normalized = String(source || 'none').toLowerCase();
        const key = `ota_detection_source_${normalized}`;
        const label = this.t(key);
        return label === key ? this.t('ota_detection_source_none') : label;
    }

    renderOtaDetection(snapshot, detected) {
        const stateEl = this.qs('#ota-detection-state');
        if (!stateEl) return;
        const baselineReady = snapshot.OTA_BASELINE_READY === 'true';
        const manualPending = snapshot.OTA_MANUAL_PENDING === 'true';
        const source = this.formatOtaSource(snapshot.OTA_DETECTION_SOURCE || 'none');
        const primary = detected
            ? `${this.t('ota_detection_active')} (${source})`
            : (baselineReady ? this.t('ota_detection_ready') : this.t('ota_detection_missing'));
        const vendorReason = snapshot.OTA_VENDOR_REASON || '';
        if (vendorReason && vendorReason !== 'none') {
            stateEl.title = `${this.t('ota_detection_vendor_reason')}: ${vendorReason}`;
            stateEl.setAttribute('aria-label', `${primary}. ${this.t('ota_detection_vendor_reason')}: ${vendorReason}`);
        } else {
            stateEl.removeAttribute('title');
            stateEl.removeAttribute('aria-label');
        }
        stateEl.textContent = manualPending && !detected
            ? `${primary} · ${this.t('ota_detection_manual_pending')}`
            : primary;
    }

    async toggleOtaManualGuard() {
        let snapshot;
        try {
            snapshot = await this.getDashboardSnapshot({ force: true });
        } catch (_) {
            this.toast(this.t('ota_manual_failed'), 'error');
            return;
        }
        const active = snapshot.OTA_MANUAL_PENDING === 'true';
        const confirmed = await this.confirmDialog(
            this.t(active ? 'ota_manual_clear_title' : 'ota_manual_arm_title'),
            this.t(active ? 'ota_manual_clear_desc' : 'ota_manual_arm_desc'),
            this.t('btn_confirm'),
            active ? 'btn-filled' : 'btn-tonal'
        );
        if (!confirmed) return;
        const action = active ? 'ota_clear_manual_flag' : 'ota_set_manual_flag webui';
        try {
            const result = await this.execStrict(`. "${this.basePath}/common.sh" 2>/dev/null && ${action} && echo OK`);
            if (!result.ok || !result.stdout.includes('OK')) throw new Error('ota manual guard command failed');
            this.toast(this.t(active ? 'ota_manual_cleared' : 'ota_manual_armed'), 'success');
            this.dashboardSnapshot = null;
            await this.loadStatus({ force: true });
        } catch (_) {
            this.toast(this.t('ota_manual_failed'), 'error');
        }
    }

    async loadConfig() {
        try {
            const raw = await this.exec(`cat "${this.confFile}" 2>/dev/null`);
            const cfg = this.parseKV(raw);
            this.config = cfg;
            this.setChecked('#cfg-enabled', cfg.ENABLED !== 'false');
            this.setVal('#cfg-threshold', cfg.REBOOT_THRESHOLD || 3);
            this.setVal('#cfg-timeout', cfg.BOOT_TIMEOUT_SEC || 90);
            this.setVal('#cfg-ota-timeout', cfg.OTA_TIMEOUT_SEC || 900);
            this.setVal('#cfg-grace', cfg.USER_REBOOT_GRACE_SEC || 30);
            this.setChecked('#cfg-log', cfg.LOG_ENABLED !== 'false');
            this.setChecked('#cfg-progressive', cfg.PROGRESSIVE_RESCUE !== 'false');
            this.setChecked('#cfg-auto-reenable', cfg.AUTO_REENABLE === 'true');
            this.setChecked('#cfg-dry-run', cfg.DRY_RUN === 'true');
            // v2.4: 补丁更新配置
            this.setVal('#cfg-patch-timeout', cfg.PATCH_UPDATE_TIMEOUT_SEC || 180);
            this.setVal('#cfg-patch-fail-threshold', cfg.PATCH_FAIL_THRESHOLD || 2);
            this.setChecked('#cfg-patch-auto-rollback', cfg.PATCH_AUTO_ROLLBACK !== 'false');
            // v2.5: 看门狗轮询间隔
            this.setVal('#cfg-watchdog-poll', cfg.WATCHDOG_POLL_INTERVAL_SEC || 2);
            this.renderWatchdogEngineChoice(cfg.WATCHDOG_ENGINE === 'native' ? 'native' : 'shell');
            this.setChecked('#cfg-integrity-enabled', cfg.INTEGRITY_CHECK_ENABLED !== 'false');
            await this.loadWatchdogEngineStatus(cfg.WATCHDOG_ENGINE || 'shell');
        } catch (e) {
            this.setDefaults();
        }
    }

    setDefaults() {
        this.config = {
            ENABLED: 'true', REBOOT_THRESHOLD: '3',
            BOOT_TIMEOUT_SEC: '90', OTA_TIMEOUT_SEC: '900',
            LOG_ENABLED: 'true', USER_REBOOT_GRACE_SEC: '30',
            PROGRESSIVE_RESCUE: 'true', AUTO_REENABLE: 'false', DRY_RUN: 'true',
            WATCHDOG_ENGINE: 'shell'
        };
        this.setChecked('#cfg-enabled', true);
        this.setVal('#cfg-threshold', 3);
        this.setVal('#cfg-timeout', 90);
        this.setVal('#cfg-ota-timeout', 900);
        this.setVal('#cfg-grace', 30);
        this.setChecked('#cfg-log', true);
        this.setChecked('#cfg-progressive', true);
        this.setChecked('#cfg-auto-reenable', false);
        this.setChecked('#cfg-dry-run', true);
        this.setVal('#cfg-watchdog-poll', 2);
        this.renderWatchdogEngineChoice('shell');
        this.setChecked('#cfg-integrity-enabled', true);
    }

    async getDashboardSnapshot(options = {}) {
        const force = !!options.force;
        const now = Date.now();
        if (!force && this.dashboardSnapshot && (now - this.dashboardSnapshotFetchedAt) < 1500) {
            return this.dashboardSnapshot;
        }
        if (!force && this.dashboardSnapshotPromise) {
            return this.dashboardSnapshotPromise;
        }
        const script = `MODDIR="${this.basePath}"; . "${this.basePath}/common.sh" 2>/dev/null
get_dashboard_snapshot`;
        this.dashboardSnapshotPromise = (async () => {
            const raw = await this.exec(script, EXEC_DEFAULT_TIMEOUT_MS);
            const parsed = this.parseKV(raw || '');
            this.dashboardSnapshot = parsed;
            this.dashboardSnapshotFetchedAt = Date.now();
            return parsed;
        })();
        try {
            return await this.dashboardSnapshotPromise;
        } finally {
            this.dashboardSnapshotPromise = null;
        }
    }

    async loadStatus(options = {}) {
        try {
            const snap = options.snapshot || await this.getDashboardSnapshot({ force: !!options.force });
            const s = snap;
            const extra = snap;
            const stats = snap;

            const result = s.LAST_BOOT_RESULT || 'UNKNOWN';
            const badge = this.qs('#status-badge');
            const heroStatus = this.qs('#hero-status');
            const heroMeta = this.qs('#hero-meta');

            const statusMap = {
                'SUCCESS': { text: 'badge_ok', cls: 'badge-ok', hero: 'status_ok', meta: 'status_ok_meta' },
                'RESCUED': { text: 'badge_rescued', cls: 'badge-warn', hero: 'status_rescued', meta: 'status_rescued_meta' },
                'BOOTING': { text: 'badge_booting', cls: 'badge-info', hero: 'status_booting', meta: 'status_booting_meta' },
                'MODULE_DISABLED': { text: 'badge_disabled', cls: 'badge-err', hero: 'status_disabled', meta: 'status_disabled_meta' },
                'INIT': { text: 'badge_init', cls: 'badge-info', hero: 'status_init', meta: 'status_init_meta' },
                'UNKNOWN': { text: 'badge_unknown', cls: 'badge-info', hero: 'status_unknown', meta: 'status_unknown_meta' }
            };
            const m = statusMap[result] || statusMap['UNKNOWN'];
            badge.textContent = this.t(m.text);
            badge.className = `badge ${m.cls}`;
            heroStatus.textContent = this.t(m.hero);
            heroMeta.textContent = this.t(m.meta);

            this.setText('#info-last-result', result);
            const timezone = extra.OTA_TIMEZONE || 'UTC';
            this.systemTimezone = timezone;
            this.setText('#info-timezone', timezone);
            this.updateWebUiPreferenceTile(extra);
            const failCount = parseInt(s.FAIL_COUNT) || 0;
            this.setText('#info-fail-count', failCount);
            const otaDetected = s.OTA_DETECTED === 'true' || extra.OTA_DETECTION_ACTIVE === 'true';
            const otaSource = extra.OTA_DETECTION_SOURCE || 'none';
            const otaEl = this.qs('#info-ota');
            if (otaEl) {
                const yesNo = otaDetected ? (this.lang === 'zh' ? '是' : 'YES') : (this.lang === 'zh' ? '否' : 'NO');
                otaEl.textContent = otaDetected ? `${yesNo} (${this.formatOtaSource(otaSource)})` : yesNo;
                otaEl.className = 'value' + (otaDetected ? ' warn' : '');
            }
            this.renderOtaDetection(extra, otaDetected);

            // Patch flag is schema-based since v3.5.1; snapshot exposes a
            // normalized boolean rather than testing its on-disk text format.
            const patchEl = this.qs('#info-patch');
            if (patchEl) {
                const patchDetected = s.PATCH_DETECTED === 'true' || extra.PATCH_FLAG_ACTIVE === 'true';
                patchEl.textContent = patchDetected ? (this.lang === 'zh' ? '是' : 'YES') : (this.lang === 'zh' ? '否' : 'NO');
                patchEl.className = 'value' + (patchDetected ? ' warn' : '');
            }
            const patchFailEl = this.qs('#info-patch-fail');
            if (patchFailEl) {
                const pfcNum = parseInt(extra.PATCH_FAIL_COUNT) || 0;
                patchFailEl.textContent = pfcNum;
                patchFailEl.className = 'value' + (pfcNum > 0 ? ' warn' : '');
            }

            const start = parseInt(s.BOOT_START) || 0;
            const end = parseInt(s.BOOT_END) || 0;
            const uptimeStart = parseInt(s.UPTIME_START) || 0;
            const uptimeEnd = parseInt(s.UPTIME_END) || 0;
            const duration = parseInt(s.BOOT_DURATION) || 0;
            const sec = this.t('seconds');
            if (duration > 0 && duration <= 3600) {
                this.setText('#info-boot-duration', `${duration}${sec}`);
            } else if (uptimeStart > 0 && uptimeEnd > 0 && uptimeEnd >= uptimeStart) {
                const upDur = uptimeEnd - uptimeStart;
                if (upDur >= 5 && upDur <= 3600) this.setText('#info-boot-duration', `${upDur}${sec}`);
                else this.setText('#info-boot-duration', this.t('boot_error'));
            } else if (start > 0 && end > 0 && end > start && (end - start) <= 3600) {
                this.setText('#info-boot-duration', `${end - start}${sec}`);
            } else if (start > 0 && end > 0) {
                this.setText('#info-boot-duration', this.t('clock_unsync'));
            } else {
                this.setText('#info-boot-duration', '--');
            }

            const rescueCount = parseInt(stats.RESCUED) || parseInt(s.RESCUE_COUNT) || 0;
            this.setText('#info-rescue-count', rescueCount);

            // 看门狗状态（从合并命令结果中读取，无需额外 exec）
            const wdPid = extra.WD_PID || '';
            const wdStatus = extra.WD_STATUS || 'nopid';
            if (wdPid && /^\d+$/.test(wdPid.trim()) && wdStatus === 'alive_ours') {
                this.setText('#info-watchdog', `${this.t('wd_running')} (PID ${wdPid.trim()})`);
            } else {
                this.setText('#info-watchdog', this.t('wd_idle'));
            }

            // 失败进度
            const threshold = parseInt(this.config.REBOOT_THRESHOLD) || 3;
            const pct = Math.min(100, (failCount / threshold) * 100);
            const fill = this.qs('#progress-fill');
            fill.style.width = `${pct}%`;
            fill.classList.toggle('danger', failCount >= threshold - 1);
            this.setText('#progress-text', `${failCount} / ${threshold}`);

            const failEl = this.qs('#info-fail-count');
            failEl.className = 'value' + (failCount >= threshold ? ' danger' : (failCount > 0 ? ' warn' : ' ok'));

            this.lastStatus = {
                result,
                failCount,
                watchdogAlive: wdStatus === 'alive_ours',
                patchDetected: s.PATCH_DETECTED === 'true' || extra.PATCH_FLAG === '1'
            };
            this.renderIntegrity(snap);
            this.renderReadiness();
        } catch (e) {
            console.error('loadStatus failed:', e);
        }
    }

    renderIntegrity(snapshot) {
        const result = snapshot.INTEGRITY_RESULT || 'NOT_INITIALIZED';
        const badge = this.qs('#integrity-badge');
        const classes = { OK: 'badge-ok', COMPROMISED: 'badge-err', BASELINE_CREATED: 'badge-info', ERROR: 'badge-err', NOT_INITIALIZED: 'badge-info' };
        badge.textContent = result;
        badge.className = `badge ${classes[result] || 'badge-info'}`;
        this.setText('#integrity-daemon', snapshot.INTEGRITY_DAEMON === 'alive' ? this.t('wd_running') : this.t('wd_idle'));
        this.setText('#integrity-last-check', this.formatTimeValue(snapshot.INTEGRITY_CHECKED_AT));
        this.setText('#integrity-detail', snapshot.INTEGRITY_DETAIL || '--');
    }

    async runIntegrityCheck() {
        try {
            const out = await this.exec(`MODDIR="${this.basePath}"; . "${this.basePath}/common.sh" 2>/dev/null && integrity_check_once; echo RESULT=$?`);
            this.dashboardSnapshot = null;
            await this.loadStatus({ force: true });
            const passed = out.includes('RESULT=0');
            this.toast(this.t(passed ? 'integrity_passed' : 'integrity_failed'), passed ? 'success' : 'error');
        } catch (e) {
            this.toast(this.t('integrity_failed'), 'error');
        }
    }

    async loadWhitelist() {
        // 白名单从 config 加载，模块选择器加载时勾选
    }

    // === 模块选择器 ===
    async loadModules() {
        try {
            // 读取白名单
            const wlRaw = await this.exec(`cat "${this.whitelistFile}" 2>/dev/null`);
            const wlSet = new Set();
            wlRaw.split('\n').forEach(line => {
                const l = line.replace(/#.*$/, '').trim();
                if (l && MODULE_ID_RE.test(l)) wlSet.add(l);
            });

            // 扫描已装模块（用 shell 批量输出，减少 RPC）
            const script = `for base in ${this.moduleBases.join(' ')}; do
  [ -d "\$base" ] || continue
  case "\$base" in *ksu*) mgr="KSU";; *ap*) mgr="APatch";; *) mgr="Magisk";; esac
  for d in "\$base"/*/; do
    [ -d "\$d" ] || continue
    m=\$(basename "\$d")
    [ "\$m" = "${this.selfId}" ] && continue
    [ -f "\$d/remove" ] && continue
    en="1"; [ -f "\$d/disable" ] && en="0"
    echo "\${m}|\${en}|\${mgr}"
  done
done`;
            const out = await this.exec(script);
            const modules = [];
            out.split('\n').forEach(line => {
                const parts = line.split('|');
                if (parts.length === 3 && MODULE_ID_RE.test(parts[0])) {
                    modules.push({ id: parts[0], enabled: parts[1] === '1', manager: parts[2], whitelisted: wlSet.has(parts[0]) });
                }
            });
            this.modulesCache = modules;
            this.renderModuleList(modules, wlSet);
        } catch (e) {
            this.qs('#module-list').innerHTML = `<div class="empty-state">${this.t('loading')}</div>`;
        }
    }

    renderModuleList(modules, wlSet) {
        const container = this.qs('#module-list');
        if (!modules || modules.length === 0) {
            container.innerHTML = `<div class="empty-state">${this.t('mod_no_modules')}</div>`;
            return;
        }
        // 全选/取消全选按钮
        let html = `
            <div class="section-actions" style="margin:0 0 8px;padding:0 4px;">
                <button class="btn btn-text btn-sm" data-action="selectAllModules">${this.t('select_all')}</button>
                <button class="btn btn-text btn-sm" data-action="deselectAllModules">${this.t('deselect_all')}</button>
            </div>`;
        const t = this.t.bind(this);
        modules.forEach(m => {
            const checked = wlSet.has(m.id) ? 'checked' : '';
            const ena = m.enabled ? '1' : '0';
            const tag = m.enabled ? `<span class="module-tag enabled">${this.t('mod_enabled')}</span>` : `<span class="module-tag disabled">${this.t('mod_disabled')}</span>`;
            const mgrTag = `<span class="module-tag manager">${m.manager}</span>`;
            html += `
                <label class="module-item" data-module-id="${this.escapeHtml(m.id)}" data-module-enabled="${ena}" data-module-whitelisted="${wlSet.has(m.id) ? '1' : '0'}">
                    <input type="checkbox" class="module-checkbox" data-mod-id="${this.escapeHtml(m.id)}" ${checked}>
                    <div class="module-info">
                        <div class="name">${this.escapeHtml(m.id)}</div>
                        <div class="meta">${mgrTag} ${tag}</div>
                    </div>
                    <button class="btn btn-text btn-sm mod-toggle" data-mod-id="${this.escapeHtml(m.id)}" data-mod-enabled="${ena}">${ena === '1' ? t('toggle_disable') : t('toggle_enable')}</button>
                </label>`;
        });
        container.innerHTML = html;
        this.filterModules();
    }

    selectAllModules() {
        document.querySelectorAll('.module-checkbox').forEach(cb => cb.checked = true);
        this.filterModules();
    }

    deselectAllModules() {
        document.querySelectorAll('.module-checkbox').forEach(cb => cb.checked = false);
        this.filterModules();
    }

    filterModules() {
        const query = (this.qs('#module-search')?.value || '').trim().toLowerCase();
        const filter = this.qs('#module-filter')?.value || 'all';
        let selected = 0;
        document.querySelectorAll('#module-list .module-item').forEach(row => {
            const name = (row.dataset.moduleId || row.querySelector('.name')?.textContent || '').toLowerCase();
            const enabled = row.dataset.moduleEnabled === '1';
            const matchesQuery = !query || name.includes(query);
            const matchesFilter = filter === 'all' || (filter === 'enabled' && enabled) || (filter === 'disabled' && !enabled);
            row.hidden = !(matchesQuery && matchesFilter);
            if (row.querySelector('.module-checkbox')?.checked) selected += 1;
        });
        const count = this.qs('#module-selection-count');
        if (count) count.textContent = this.t('module_selected').replace('{n}', String(selected));
    }

    async refreshModules() {
        this.showLoading(true);
        await this.loadModules();
        this.showLoading(false);
        this.toast(this.t('refreshed'), 'success');
    }

    async saveWhitelist() {
        const checked = [];
        document.querySelectorAll('.module-checkbox:checked').forEach(cb => {
            const id = cb.dataset.modId;
            if (id && MODULE_ID_RE.test(id)) checked.push(id);
        });
        const content = '# RescueX 白名单 - 自动生成\n' + checked.join('\n') + '\n';
        try {
            const b64 = utf8ToBase64(content);
            if (!/^[A-Za-z0-9+/=]*$/.test(b64)) {
                this.toast(this.t('invalid_config'), 'error');
                return;
            }
            const result = await this.exec(`printf '%s' '${b64}' | base64 -d > "${this.whitelistFile}" && echo OK`);
            if (result.includes('OK')) {
                await this.loadModules();
                this.toast(this.t('saved'), 'success');
            } else {
                // v2.6.0 F-BUG-4 加固：错误路径也尝试 loadModules，
                //   避免保存失败后 DOM 与文件状态脱节（例如部分写入场景）
                try { await this.loadModules(); } catch (_) {}
                this.toast(this.t('save_failed'), 'error');
            }
        } catch (e) {
            // v2.6.0 F-BUG-4：异常路径同样尝试刷新
            try { await this.loadModules(); } catch (_) {}
            this.toast(this.t('save_failed'), 'error');
        }
    }

    // === 已禁用模块列表 ===
    async loadDisabledModules() {
        try {
            const script = `for base in ${this.moduleBases.join(' ')}; do
  [ -d "\$base" ] || continue
  for d in "\$base"/*/; do
    [ -d "\$d" ] || continue
    m=\$(basename "\$d")
    [ "\$m" = "${this.selfId}" ] && continue
    [ -f "\$d/disable" ] && echo "\$m"
  done
done`;
            const out = await this.exec(script);
            const container = this.qs('#disabled-list');
            const modules = out.split('\n').filter(m => m && MODULE_ID_RE.test(m));
            if (modules.length === 0) {
                container.innerHTML = `<div class="empty-state">${this.t('mod_no_disabled')}</div>`;
                return;
            }
            let html = '';
            modules.forEach(m => {
                html += `
                    <div class="module-item">
                        <div class="module-info">
                            <div class="name">${this.escapeHtml(m)}</div>
                        </div>
                        <span class="module-tag disabled">${this.t('mod_disabled')}</span>
                    </div>`;
            });
            container.innerHTML = html;
        } catch (e) {
            this.qs('#disabled-list').innerHTML = `<div class="empty-state">${this.t('loading')}</div>`;
        }
    }

    // === 快照管理 ===
    async loadSnapshots() {
        try {
            const out = await this.exec(`MODDIR="${this.basePath}"; . "${this.basePath}/common.sh" 2>/dev/null && list_snapshots`);
            const container = this.qs('#snapshot-list');
            const snaps = out.split('\n').filter(s => s);
            if (snaps.length === 0) {
                container.innerHTML = `<div class="empty-state">${this.t('no_snapshots')}</div>`;
                return;
            }
            let html = '';
            snaps.forEach(s => {
                const name = s.split('/').pop();
                html += `
                    <div class="module-item">
                        <div class="module-info">
                            <div class="name">${this.escapeHtml(name)}</div>
                        </div>
                        <button class="btn btn-tonal btn-sm" data-action="restoreSnapshot" data-snap="${this.escapeHtml(s)}">${this.lang === 'zh' ? '恢复' : 'Restore'}</button>
                        <button class="btn btn-text btn-sm" data-action="deleteSnapshot" data-snap="${this.escapeHtml(s)}" style="color:var(--md-error)">${this.lang === 'zh' ? '删除' : 'Delete'}</button>
                    </div>`;
            });
            container.innerHTML = html;
        } catch (e) {
            this.qs('#snapshot-list').innerHTML = `<div class="empty-state">${this.t('no_snapshots')}</div>`;
        }
    }

    async takeSnapshot() {
        try {
            const result = await this.exec(`MODDIR="${this.basePath}"; . "${this.basePath}/common.sh" 2>/dev/null && manual_take_snapshot manual`);
            if (result.trim()) {
                this.toast(this.t('snapshot_taken'), 'success');
                this.loadSnapshots();
            } else {
                this.toast(this.t('snapshot_failed'), 'error');
            }
        } catch (e) {
            this.toast(this.t('snapshot_failed'), 'error');
        }
    }

    async restoreSnapshot(e) {
        const snapFile = e.target.dataset.snap;
        if (!this.isSafeSnapshotPath(snapFile)) return;
        const confirm = await this.confirmDialog(
            this.t('confirm_title'),
            this.lang === 'zh' ? '将恢复到该快照记录的模块状态，重启后生效。是否继续？' : 'Restore module states from this snapshot. Effective after reboot. Continue?',
            this.t('btn_confirm'), 'btn-filled'
        );
        if (!confirm) return;
        try {
            const result = await this.exec(`MODDIR="${this.basePath}"; . "${this.basePath}/common.sh" 2>/dev/null && manual_restore_snapshot "${snapFile}"`);
            if (result.includes('OK')) {
                this.toast(this.t('snapshot_restored'), 'success');
                await Promise.all([this.loadDisabledModules(), this.loadSuspectModules()]);
            } else {
                this.toast(this.t('snapshot_failed'), 'error');
            }
        } catch (e) {
            this.toast(this.t('snapshot_failed'), 'error');
        }
    }

    async deleteSnapshot(e) {
        const snapFile = e.target.dataset.snap;
        if (!this.isSafeSnapshotPath(snapFile)) return;
        const confirm = await this.confirmDialog(
            this.t('confirm_title'),
            this.t('confirm_clear'),
            this.t('btn_confirm'), 'btn-danger'
        );
        if (!confirm) return;
        try {
            const result = await this.exec(`MODDIR="${this.basePath}"; . "${this.basePath}/common.sh" 2>/dev/null && manual_delete_snapshot "${snapFile}"; echo RESULT=$?`);
            if (!result.includes('RESULT=0')) {
                this.toast(this.t('snapshot_failed'), 'error');
                return;
            }
            this.toast(this.t('snapshot_deleted'), 'success');
            await this.loadSnapshots();
        } catch (e) {
            this.toast(this.t('snapshot_failed'), 'error');
        }
    }

    async restoreBaseline() {
        const confirm = await this.confirmDialog(
            this.t('confirm_title'),
            this.t('confirm_restore_baseline'),
            this.t('btn_confirm'), 'btn-filled'
        );
        if (!confirm) return;
        try {
            const result = await this.exec(`MODDIR="${this.basePath}"; . "${this.basePath}/common.sh" 2>/dev/null && manual_restore_good_modules_baseline`);
            if (result.includes('CHANGED=')) {
                this.toast(this.t('baseline_restored'), 'success');
                await Promise.all([this.loadDisabledModules(), this.loadSuspectModules(), this.loadRescueLevel()]);
            } else {
                this.toast(this.t('snapshot_failed'), 'error');
            }
        } catch (e) {
            this.toast(this.t('snapshot_failed'), 'error');
        }
    }
    renderWatchdogEngineChoice(engine) {
        const native = engine === 'native';
        this.setText('#cfg-watchdog-engine-choice', this.t(native ? 'watchdog_engine_native' : 'watchdog_engine_shell'));
        this.setChecked('#cfg-watchdog-engine', native);
    }

    renderWatchdogEngineStatus(status = {}) {
        const configured = status.CONFIGURED === 'native' ? 'native' : 'shell';
        const effective = status.EFFECTIVE === 'native' ? 'native' : 'shell';
        const reason = status.REASON || 'shell_selected';
        this.renderWatchdogEngineChoice(configured);
        const configuredLabel = this.t(configured === 'native' ? 'watchdog_engine_native' : 'watchdog_engine_shell');
        const effectiveLabel = this.t(effective === 'native' ? 'watchdog_engine_native' : 'watchdog_engine_shell');
        const reasonKey = `watchdog_engine_reason_${reason}`;
        const reasonText = this.t(reasonKey) === reasonKey ? reason : this.t(reasonKey);
        const prefix = this.t('watchdog_engine_status');
        const text = configured === effective
            ? `${prefix}: ${effectiveLabel} · ${reasonText}`
            : `${prefix}: ${effectiveLabel}（${configuredLabel}，${reasonText}）`;
        this.setText('#cfg-watchdog-engine-status', text);
        const statusEl = this.qs('#cfg-watchdog-engine-status');
        if (statusEl) statusEl.className = `hint watchdog-engine-status ${effective === 'native' ? 'is-native' : (configured === 'native' ? 'is-fallback' : '')}`;
    }

    async loadWatchdogEngineStatus(configured = 'shell') {
        try {
            const script = `MODDIR="${this.basePath}"; . "${this.basePath}/common.sh" 2>/dev/null || exit 1; read_config; get_watchdog_engine_status`;
            const result = await this.execStrict(script, 5000);
            if (!result.ok) {
                this.renderWatchdogEngineStatus({ CONFIGURED: configured, EFFECTIVE: 'shell', REASON: 'shell_selected' });
                return;
            }
            this.renderWatchdogEngineStatus(this.parseKV(result.stdout));
        } catch (_) {
            this.renderWatchdogEngineStatus({ CONFIGURED: configured, EFFECTIVE: 'shell', REASON: 'shell_selected' });
        }
    }

    // === 配置操作 ===
    toggleEnabled(e) {
        this.config.ENABLED = e.target.checked ? 'true' : 'false';
    }

    async saveConfig() {
        const threshold = parseInt(this.qs('#cfg-threshold').value) || 3;
        const timeout = parseInt(this.qs('#cfg-timeout').value) || 90;
        const otaTimeout = parseInt(this.qs('#cfg-ota-timeout').value) || 900;
        const grace = parseInt(this.qs('#cfg-grace').value) || 30;
        const enabled = this.qs('#cfg-enabled').checked ? 'true' : 'false';
        const log = this.qs('#cfg-log').checked ? 'true' : 'false';
        const progressive = this.qs('#cfg-progressive').checked ? 'true' : 'false';
        const autoReenable = this.qs('#cfg-auto-reenable').checked ? 'true' : 'false';
        const dryRun = this.qs('#cfg-dry-run').checked ? 'true' : 'false';
        // v2.4: 补丁更新配置
        const patchTimeout = parseInt(this.qs('#cfg-patch-timeout') ? this.qs('#cfg-patch-timeout').value : 180) || 180;
        const patchFailThreshold = parseInt(this.qs('#cfg-patch-fail-threshold') ? this.qs('#cfg-patch-fail-threshold').value : 2) || 2;
        const patchAutoRollback = this.qs('#cfg-patch-auto-rollback') ? this.qs('#cfg-patch-auto-rollback').checked : true;
        // v2.5: 看门狗轮询间隔
        const watchdogPollRaw = this.qs('#cfg-watchdog-poll') ? this.qs('#cfg-watchdog-poll').value : '2';
        const watchdogPoll = parseInt(watchdogPollRaw) || 2;
        const integrityEnabled = this.qs('#cfg-integrity-enabled').checked;
        const watchdogEngine = this.qs('#cfg-watchdog-engine')?.checked ? 'native' : 'shell';

        const t = Math.max(1, Math.min(10, threshold));
        const to = Math.max(30, Math.min(600, timeout));
        const ota = Math.max(60, Math.min(1800, otaTimeout));
        const gr = Math.max(5, Math.min(300, grace));
        const pt = Math.max(60, Math.min(600, patchTimeout));
        const pft = Math.max(1, Math.min(5, patchFailThreshold));
        const wp = Math.max(1, Math.min(10, watchdogPoll));

        const lines = [
            `REBOOT_THRESHOLD=${t}`,
            `BOOT_TIMEOUT_SEC=${to}`,
            `OTA_TIMEOUT_SEC=${ota}`,
            `ENABLED=${enabled}`,
            `LOG_ENABLED=${log}`,
            `DRY_RUN=${dryRun}`,
            `PROGRESSIVE_RESCUE=${progressive}`,
            `AUTO_REENABLE=${autoReenable}`,
            `USER_REBOOT_GRACE_SEC=${gr}`,
            `PATCH_UPDATE_TIMEOUT_SEC=${pt}`,
            `PATCH_FAIL_THRESHOLD=${pft}`,
            `PATCH_AUTO_ROLLBACK=${patchAutoRollback ? 'true' : 'false'}`,
            `WATCHDOG_POLL_INTERVAL_SEC=${wp}`,
            `WATCHDOG_ENGINE=${watchdogEngine}`,
            `INTEGRITY_CHECK_ENABLED=${integrityEnabled ? 'true' : 'false'}`,
            ''
        ];
        try {
            // LOG-006: Atomic write (tmp + sync + mv) to prevent config corruption on power loss
            const cmd = `umask 077; mkdir -p "${this.stateDir}" "/data/adb/rescuex_data" && {
cat > "${this.stateDir}/config.conf.tmp.$$" << 'RXCONF'
${lines.join('\n')}
RXCONF
sync "${this.stateDir}/config.conf.tmp.$$" 2>/dev/null
mv -f "${this.stateDir}/config.conf.tmp.$$" "${this.stateDir}/config.conf"
} && cp -f "${this.stateDir}/config.conf" "/data/adb/rescuex_data/config.conf.tmp.$$" && sync "/data/adb/rescuex_data/config.conf.tmp.$$" 2>/dev/null && mv -f "/data/adb/rescuex_data/config.conf.tmp.$$" "/data/adb/rescuex_data/config.conf" && chmod 0600 "${this.stateDir}/config.conf" "/data/adb/rescuex_data/config.conf" && echo OK`;
            const result = await this.execStrict(cmd);
            if (result.ok && result.stdout.includes('OK')) {
                this.config = {
                    ENABLED: enabled, REBOOT_THRESHOLD: String(t),
                    BOOT_TIMEOUT_SEC: String(to), OTA_TIMEOUT_SEC: String(ota),
                    LOG_ENABLED: log, DRY_RUN: dryRun,
                    PROGRESSIVE_RESCUE: progressive, AUTO_REENABLE: autoReenable,
                    USER_REBOOT_GRACE_SEC: String(gr),
                    PATCH_UPDATE_TIMEOUT_SEC: String(pt),
                    PATCH_FAIL_THRESHOLD: String(pft),
                    PATCH_AUTO_ROLLBACK: patchAutoRollback ? 'true' : 'false',
                    WATCHDOG_POLL_INTERVAL_SEC: String(wp),
                    WATCHDOG_ENGINE: watchdogEngine,
                    INTEGRITY_CHECK_ENABLED: integrityEnabled ? 'true' : 'false'
                };
                this.toast(this.t('saved'), 'success');
            } else {
                this.toast(this.t('save_failed'), 'error');
            }
        } catch (e) {
            this.toast(this.t('save_failed') + ': ' + (e.message || ''), 'error');
        }
    }

    // === 配置导入/导出 ===
    async exportConfig() {
        // v2.4: WebUI 容器不支持 Blob 下载，改用 shell 写入 /sdcard/Download + am start 分享
        try {
            const configRaw = await this.exec(`cat "${this.confFile}" 2>/dev/null`);
            const whitelistRaw = await this.exec(`cat "${this.whitelistFile}" 2>/dev/null`);
            const data = {
                version: APP_VERSION,
                versionCode: APP_VERSION_CODE,
                exported_at: new Date().toISOString(),
                config: this.parseKV(configRaw),
                whitelist: whitelistRaw
            };
            const json = JSON.stringify(data, null, 2);
            const ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
            const filepath = `/sdcard/Download/rescuex-config-${ts}.json`;
            const b64 = utf8ToBase64(json);
            if (!/^[A-Za-z0-9+/=]*$/.test(b64)) {
                this.toast(this.t('export_failed'), 'error');
                return;
            }
            const r = await this.execStrict(`mkdir -p /sdcard/Download && printf '%s' '${b64}' | base64 -d > '${filepath}' && echo OK`);
            if (r.ok && r.stdout.includes('OK')) {
                await this.exec(`am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file://'${filepath}' 2>/dev/null`);
                this.toast((this.lang === 'zh' ? '配置已保存到 ' : 'Config saved to ') + filepath, 'success', 5000);
            } else {
                this.toast(this.t('export_failed'), 'error');
            }
        } catch (e) {
            this.toast(this.t('export_failed'), 'error');
        }
    }

    async importConfig() {
        // v3.5.9: Atomic import. Write to temp files, validate, then rename.
        // If either file fails, neither is committed.
        const filepath = '/sdcard/Download/rescuex-config.json';
        const confirm = await this.confirmDialog(
            this.t('import_config'),
            this.lang === 'zh'
                ? `将从 ${filepath} 读取配置并覆盖当前配置。请先用"导出配置"生成该文件，或手动放置配置文件到该路径。是否继续？`
                : `Will read config from ${filepath} and overwrite current. Use "Export" first to generate the file, or manually place it there. Continue?`,
            this.t('btn_confirm'), 'btn-filled'
        );
        if (!confirm) return;

        try {
            const readR = await this.execStrict(`cat '${filepath}' 2>/dev/null`);
            if (!readR.ok || !readR.stdout) {
                this.toast(this.lang === 'zh' ? `未找到或读取失败: ${filepath}` : `Not found or read failed: ${filepath}`, 'error');
                return;
            }
            const text = readR.stdout;
            let data;
            try { data = JSON.parse(text); }
            catch (e) { this.toast(this.t('config_import_failed'), 'error'); return; }
            if (!data.config || typeof data.config !== 'object') {
                this.toast(this.t('config_import_failed'), 'error');
                return;
            }
            const cfg = data.config;
            const clamped = this._validateAndClampConfig(cfg);
            const lines = [];
            Object.keys(clamped).forEach(k => { lines.push(`${k}=${clamped[k]}`); });
            lines.push('');
            const configContent = lines.join('\n');
            const configB64 = utf8ToBase64(configContent);
            if (!/^[A-Za-z0-9+/=]*$/.test(configB64)) { this.toast(this.t('config_import_failed'), 'error'); return; }

            // Prepare whitelist content
            let wlB64 = null;
            if (data.whitelist) {
                const safeWl = String(data.whitelist)
                    .split('\n')
                    .map(l => {
                        const hashIdx = l.indexOf('#');
                        const comment = hashIdx >= 0 ? l.substring(hashIdx) : '';
                        const content = hashIdx >= 0 ? l.substring(0, hashIdx) : l;
                        const cleaned = content.replace(/[^A-Za-z0-9._-]/g, '').trim();
                        return cleaned || comment;
                    })
                    .filter(l => l)
                    .join('\n');
                wlB64 = utf8ToBase64(safeWl + '\n');
                if (!/^[A-Za-z0-9+/=]*$/.test(wlB64)) { this.toast(this.t('config_import_failed'), 'error'); return; }
            }

            // v3.5.9: Write both to temp, then rename atomically.
            const tmpConf = `${this.confFile}.import.$$`;
            const tmpWl = `${this.whitelistFile}.import.$$`;
            const writeConf = `printf '%s' '${configB64}' | base64 -d > '${tmpConf}' && echo OK`;
            const r1 = await this.execStrict(writeConf);
            if (!r1.ok || !r1.stdout.includes('OK')) {
                this.toast(this.t('save_failed'), 'error');
                await this.execStrict(`rm -f '${tmpConf}' '${tmpWl}' 2>/dev/null`);
                return;
            }
            if (wlB64) {
                const r2 = await this.execStrict(`printf '%s' '${wlB64}' | base64 -d > '${tmpWl}' && echo OK`);
                if (!r2.ok || !r2.stdout.includes('OK')) {
                    this.toast(this.t('save_failed'), 'error');
                    await this.execStrict(`rm -f '${tmpConf}' '${tmpWl}' 2>/dev/null`);
                    return;
                }
            }
            // Commit: rename temp to final. mv is atomic on same filesystem.
            const commitConf = await this.execStrict(`mv -f '${tmpConf}' '${this.confFile}' && echo OK`);
            const commitWl = wlB64 ? await this.execStrict(`mv -f '${tmpWl}' '${this.whitelistFile}' && echo OK`) : { ok: true, stdout: 'OK' };
            const mirrorConf = await this.execStrict(`mkdir -p '/data/adb/rescuex_data' && cp -f '${this.confFile}' '/data/adb/rescuex_data/config.conf.import.$$' && sync '/data/adb/rescuex_data/config.conf.import.$$' 2>/dev/null && mv -f '/data/adb/rescuex_data/config.conf.import.$$' '/data/adb/rescuex_data/config.conf' && chmod 0600 '/data/adb/rescuex_data/config.conf' && echo OK`);
            if (commitConf.ok && commitConf.stdout.includes('OK') && commitWl.ok && commitWl.stdout.includes('OK') && mirrorConf.ok && mirrorConf.stdout.includes('OK')) {
                this.toast(this.t('config_imported'), 'success');
                await this.loadConfig();
                await this.loadModules();
            } else {
                this.toast(this.t('save_failed'), 'error');
                await this.execStrict(`rm -f '${tmpConf}' '${tmpWl}' 2>/dev/null`);
            }
        } catch (e) {
            this.toast(this.t('config_import_failed'), 'error');
        }
    }

    // v2.5: 配置字段级校验与 clamp（修复 Issue 4）
    // 与 common.sh 的 read_config 范围保持一致
    _validateAndClampConfig(cfg) {
        const out = {};
        // 数值字段定义：[key, min, max, default]
        const numFields = [
            ['REBOOT_THRESHOLD', 1, 10, 3],
            ['BOOT_TIMEOUT_SEC', 30, 600, 90],
            ['OTA_TIMEOUT_SEC', 60, 1800, 900],
            ['USER_REBOOT_GRACE_SEC', 5, 300, 30],
            ['PATCH_UPDATE_TIMEOUT_SEC', 60, 600, 180],
            ['PATCH_FAIL_THRESHOLD', 1, 5, 2],
            ['WATCHDOG_POLL_INTERVAL_SEC', 1, 10, 2]
        ];
        numFields.forEach(([k, min, max, def]) => {
            let v = cfg[k];
            if (v === undefined || v === null) {
                out[k] = String(def);
                return;
            }
            // LOG-005: Reject negative values instead of silently stripping the minus sign
            let vStr = String(v).trim();
            if (vStr.startsWith('-')) {
                out[k] = String(def);
                return;
            }
            let n = parseInt(vStr.replace(/[^0-9]/g, ''));
            if (isNaN(n)) n = def;
            if (n < min) n = min;
            if (n > max) n = max;
            out[k] = String(n);
        });
        const boolDefaults = {
            ENABLED: 'true',
            LOG_ENABLED: 'true',
            DRY_RUN: 'false',
            PROGRESSIVE_RESCUE: 'true',
            AUTO_REENABLE: 'false',
            PATCH_AUTO_ROLLBACK: 'true'
        };
        Object.keys(boolDefaults).forEach(k => {
            if (cfg[k] === undefined || cfg[k] === null) {
                out[k] = boolDefaults[k];
                return;
            }
            let v = String(cfg[k]).toLowerCase().trim();
            out[k] = v === 'true' ? 'true' : 'false';
        });
        return out;
    }

    // === 手动操作 ===
    _buildModuleScript(action) {
        const basesStr = this.moduleBases.join(' ');
        const commonPath = `${this.basePath}/common.sh`;
        if (action === 'disable') {
            return `WL_CONTENT="
\$(cat "${this.whitelistFile}" 2>/dev/null)
"
. "${commonPath}" 2>/dev/null || exit 1
_rescuex_init_paths 2>/dev/null || true
for base in ${basesStr}; do
  [ -d "\$base" ] || continue
  for d in "\$base"/*/; do
    [ -d "\$d" ] || continue
    m=\$(basename "\$d")
    [ "\$m" = "${this.selfId}" ] && continue
    case "\$m" in *[!A-Za-z0-9._-]*) continue ;; esac
    case "\$WL_CONTENT" in *"
\$m
"*) continue ;; esac
    [ -f "\$d/disable" ] && continue
    disable_module_at_dir "\$d" "\$m" >/dev/null 2>&1 && [ -f "\$d/disable" ] && echo "disabled:\$m"
  done
done`;
        } else {
            return `for base in ${basesStr}; do
  [ -d "\$base" ] || continue
  for d in "\$base"/*/; do
    [ -d "\$d" ] || continue
    m=\$(basename "\$d")
    [ "\$m" = "${this.selfId}" ] && continue
    case "\$m" in *[!A-Za-z0-9._-]*) continue ;; esac
    [ -f "\$d/disable" ] || continue
    rm -f "\$d/disable" 2>/dev/null && echo "enabled:\$m"
  done
done`;
        }
    }

    async disableAllModules() {
        const confirm = await this.confirmDialog(
            this.t('confirm_title'),
            this.t('confirm_disable_all'),
            this.t('btn_confirm'), 'btn-danger'
        );
        if (!confirm) return;
        this.toast(this.lang === 'zh' ? '正在禁用...' : 'Disabling...', '');
        this.showLoading(true);
        try {
            const out = await this.exec(this._buildModuleScript('disable'));
            const count = (out.match(/^disabled:/gm) || []).length;
            this.toast(this.t('disabled_count').replace('N', count), 'success');
            this.loadStatus();
            this.loadDisabledModules();
        } catch (e) {
            this.toast(this.t('save_failed'), 'error');
        }
        this.showLoading(false);
    }

    async refreshRescueTransaction() {
        const out = await this.exec(`MODDIR="${this.modulePath}"; . "$MODDIR/common.sh"; rescue_transaction_status`);
        const state = (out.match(/^STATE=(.*)$/m) || [])[1] || 'NONE';
        const id = (out.match(/^TXN_ID=(.*)$/m) || [])[1] || '-';
        const targets = (out.match(/^TARGETS=(.*)$/m) || [])[1] || '0';
        this.toast(this.lang === 'zh' ? `救砖事务：${state}，目标 ${targets} 个（${id}）` : `Rescue transaction: ${state}, ${targets} targets (${id})`, state === 'PARTIAL' ? 'error' : '');
        return out;
    }

    async restoreRescueTransaction() {
        const status = await this.refreshRescueTransaction();
        if (!/^STATE=(APPLIED|PARTIAL)$/m.test(status)) {
            this.toast(this.lang === 'zh' ? '没有可恢复的 RescueX 救砖事务。' : 'No recoverable RescueX transaction.', 'error');
            return;
        }
        const confirm = await this.confirmDialog(
            this.t('confirm_title'),
            this.lang === 'zh' ? '仅恢复 RescueX 在当前事务中实际写入的 disable 标记；不会启用你或其他工具手动禁用的模块。是否继续？' : 'Only disable markers written by RescueX in the current transaction will be removed. Manually disabled modules stay disabled. Continue?',
            this.t('btn_confirm'), 'btn-filled'
        );
        if (!confirm) return;
        this.showLoading(true);
        try {
            const out = await this.execStrict(`MODDIR="${this.modulePath}"; . "$MODDIR/common.sh"; RESCUEX_READ_ONLY=false; rescue_transaction_restore_current`);
            const restored = (out.match(/^RESTORED=(\d+)$/m) || [])[1] || '0';
            this.toast(this.lang === 'zh' ? `已安全恢复 ${restored} 个模块。` : `Safely restored ${restored} module(s).`, 'success');
            this.loadStatus(); this.loadDisabledModules();
        } catch (e) { this.toast(this.t('save_failed'), 'error'); }
        this.showLoading(false);
    }

    async reenableAllModules() {
        // Legacy UI entry now delegates to transaction-bound recovery; it never
        // scans all disable markers across Root managers.
        return this.restoreRescueTransaction();
    }

    async legacyReenableAllModulesRemoved() {
        const confirm = await this.confirmDialog(
            this.t('confirm_title'),
            this.t('confirm_enable_all'),
            this.t('btn_confirm'), 'btn-filled'
        );
        if (!confirm) return;
        this.toast(this.lang === 'zh' ? '正在恢复...' : 'Enabling...', '');
        this.showLoading(true);
        try {
            const out = await this.exec(this._buildModuleScript('enable'));
            const count = (out.match(/^enabled:/gm) || []).length;
            this.toast(this.t('enabled_count').replace('N', count), 'success');
            this.loadStatus();
            this.loadDisabledModules();
        } catch (e) {
            this.toast(this.t('save_failed'), 'error');
        }
        this.showLoading(false);
    }

    // v2.4: Manually set/clear the patch update flag.
    async togglePatchFlag() {
        let active = false;
        try {
            const current = await this.execStrict(`. "${this.basePath}/common.sh" 2>/dev/null && if patch_flag_active; then printf '1'; else printf '0'; fi`);
            if (!current.ok) throw new Error('patch flag status failed');
            active = current.stdout.trim() === '1';
        } catch (_) {
            this.toast(this.t('save_failed'), 'error');
            return;
        }

        const confirm = await this.confirmDialog(
            this.lang === 'zh' ? (active ? '清除补丁标记' : '设置补丁标记') : (active ? 'Clear Patch Flag' : 'Set Patch Flag'),
            active
                ? (this.lang === 'zh' ? '将清除补丁更新标记和补丁失败计数。是否继续？' : 'Will clear the patch marker and patch failure count. Continue?')
                : (this.lang === 'zh' ? '下次启动将使用补丁专属超时。是否继续？' : 'The next boot will use the patch-specific timeout. Continue?'),
            this.t('btn_confirm'), 'btn-filled'
        );
        if (!confirm) return;

        try {
            const command = active ? 'manual_clear_patch_flag' : 'set_patch_flag';
            const result = await this.execStrict(`. "${this.basePath}/common.sh" 2>/dev/null && ${command} && echo OK`);
            if (!result.ok || !result.stdout.includes('OK')) throw new Error('patch flag write failed');
            this.toast(this.lang === 'zh' ? (active ? '补丁标记已清除' : '补丁标记已设置，重启后生效') : (active ? 'Patch flag cleared' : 'Patch flag set, effective after reboot'), 'success');
            this.dashboardSnapshot = null;
            await this.loadStatus({ force: true });
        } catch (_) {
            this.toast(this.t('save_failed'), 'error');
        }
    }

    async testWatchdog() {
        const confirm = await this.confirmDialog(
            this.t('confirm_title'),
            this.t('confirm_test_wd'),
            this.t('btn_confirm'), 'btn-danger'
        );
        if (!confirm) return;
        try {
            const script = `( sh "${this.basePath}/watchdog.sh" 10 >/dev/null 2>&1 < /dev/null & ) ; echo "started"`;
            await this.exec(script);
            this.toast(this.lang === 'zh' ? '测试看门狗已启动，10 秒后将触发' : 'Test watchdog started, triggers in 10s', 'warn');
        } catch (e) {
            this.toast(this.t('save_failed'), 'error');
        }
    }

    async rebootDevice() {
        const confirm = await this.confirmDialog(
            this.t('confirm_title'),
            this.t('confirm_reboot'),
            this.t('btn_confirm'), 'btn-danger'
        );
        if (!confirm) return;
        try {
            await this.exec('sync ; sleep 1 ; setprop sys.powerctl reboot');
            this.toast(this.lang === 'zh' ? '正在重启...' : 'Rebooting...', 'success');
        } catch (e) {
            this.toast(this.t('save_failed'), 'error');
        }
    }

    // === 诊断报告 ===
    async generateReport() {
        const confirm = await this.confirmDialog(
            this.t('confirm_title'),
            this.t('report_privacy_confirm'),
            this.t('btn_confirm'), 'btn-filled'
        );
        if (!confirm) return;
        this.showLoading(true);
        // v2.7: 60s 超时下补充 "生成中..." 提示，避免用户误以为卡死
        this.toast(this.lang === 'zh' ? '生成中...' : 'Generating...', '', 60000);
        try {
            const script = `MODDIR="${this.basePath}"; . "${this.basePath}/common.sh" 2>/dev/null
generate_report`;
            const report = await this.exec(script, EXEC_REPORT_TIMEOUT_MS);
            if (!report) {
                // v2.6.0 F-BUG-8: 区分超时与空输出，给出更明确提示
                console.warn('[RescueX] generateReport: empty output (likely timeout or common.sh not found)');
                this.toast(this.lang === 'zh'
                    ? '报告生成失败：执行超时或 common.sh 不可达，请检查模块路径'
                    : 'Report failed: timeout or common.sh unreachable, check module path', 'error', 6000);
                return;
            }
            this.showTextModal(this.t('report_title'), report);
        } catch (e) {
            // v2.6.0 F-BUG-8: catch 块输出详细错误到 console 便于排障
            console.warn('[RescueX] generateReport error:', e);
            this.toast(this.lang === 'zh'
                ? '报告生成异常：' + (e && e.message ? e.message : '未知错误')
                : 'Report error: ' + (e && e.message ? e.message : 'unknown'), 'error', 6000);
        }
        this.showLoading(false);
    }

    async generateDecisionReport() {
        this.showLoading(true);
        this.toast(this.lang === 'zh' ? '生成中...' : 'Generating...', '', 60000);
        try {
            const report = await this.exec(`MODDIR="${this.basePath}"; . "${this.basePath}/common.sh" 2>/dev/null
manual_generate_rescue_decision_report`, EXEC_REPORT_TIMEOUT_MS);
            if (!report) {
                this.toast(this.t('snapshot_failed'), 'error', 6000);
                return;
            }
            this.showTextModal(this.t('decision_report_title'), report);
        } catch (e) {
            this.toast(this.t('snapshot_failed'), 'error', 6000);
        }
        this.showLoading(false);
    }

    showTextModal(title, report) {
        const overlay = document.createElement('div');
        overlay.className = 'modal-overlay';
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.maxWidth = '560px';

        const h3 = document.createElement('h3');
        h3.textContent = title;

        const pre = document.createElement('pre');
        pre.className = 'log-view';
        pre.style.maxHeight = '400px';
        pre.textContent = report;

        const btns = document.createElement('div');
        btns.className = 'modal-buttons';

        const cancel = document.createElement('button');
        cancel.className = 'btn btn-text';
        cancel.textContent = this.t('btn_cancel');

        const copyBtn = document.createElement('button');
        copyBtn.className = 'btn btn-filled';
        copyBtn.textContent = this.t('copy');

        const downloadBtn = document.createElement('button');
        downloadBtn.className = 'btn btn-tonal';
        downloadBtn.textContent = this.t('export');

        btns.appendChild(cancel);
        btns.appendChild(copyBtn);
        btns.appendChild(downloadBtn);
        modal.appendChild(h3);
        modal.appendChild(pre);
        modal.appendChild(btns);
        overlay.appendChild(modal);
        document.body.appendChild(overlay);

        const close = () => overlay.remove();
        cancel.onclick = close;
        overlay.onclick = (e) => { if (e.target === overlay) close(); };
        copyBtn.onclick = async () => {
            try {
                await navigator.clipboard.writeText(report);
                this.toast(this.t('copied'), 'success');
            } catch (e) {
                // fallback
                const ta = document.createElement('textarea');
                ta.value = report;
                document.body.appendChild(ta);
                ta.select();
                document.execCommand('copy');
                document.body.removeChild(ta);
                this.toast(this.t('copied'), 'success');
            }
        };
        downloadBtn.onclick = async () => {
            // v2.4: WebUI 容器不支持 Blob 下载，改用 shell 写入 /sdcard/Download + am start 分享
            const ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
            const filename = `rescuex-report-${ts}.txt`;
            const filepath = `/sdcard/Download/${filename}`;
            try {
                // 用 base64 编码避免特殊字符问题
                const b64 = utf8ToBase64(report);
                if (!/^[A-Za-z0-9+/=]*$/.test(b64)) {
                    this.toast(this.t('export_failed'), 'error');
                    return;
                }
                // 写入 /sdcard/Download
                const result = await this.exec(`mkdir -p /sdcard/Download && printf '%s' '${b64}' | base64 -d > '${filepath}' && echo OK`);
                if (result.includes('OK')) {
                    // 触发媒体扫描 + 用分享面板
                    await this.exec(`am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file://'${filepath}' 2>/dev/null; am start -a android.intent.action.SEND -t text/plain --android.intent.extra.STREAM file://'${filepath}' 2>/dev/null`);
                    this.toast((this.lang === 'zh' ? '已保存到 ' : 'Saved to ') + filepath, 'success', 5000);
                } else {
                    this.toast(this.t('export_failed'), 'error');
                }
            } catch (e) {
                this.toast(this.t('export_failed'), 'error');
            }
        };
    }

    // === 日志 ===
    async loadHistory() {
        try {
            const raw = await this.exec(`tail -n 50 "${this.historyFile}" 2>/dev/null`);
            this.qs('#boot-history').textContent = raw || (this.lang === 'zh' ? '暂无启动记录' : 'No history');
        } catch (e) {
            this.qs('#boot-history').textContent = this.lang === 'zh' ? '读取失败' : 'Read failed';
        }
    }

    async loadLog() {
        try {
            const raw = await this.exec(`tail -n 80 "${this.logFile}" 2>/dev/null`);
            const el = this.qs('#rescue-log');
            el.textContent = raw || (this.lang === 'zh' ? '暂无日志' : 'No logs');
            this.highlightLog(el);
        } catch (e) {
            this.qs('#rescue-log').textContent = this.lang === 'zh' ? '读取失败' : 'Read failed';
        }
    }

    highlightLog(el) {
        const text = el.textContent;
        if (!text) return;
        const lines = text.split('\n');
        const html = lines.map(line => {
            let cls = '';
            if (/警告|失败|错误|CRITICAL|ERROR|FAIL/i.test(line)) cls = 'log-line-error';
            else if (/超时|timeout|WARNING|WARN/i.test(line)) cls = 'log-line-warn';
            else if (/成功|完成|SUCCESS|OK/i.test(line)) cls = 'log-line-ok';
            else if (/启动|初始化|INFO|START/i.test(line)) cls = 'log-line-info';
            return cls ? `<span class="${cls}">${this.escapeHtml(line)}</span>` : this.escapeHtml(line);
        }).join('\n');
        el.innerHTML = html;
    }

    async detectManager() {
        const out = await this.exec(`[ -d /data/adb/ksu ] && if pm list packages 2>/dev/null | grep -qi sukisu; then if pm list packages 2>/dev/null | grep -q "com.dergoogler.mmrl\|com.dergoogler.mmrl.wx"; then echo "SukiSU Ultra (MMRL)"; else echo "SukiSU Ultra"; fi; else if pm list packages 2>/dev/null | grep -q "com.dergoogler.mmrl\|com.dergoogler.mmrl.wx"; then echo "KSU (MMRL)"; else echo KSU; fi; fi ; [ -d /data/adb/ap ] && echo APatch ; [ -d /data/adb/magisk ] && echo Magisk`);
        const managers = out.split('\n').filter(Boolean);
        this.setText('#info-manager', managers.join(' / ') || (this.lang === 'zh' ? '未知' : 'Unknown'));
    }

    switchTab(tab) {
        this.currentTab = tab;
        document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === tab));
        this.qs('#rescue-log').classList.toggle('hidden', tab !== 'log');
        this.qs('#boot-history').classList.toggle('hidden', tab !== 'history');
    }

    startAutoRefresh() {
        if (this.refreshTimer) clearInterval(this.refreshTimer);
        this.refreshTimer = setInterval(async () => {
            if (!this.isLoading) {
                let dashboardSnapshot = null;
                try {
                    dashboardSnapshot = await this.getDashboardSnapshot({ force: true });
                } catch (_) {}
                this.loadStatus(dashboardSnapshot ? { snapshot: dashboardSnapshot } : {});
                // 日志 Tab 也自动刷新（频率较低）
                if (this.currentTab === 'log') this.loadLog();
                // v2.5: 统计面板每 ~30 秒刷新一次（每 6 个周期）
                this._statsCounter = (this._statsCounter || 0) + 1;
                if (this._statsCounter >= 6) {
                    this.loadStats(dashboardSnapshot ? { silent: true, snapshot: dashboardSnapshot } : { silent: true });
                    this.loadAuditLog();
                    this.loadBootTrend();
                    this.loadSuspectModules();
                    this.loadRescueLevel();
                    this._statsCounter = 0;
                }
            }
        }, 5000);
    }

    async refreshLog() {
        this.showLoading(true);
        if (this.currentTab === 'log') await this.loadLog();
        else await this.loadHistory();
        this.showLoading(false);
        this.toast(this.t('refreshed'), 'success');
    }

    async copyLog() {
        const targetEl = this.currentTab === 'log' ? '#rescue-log' : '#boot-history';
        const text = this.qs(targetEl).textContent || '';
        if (!text || text === this.t('loading')) {
            this.toast(this.t('no_content'), 'warn');
            return;
        }
        try {
            if (navigator.clipboard && navigator.clipboard.writeText) {
                await navigator.clipboard.writeText(text);
                this.toast(this.t('copied'), 'success');
                return;
            }
        } catch (e) { /* fallback */ }
        try {
            const ta = document.createElement('textarea');
            ta.value = text;
            ta.style.cssText = 'position:fixed;top:-9999px;left:-9999px;opacity:0;';
            document.body.appendChild(ta);
            ta.select();
            const ok = document.execCommand('copy');
            document.body.removeChild(ta);
            if (ok) this.toast(this.t('copied'), 'success');
            else this.toast(this.t('copy_failed'), 'error');
        } catch (e) {
            this.toast(this.t('copy_failed'), 'error');
        }
    }

    async exportLog() {
        const targetEl = this.currentTab === 'log' ? '#rescue-log' : '#boot-history';
        const text = this.qs(targetEl).textContent || '';
        if (!text || text === this.t('loading')) {
            this.toast(this.t('no_content'), 'warn');
            return;
        }
        // v2.4: WebUI 容器不支持 Blob 下载，改用 shell 写入 /sdcard/Download + am start 分享
        try {
            const ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
            const name = this.currentTab === 'log' ? `rescuex-log-${ts}.txt` : `rescuex-history-${ts}.txt`;
            const filepath = `/sdcard/Download/${name}`;
            const b64 = utf8ToBase64(text);
            if (!/^[A-Za-z0-9+/=]*$/.test(b64)) {
                this.toast(this.t('export_failed'), 'error');
                return;
            }
            const result = await this.exec(`mkdir -p /sdcard/Download && printf '%s' '${b64}' | base64 -d > '${filepath}' && echo OK`);
            if (result.includes('OK')) {
                await this.exec(`am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file://'${filepath}' 2>/dev/null`);
                this.toast((this.lang === 'zh' ? '已保存到 ' : 'Saved to ') + filepath, 'success', 5000);
            } else {
                this.toast(this.t('export_failed'), 'error');
            }
        } catch (e) {
            this.toast(this.t('export_failed'), 'error');
        }
    }

    async clearLog() {
        const target = this.currentTab === 'log' ? this.logFile : this.historyFile;
        const targetEl = this.currentTab === 'log' ? '#rescue-log' : '#boot-history';
        const confirm = await this.confirmDialog(
            this.t('confirm_title'),
            this.t('confirm_clear'),
            this.t('btn_confirm'), 'btn-danger'
        );
        if (!confirm) return;
        try {
            await this.exec(`: > "${target}"`);
            this.qs(targetEl).textContent = this.t('cleared');
            this.toast(this.t('cleared'), 'success');
        } catch (e) {
            this.toast(this.t('save_failed'), 'error');
        }
    }

    // === WebUI 安装偏好 ===
    scheduleWebUiPreferenceCheck(attempt = 0) {
        if (this.webuiPreferenceChecked) return;
        // The onboarding dialog is also modal. Wait for it to close before
        // asking about the installer preference.
        if (this.qs('.onboarding-overlay')) {
            if (attempt < 120) {
                setTimeout(() => this.scheduleWebUiPreferenceCheck(attempt + 1), 1000);
            }
            return;
        }
        this.checkWebUiPreference();
    }

    webUiPreferenceLabel(state, choice) {
        if (state === 'CONFIRMED' && choice === 'install') return this.t('webui_preference_install');
        if (state === 'CONFIRMED' && choice === 'skip') return this.t('webui_preference_skip');
        if (state === 'PENDING') return this.t('webui_preference_pending');
        if (state === 'DEFERRED') return this.t('webui_preference_deferred');
        return '--';
    }

    async checkWebUiPreference() {
        if (this.webuiPreferenceChecked) return;
        this.webuiPreferenceChecked = true;
        try {
            const script = `. "${this.basePath}/webui-choice.sh" 2>/dev/null && rx_webui_choice_status`;
            const result = await this.execStrict(script, 5000);
            if (!result.ok) return;
            const snapshot = this.parseKV(result.stdout || '');
            const state = snapshot.WEBUI_PREF_STATE || 'NONE';
            const choice = snapshot.WEBUI_PREF_CHOICE || 'install';
            this.updateWebUiPreferenceTile(snapshot);
            if (state !== 'PENDING' || (choice !== 'install' && choice !== 'skip')) return;
            const selected = await this.showWebUiPreferenceDialog(choice);
            if (!selected) return;
            const command = selected === 'defer'
                ? `rx_webui_choice_write_deferred ${choice} ui-defer`
                : `rx_webui_choice_write_confirmed ${selected} ui`;
            const saved = await this.execStrict(`. "${this.basePath}/webui-choice.sh" 2>/dev/null && ${command}`, 5000);
            if (!saved.ok) {
                this.toast(this.t('webui_preference_save_failed'), 'error');
                return;
            }
            const nextState = selected === 'defer' ? 'DEFERRED' : 'CONFIRMED';
            const nextChoice = selected === 'defer' ? choice : selected;
            this.updateWebUiPreferenceTile({ WEBUI_PREF_STATE: nextState, WEBUI_PREF_CHOICE: nextChoice });
            this.toast(this.t(selected === 'install'
                ? 'webui_preference_saved_install'
                : selected === 'skip'
                    ? 'webui_preference_saved_skip'
                    : 'webui_preference_deferred_toast'), selected === 'defer' ? 'warn' : 'success', 4500);
        } catch (_) {
            // A missing helper on an older/partial installation should not
            // block the rest of the WebUI.
        }
    }

    updateWebUiPreferenceTile(snapshot) {
        const el = this.qs('#info-webui-preference');
        if (!el) return;
        el.textContent = this.webUiPreferenceLabel(snapshot.WEBUI_PREF_STATE, snapshot.WEBUI_PREF_CHOICE);
    }

    showWebUiPreferenceDialog(choice) {
        const overlay = document.createElement('div');
        overlay.className = 'modal-overlay webui-preference-overlay';
        const modal = document.createElement('div');
        modal.className = 'modal webui-preference-modal';
        modal.setAttribute('role', 'dialog');
        modal.setAttribute('aria-modal', 'true');

        const title = document.createElement('h3');
        title.textContent = this.t('webui_preference_title');
        const body = document.createElement('p');
        body.textContent = this.t(choice === 'skip'
            ? 'webui_preference_desc_skip'
            : 'webui_preference_desc_install');
        const buttons = document.createElement('div');
        buttons.className = 'modal-buttons webui-preference-buttons';

        const makeButton = (labelKey, className, value) => {
            const button = document.createElement('button');
            button.type = 'button';
            button.className = `btn ${className}`;
            button.textContent = this.t(labelKey);
            button.dataset.preferenceValue = value;
            return button;
        };
        const installButton = makeButton('webui_preference_install_action', 'btn-filled', 'install');
        const skipButton = makeButton('webui_preference_skip_action', 'btn-outlined', 'skip');
        const deferButton = makeButton('webui_preference_defer_action', 'btn-text', 'defer');
        buttons.append(installButton, skipButton, deferButton);
        modal.append(title, body, buttons);
        overlay.appendChild(modal);
        document.body.appendChild(overlay);

        return new Promise(resolve => {
            let settled = false;
            const finish = value => {
                if (settled) return;
                settled = true;
                document.removeEventListener('keydown', onKeyDown);
                overlay.remove();
                resolve(value);
            };
            const onKeyDown = event => {
                if (event.key === 'Escape') finish('defer');
            };
            [installButton, skipButton, deferButton].forEach(button => {
                button.addEventListener('click', () => finish(button.dataset.preferenceValue));
            });
            overlay.addEventListener('click', event => {
                if (event.target === overlay) finish('defer');
            });
            document.addEventListener('keydown', onKeyDown);
            installButton.focus();
        });
    }

    // === v2.5: 首次运行引导 ===
    async checkFirstRun() {
        // v3.5.9: acknowledgement is stored in the module state and in the
        // external RescueX persistence directory. Do not use WebView
        // localStorage as the source of truth: some managers recreate the
        // WebView storage whenever the user exits the page.
        try {
            const probe = `for f in "${this.onboardingAckFile}" "/data/adb/rescuex_data/onboarding_ack"; do if [ -f "$f" ]; then cat "$f"; exit 0; fi; done; printf '__NO_ACK__'`;
            const result = await this.execStrict(probe, 5000);
            if (!result.ok) {
                // A bridge failure is not proof that the user needs the notice.
                // Stay quiet rather than reopening it on every entry.
                return;
            }
            let acknowledged = null;
            try { acknowledged = JSON.parse(result.stdout.trim()); } catch (_) {}
            const versionChanged = !acknowledged || acknowledged.version !== APP_VERSION;
            const noticeChanged = !acknowledged || acknowledged.noticeRevision !== ONBOARDING_NOTICE_REVISION;
            // Show a changed safety notice even when the app version itself did
            // not change; acknowledgement is valid only for this exact revision.
            if (versionChanged || noticeChanged) {
                this.showOnboarding(JSON.stringify({ version: APP_VERSION, noticeRevision: ONBOARDING_NOTICE_REVISION }), this.onboardingAckFile);
            }
        } catch (e) { /* bridge unavailable: stay quiet */ }
    }

    showOnboarding(contentHash, ackPath) {
        if (this.onboardingShown) return;
        this.onboardingShown = true;

        const isZh = this.lang === 'zh';
        const overlay = document.createElement('div');
        overlay.className = 'onboarding-overlay';
        overlay.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.5);display:flex;align-items:center;justify-content:center;padding:16px;';

        const modal = document.createElement('div');
        modal.style.cssText = 'background:var(--rx-surface,#fff);border-radius:16px;max-width:440px;width:100%;max-height:85vh;display:flex;flex-direction:column;overflow:hidden;';

        // Header
        const header = document.createElement('div');
        header.style.cssText = 'padding:20px 20px 12px;text-align:center;flex-shrink:0;';
        const logo = document.createElement('div');
        logo.style.cssText = 'width:48px;height:48px;border-radius:12px;background:var(--rx-action,#3d82f5);color:#fff;display:flex;align-items:center;justify-content:center;font-size:24px;font-weight:700;margin:0 auto 8px;';
        logo.textContent = 'R';
        const title = document.createElement('h2');
        title.style.cssText = 'margin:0;font-size:18px;color:var(--rx-ink,#1a1a2e);';
        title.textContent = isZh ? 'RescueX v3.5.11 更新须知' : 'RescueX v3.5.11 Update Notice';
        header.appendChild(logo);
        header.appendChild(title);

        // Scrollable content area
        const body = document.createElement('div');
        body.style.cssText = 'flex:1;overflow-y:auto;padding:0 20px;-webkit-overflow-scrolling:touch;';

        const sections = isZh ? [
            { title: '🔒 隐私协议', items: [
                'RescueX 不联网、不上传任何数据，所有状态文件仅存储在设备本地。',
                '诊断包导出是用户主动操作，包含设备型号、系统版本、模块列表、配置和日志，导出前会脱敏。',
                'GitHub Issue 草稿功能仅打开预填页面，不自动上传文件或代管 Token。',
            ]},
            { title: '📋 使用须知', items: [
                '首次安装默认 DRY_RUN=true（仅记录日志不实际禁用模块），验证逻辑无误后再关闭。',
                '白名单中的模块在救砖时不会被禁用，请将关键模块（字体、音效等）加入白名单。',
                '一次性安全模式会立即写入禁用标记，下次启动生效，请确认后再布防。',
                '覆盖更新后如遇异常，可先卸载模块（会彻底清理状态和持久化目录）再重新安装。',
            ]},
            { title: 'v3.5.11 手机端导航与 OTA 识别修复', items: [
                '修复手机端底部导航无法切页：之前缺少分组隐藏样式，所有卡片堆在同一页。',
                '修复 OTA 长期误报：不再把常驻的厂商属性、update_engine 进程和旧状态文件当作正在更新。',
                'WebUI 安装偏好会在确认后沿用，升级不再每次依赖音量键；旧 WebUI 不会因误按音量下被删除。',
                '新增 MIUI X 与 Material Design 3 外观选择；可选 Monet 动态配色仅作用于 MD3。',
                '已删除与救砖无关的 ColorOS 功能扩展，只保留影响开机超时判断的厂商 OTA 识别。',
                'OTA 识别仍然只影响超时选择，不改失败计数、看门狗、模块禁用/恢复和重启行为。',
            ]},
            { title: '⚠️ 重要提醒', items: [
                '本模块具有 Root 权限，请仅从官方 GitHub Release 下载。',
                '自动救砖会在连续启动失败时禁用非白名单模块并重启，请确保白名单配置正确。',
                '如遇问题请使用诊断包导出功能生成报告，并通过 GitHub Issue 反馈。',
            ]},
        ] : [
            { title: '🔒 Privacy Policy', items: [
                'RescueX does not connect to the internet or upload any data. All state files are stored locally on the device.',
                'Diagnostic bundle export is a user-initiated action containing device model, OS version, module list, config, and logs. Data is redacted before export.',
                'GitHub Issue draft only opens a pre-filled page; it does not auto-upload files or manage tokens.',
            ]},
            { title: '📋 Usage Notice', items: [
                'First install defaults to DRY_RUN=true (log only, no actual disabling). Verify logic before turning it off.',
                'Whitelisted modules are never disabled during rescue. Add critical modules (fonts, audio) to the whitelist.',
                'One-shot safe mode writes disable markers immediately, effective on next boot. Confirm before arming.',
                'If issues occur after an update, uninstall the module (which fully cleans state and persist dirs) then reinstall.',
            ]},
            { title: 'v3.5.11 Mobile navigation and OTA detection fixes', items: [
                'Fixed mobile bottom-navigation switching: the group-hiding style was missing, so every card stacked onto one page.',
                'Fixed a persistent OTA false positive: always-present vendor properties, a running update_engine, and stale status files no longer count as an active update.',
                'A confirmed WebUI install preference survives upgrades, so updates no longer rely on volume keys; an accidental volume-down press cannot delete an existing WebUI.',
                'MIUI X and Material Design 3 are selectable appearances. Optional Monet dynamic color is scoped to MD3.',
                'Removed the ColorOS feature extension, which was unrelated to rescue. Only vendor OTA detection that affects boot timeout remains.',
                'OTA detection still only selects a timeout; it does not change failure counts, the watchdog, module disable/restore, or reboot behavior.',
            ]},
            { title: '⚠️ Important', items: [
                'This module has Root access. Only download from the official GitHub Release.',
                'Auto-rescue disables non-whitelisted modules and reboots after consecutive boot failures.',
                'Use the diagnostic export feature and report issues via GitHub Issues.',
            ]},
        ];

        sections.forEach(sec => {
            const h = document.createElement('div');
            h.style.cssText = 'margin:16px 0 6px;font-size:14px;font-weight:700;color:var(--rx-ink,#1a1a2e);';
            h.textContent = sec.title;
            body.appendChild(h);
            sec.items.forEach(text => {
                const p = document.createElement('div');
                p.style.cssText = 'font-size:13px;line-height:1.6;color:var(--rx-muted,#666);margin:4px 0 4px 12px;';
                p.textContent = '• ' + text;
                body.appendChild(p);
            });
        });

        // Scroll sentinel
        const sentinel = document.createElement('div');
        sentinel.style.cssText = 'height:1px;';
        body.appendChild(sentinel);

        // Footer with countdown
        const footer = document.createElement('div');
        footer.style.cssText = 'padding:12px 20px 16px;flex-shrink:0;border-top:1px solid var(--rx-border,#eee);text-align:center;';
        const hint = document.createElement('div');
        hint.style.cssText = 'font-size:12px;color:var(--rx-muted,#999);margin-bottom:8px;';
        hint.textContent = isZh ? '请滚动到底部并等待倒计时结束' : 'Scroll to bottom and wait for countdown';
        const countdown = document.createElement('div');
        countdown.style.cssText = 'font-size:13px;color:var(--rx-muted,#999);margin-bottom:8px;';
        countdown.textContent = isZh ? '请先滚动到底部' : 'Please scroll to bottom first';
        const btn = document.createElement('button');
        btn.className = 'btn btn-filled';
        btn.style.cssText = 'width:100%;opacity:0.4;pointer-events:none;';
        btn.textContent = isZh ? `我已阅读并了解（${ONBOARDING_COUNTDOWN_SECONDS}s）` : `I have read and understood (${ONBOARDING_COUNTDOWN_SECONDS}s)`;
        footer.appendChild(hint);
        footer.appendChild(countdown);
        footer.appendChild(btn);

        modal.appendChild(header);
        modal.appendChild(body);
        modal.appendChild(footer);
        overlay.appendChild(modal);
        document.body.appendChild(overlay);

        // Track scroll state
        let scrolledToBottom = false;
        let countdownSec = ONBOARDING_COUNTDOWN_SECONDS;
        let timer = null;

        const updateButton = () => {
            if (scrolledToBottom && countdownSec <= 0) {
                btn.style.opacity = '1';
                btn.style.pointerEvents = 'auto';
                btn.textContent = isZh ? '我已阅读并了解' : 'I have read and understood';
            } else {
                btn.style.opacity = '0.4';
                btn.style.pointerEvents = 'none';
                if (!scrolledToBottom) {
                    countdown.textContent = isZh ? '请先滚动到底部' : 'Please scroll to bottom first';
                } else {
                    countdown.textContent = isZh ? `请等待 ${countdownSec}s` : `Please wait ${countdownSec}s`;
                }
            }
        };

        body.addEventListener('scroll', () => {
            if (body.scrollTop + body.clientHeight >= body.scrollHeight - 4) {
                if (!scrolledToBottom) {
                    scrolledToBottom = true;
                    // Start countdown only after scrolling to bottom
                    timer = setInterval(() => {
                        countdownSec--;
                        updateButton();
                        if (countdownSec <= 0) {
                            clearInterval(timer);
                            timer = null;
                        }
                    }, 1000);
                }
            }
        });

        btn.onclick = async () => {
            if (!(scrolledToBottom && countdownSec <= 0)) return;
            btn.disabled = true;
            btn.style.opacity = '0.65';
            const persistPath = '/data/adb/rescuex_data/onboarding_ack';
            const stateTmp = `${ackPath}.tmp.$$`;
            const persistTmp = `${persistPath}.tmp.$$`;
            const shellQuote = value => `'${String(value).replace(/'/g, "'\\''")}'`;
            const command = `umask 077; mkdir -p "${this.stateDir}" "/data/adb/rescuex_data" && printf '%s\n' ${shellQuote(contentHash)} > "${stateTmp}" && mv -f "${stateTmp}" "${ackPath}" && printf '%s\n' ${shellQuote(contentHash)} > "${persistTmp}" && mv -f "${persistTmp}" "${persistPath}" && chmod 0600 "${ackPath}" "${persistPath}"`;
            const result = await this.execStrict(command, 5000);
            if (!result.ok) {
                btn.disabled = false;
                btn.style.opacity = '1';
                this.toast(isZh ? '确认状态保存失败，请重试' : 'Could not save acknowledgement. Try again.', 'error');
                return;
            }
            try { localStorage.setItem('rescuex_onboarding_notice_ack', contentHash); } catch (_) {}
            if (timer) { clearInterval(timer); timer = null; }
            overlay.remove();
            this.toast(isZh ? '欢迎使用 RescueX v3.5.11' : 'Welcome to RescueX v3.5.11', 'success');
        };

        updateButton();
    }

    // === v2.5: 启动统计面板 ===
    async loadStats(options = {}) {
        try {
            const stats = options.snapshot || await this.getDashboardSnapshot({ force: !!options.force });
            if (!stats || typeof stats.TOTAL === 'undefined') {
                throw new Error('invalid stats output');
            }
            const total = parseInt(stats.TOTAL) || 0;
            const success = parseInt(stats.SUCCESS) || 0;
            const rescued = parseInt(stats.RESCUED) || 0;
            const failed = parseInt(stats.FAILED) || 0;
            const rate = parseInt(stats.SUCCESS_RATE) || 0;
            const avgDur = parseInt(stats.AVG_DURATION) || 0;
            const lastRescue = parseInt(stats.LAST_RESCUE_TIME) || 0;
            const lastSuccess = parseInt(stats.LAST_SUCCESS_TIME) || 0;

            this.setText('#stat-success-rate', `${rate}%`);
            this.setText('#stat-avg-duration', avgDur > 0 ? `${avgDur}${this.t('seconds')}` : '--');
            this.setText('#stat-total', total);
            this.setText('#stat-rescued', rescued);
            this.setText('#stat-success', success);
            this.setText('#stat-failed', failed);
            this.setText('#stat-last-success', lastSuccess > 0 ? this.formatTime(lastSuccess) : this.t('never'));
            // v3.5.10-r2: 已发生救砖但时间未知（早期 RTC）时显示"时间未知"而非"从未"
            this.setText('#stat-last-rescue', lastRescue > 0 ? this.formatTime(lastRescue) : (rescued > 0 ? this.t('unknown_time') : this.t('never')));

            // 颜色提示
            const rateEl = this.qs('#stat-success-rate');
            if (rateEl) {
                rateEl.className = 'stat-value ' + (rate >= 90 ? 'ok' : (rate >= 60 ? 'warn' : 'danger'));
            }
            const rescuedEl = this.qs('#stat-rescued');
            if (rescuedEl) {
                rescuedEl.className = 'stat-value ' + (rescued === 0 ? 'ok' : 'warn');
            }
        } catch (e) {
            // v2.6.0 F-BUG-7: 补充 console.warn 辅助排障，保留原 UI 重置 + toast 提示
            console.warn('[RescueX] loadStats failed:', e,
                '\n  basePath=', this.basePath,
                '\n  可能原因：common.sh 不在该路径（F-BUG-5）、exec 超时、compute_boot_stats 输出格式异常');
            this.setText('#stat-success-rate', '--%');
            this.setText('#stat-avg-duration', '--');
            this.setText('#stat-last-success', this.t('unknown_time'));
            this.setText('#stat-last-rescue', this.t('unknown_time'));
            if (!options.silent) this.toast(this.t('stats_unavailable'), 'warn');
        }
    }

    async refreshStats() {
        this.showLoading(true);
        await this.loadStats();
        this.showLoading(false);
        this.toast(this.t('refreshed'), 'success');
    }

    // v2.5: 时间戳格式化为相对时间
    formatTime(epoch) {
        if (!epoch || epoch <= 0) return this.t('never');
        const now = Math.floor(Date.now() / 1000);
        const diff = now - epoch;
        if (diff < 0) return this.t('unknown_time');
        if (diff < 60) return this.t('just_now');
        if (diff < 3600) return `${Math.floor(diff / 60)} ${this.t('minutes_ago')}`;
        if (diff < 86400) return `${Math.floor(diff / 3600)} ${this.t('hours_ago')}`;
        return `${Math.floor(diff / 86400)} ${this.t('days_ago')}`;
    }

    // === v2.5: 文档 Modal（功能介绍/隐私协议/使用须知）===
    _showDocModal(title, htmlContent) {
        const overlay = document.createElement('div');
        overlay.className = 'modal-overlay';
        const modal = document.createElement('div');
        modal.className = 'doc-modal';
        const h2 = document.createElement('h2');
        h2.textContent = title;
        const body = document.createElement('div');
        // htmlContent 仅来自 showFeatures/showPrivacy/showUsage 中的硬编码文档。
        body.innerHTML = htmlContent;
        const actions = document.createElement('div');
        actions.className = 'doc-actions';
        const closeBtn = document.createElement('button');
        closeBtn.className = 'btn btn-filled';
        closeBtn.textContent = this.t('doc_close');
        actions.appendChild(closeBtn);
        modal.appendChild(h2);
        modal.appendChild(body);
        modal.appendChild(actions);
        overlay.appendChild(modal);
        document.body.appendChild(overlay);
        const close = () => overlay.remove();
        closeBtn.onclick = close;
        overlay.onclick = (e) => { if (e.target === overlay) close(); };
    }

    showFeatures() {
        const isZh = this.lang === 'zh';
        const html = isZh ? `
            <h3>核心保护</h3>
            <ul>
                <li><strong>连续重启检测</strong>：达到阈值（默认 3 次）自动禁用所有非白名单模块</li>
                <li><strong>开机超时看门狗</strong>：开机超过指定时长未完成，自动救砖并重启</li>
                <li><strong>渐进式救砖</strong>：第一次失败只禁用最近安装的模块，达到阈值才全禁</li>
                <li><strong>白名单保护</strong>：关键模块（字体、音效等）可加入白名单不被禁用</li>
            </ul>
            <h3>智能识别</h3>
            <ul>
                <li><strong>OTA 智能识别</strong>：检测底层 OTA 升级（属性 / recovery / BCB / update_engine），自动延长超时（默认 15 分钟）</li>
                <li><strong>补丁更新识别</strong>：区分 ColorOS/MIUI 等上层系统补丁与底层 OTA，独立超时与失败计数，达到阈值只做轻量回滚</li>
                <li><strong>用户重启识别</strong>：短时间内主动重启不计入失败次数</li>
                <li><strong>启动模式感知</strong>（v2.5）：Recovery / Fastbootd / Charger 模式自动跳过失败计数</li>
            </ul>
            <h3>高级特性</h3>
            <ul>
                <li><strong>DRY_RUN 模式</strong>：仅记录日志不实际禁用，方便验证逻辑</li>
                <li><strong>自动恢复</strong>（实验性）：救砖后下次启动自动恢复被禁用的模块</li>
                <li><strong>模块状态快照</strong>：手动创建快照，补丁回滚或误禁用后可一键恢复</li>
                <li><strong>诊断报告</strong>：一键生成含设备信息、模块状态、日志片段的纯文本报告</li>
                <li><strong>启动统计</strong>（v2.5）：成功率、平均耗时、救砖时间线</li>
                <li><strong>三级渐进式救砖</strong>（v3.0）：嫌疑禁用 → 全量+脚本锁定 → APP 解冻，逐级升级不遗漏任何可能</li>
                <li><strong>嫌疑模块追踪</strong>（v3.0）：启动成功后自动记录已知良好列表，下次失败精准对比定位新增/新启用模块</li>
                                <li><strong>APP 自动解冻</strong>（v3.0）：删除 package-restrictions.xml 解冻被 PM 冻结的关键应用</li>
            </ul>
            <h3>安全设计</h3>
            <ul>
                <li>状态原子写入（tmp+sync+rename，断电不损坏）</li>
                <li>看门狗独立进程，双 fork 脱离父进程</li>
                <li>kill 前按 cmdline 验证 PID，避免 PID 复用误杀</li>
                <li>看门狗自适应轮询（v2.5）：长超时场景自动放大间隔，减少 I/O</li>
                <li>WebUI 路径白名单校验、base64 编码传输、textContent 防 XSS</li>
                <li>最小权限：状态目录 0700，敏感文件 0600，脚本 0700</li>
            </ul>
        ` : `
            <h3>Core Protection</h3>
            <ul>
                <li><strong>Consecutive Reboot Detection</strong>: Disable all non-whitelisted modules after threshold (default 3)</li>
                <li><strong>Boot Timeout Watchdog</strong>: Auto-rescue and reboot if boot not completed in time</li>
                <li><strong>Progressive Rescue</strong>: First failure only disables recently installed modules</li>
                <li><strong>Whitelist Protection</strong>: Critical modules (fonts, audio, etc.) survive rescue</li>
            </ul>
            <h3>Smart Detection</h3>
            <ul>
                <li><strong>OTA Detection</strong>: Detects firmware OTA via props/recovery/BCB/update_engine, extends timeout (default 15 min)</li>
                <li><strong>Patch Update Detection</strong>: Distinguishes ColorOS/MIUI patches from OTA, independent timeout & rollback</li>
                <li><strong>User Reboot Recognition</strong>: Short reboots not counted as failures</li>
                <li><strong>Boot Mode Awareness</strong> (v2.5): Recovery/Fastbootd/Charger modes skip failure counting</li>
            </ul>
            <h3>Advanced</h3>
            <ul>
                <li><strong>DRY_RUN</strong>: Log-only mode for logic validation</li>
                <li><strong>Auto Re-enable</strong> (experimental): Restore disabled modules on next boot</li>
                <li><strong>Snapshots</strong>: Manual state snapshots for one-click rollback</li>
                <li><strong>Diagnostic Report</strong>: One-click text report with device info & logs</li>
                <li><strong>Boot Statistics</strong> (v2.5): Success rate, avg duration, rescue timeline</li>
                <li><strong>Three-Level Rescue</strong> (v3.0): Suspect disable → Full + Script Lock → APP Unfreeze</li>
                <li><strong>Suspect Module Tracking</strong> (v3.0): Auto-saves known-good list on success, diff-compares on failure</li>
                <li><strong>Script Directory Locking</strong> (v3.0): Lock service.d/post-fs-data.d permissions during full rescue</li>
                <li><strong>APP Auto-Unfreeze</strong> (v3.0): Delete package-restrictions.xml to unfreeze critical apps</li>
            </ul>
            <h3>Security</h3>
            <ul>
                <li>Atomic state writes (tmp+sync+rename)</li>
                <li>Independent watchdog process (double fork)</li>
                <li>PID verification via cmdline before kill</li>
                <li>Adaptive watchdog polling (v2.5)</li>
                <li>WebUI path whitelist, base64 transport, XSS prevention</li>
                <li>Least privilege: 0700 dirs, 0600 sensitive files, 0700 scripts</li>
            </ul>
        `;
        this._showDocModal(this.t('features_title'), html);
    }

    showPrivacy() {
        const isZh = this.lang === 'zh';
        const html = isZh ? `
            <div class="privacy-section">
                <h3>1. 数据收集声明</h3>
                <p>RescueX <strong>不收集、不上传、不分享</strong>任何用户数据。所有运行数据均存储在设备本地的 <code>/data/adb/modules/RescueX/webroot/state/</code> 目录下。</p>
            </div>
            <div class="privacy-section">
                <h3>2. 本地存储的数据</h3>
                <p>以下数据仅存储在设备本地，不会离开设备：</p>
                <ul>
                    <li><strong>配置文件</strong>（config.conf）：救砖参数（阈值、超时等）</li>
                    <li><strong>白名单</strong>（whitelist.conf）：用户指定的保护模块列表</li>
                    <li><strong>启动状态</strong>（boot_status）：上次启动结果、失败计数、救砖次数</li>
                    <li><strong>启动历史</strong>（boot_history）：最近 100 次启动记录（仅时间与结果，无内容）</li>
                    <li><strong>日志</strong>（rescue.log）：救砖操作日志（超 500KB 自动轮转，保留最后 200 行）</li>
                    <li><strong>快照</strong>（snapshots/）：模块启用/禁用状态快照</li>
                </ul>
            </div>
            <div class="privacy-section">
                <h3>3. 系统信息读取</h3>
                <p>为完成救砖功能，RescueX 会读取以下系统信息（仅本地处理，不上传）：</p>
                <ul>
                    <li>设备型号、Android 版本、内核版本（仅用于诊断报告）</li>
                    <li>系统属性（getprop）用于 OTA/补丁/启动模式检测</li>
                    <li>已安装模块列表（仅模块 ID，不读取模块内容）</li>
                    <li>LSPosed 禁用状态（v2.5，仅用于诊断）</li>
                </ul>
            </div>
            <div class="privacy-section">
                <h3>4. 网络行为</h3>
                <p>RescueX 仅在用户点击检查更新时访问 GitHub 上的 <code>update.json</code> 与 Releases 页面。WebUI 中的"导出配置/报告"功能通过 shell 写入 <code>/sdcard/Download/</code>，由用户自行管理。</p>
            </div>
            <div class="privacy-section">
                <h3>5. 卸载与数据清理</h3>
                <p>卸载模块时，<code>uninstall.sh</code> 会彻底清理所有状态文件、日志、快照与临时文件，不残留任何数据。</p>
            </div>
            <div class="privacy-section">
                <h3>6. 权限说明</h3>
                <p>RescueX 通过 root 权限运行（Magisk/KernelSU/APatch 提供），仅执行以下操作：</p>
                <ul>
                    <li>读写 <code>/data/adb/modules/</code> 下的模块 disable 标记</li>
                    <li>读取系统属性、/proc、/dev/block 信息</li>
                    <li>触发系统重启（仅救砖时）</li>
                </ul>
                <p>不会访问通讯录、短信、相册、位置等敏感数据。</p>
            </div>
        ` : `
            <div class="privacy-section">
                <h3>1. Data Collection</h3>
                <p>RescueX <strong>does not collect, upload, or share</strong> any user data. All runtime data is stored locally at <code>/data/adb/modules/RescueX/webroot/state/</code>.</p>
            </div>
            <div class="privacy-section">
                <h3>2. Locally Stored Data</h3>
                <ul>
                    <li><strong>Config</strong> (config.conf): Rescue parameters</li>
                    <li><strong>Whitelist</strong> (whitelist.conf): Protected modules</li>
                    <li><strong>Boot Status</strong> (boot_status): Last result, fail count, rescue count</li>
                    <li><strong>Boot History</strong> (boot_history): Last 100 boots (time + result only)</li>
                    <li><strong>Logs</strong> (rescue.log): Auto-rotates at 500KB, keeps last 200 lines</li>
                    <li><strong>Snapshots</strong> (snapshots/): Module state snapshots</li>
                </ul>
            </div>
            <div class="privacy-section">
                <h3>3. System Info Access</h3>
                <ul>
                    <li>Device model, Android version, kernel (for diagnostic report only)</li>
                    <li>System properties (getprop) for OTA/patch/boot mode detection</li>
                    <li>Installed module list (IDs only, not content)</li>
                    <li>LSPosed state (v2.5, diagnostic only)</li>
                </ul>
            </div>
            <div class="privacy-section">
                <h3>4. Network</h3>
                <p>RescueX only contacts GitHub <code>update.json</code> and Releases when the user taps Check Updates. Export features write to <code>/sdcard/Download/</code> via shell.</p>
            </div>
            <div class="privacy-section">
                <h3>5. Uninstall</h3>
                <p><code>uninstall.sh</code> completely removes all state, logs, snapshots, and temp files.</p>
            </div>
            <div class="privacy-section">
                <h3>6. Permissions</h3>
                <p>Runs as root (via Magisk/KernelSU/APatch). Only:</p>
                <ul>
                    <li>Reads/writes module disable flags in <code>/data/adb/modules/</code></li>
                    <li>Reads system props, /proc, /dev/block</li>
                    <li>Triggers reboot (only on rescue)</li>
                </ul>
                <p>Does NOT access contacts, SMS, gallery, location, or other sensitive data.</p>
            </div>
        `;
        this._showDocModal(this.t('privacy_title'), html);
    }

    showUsage() {
        const isZh = this.lang === 'zh';
        const html = isZh ? `
            <h3>⚠ 使用前必读</h3>
            <p>本模块涉及<strong>禁用系统模块</strong>和<strong>触发重启</strong>，使用前请务必：</p>
            <ol>
                <li><strong>备份重要数据</strong>：虽然救砖逻辑设计为只禁用模块不清数据，但极端情况下仍可能需要恢复出厂设置。</li>
                <li><strong>在测试设备上验证</strong>：首次使用建议先在非主力设备上测试，确认逻辑符合预期。</li>
                <li><strong>开启 DRY_RUN 模式</strong>：首次使用时勾选 DRY_RUN，仅记录日志不实际禁用，观察日志确认逻辑无误后再正式启用。</li>
            </ul>

            <h3>📋 推荐配置流程</h3>
            <ol>
                <li>安装模块后重启设备</li>
                <li>打开 WebUI，完成首次引导</li>
                <li>开启 <code>DRY_RUN</code> 模式，保存配置</li>
                <li>重启设备，观察 <code>rescue.log</code> 是否正常记录启动过程</li>
                <li>确认无误后，关闭 DRY_RUN，根据需要调整阈值与超时</li>
                <li>将关键模块（字体、音效等）加入白名单</li>
                <li>拍一张当前模块状态快照，作为恢复基线</li>
            </ul>

            <h3>🔧 参数调优建议</h3>
            <ul>
                <li><strong>连续重启阈值</strong>：保守用户设为 5，激进用户设为 2（更快救砖但更易误触发）</li>
                <li><strong>开机超时</strong>：慢速设备建议 120-180 秒，旗舰设备 60-90 秒即可</li>
                <li><strong>用户重启宽限期</strong>：频繁调试模块的用户建议设为 60-120 秒</li>
                <li><strong>看门狗轮询间隔</strong>：默认 2 秒足够；长超时场景会自动放大（v2.5），无需手动调整</li>
            </ul>

            <h3>🚨 故障排查</h3>
            <p><strong>救砖未触发：</strong></p>
            <ul>
                <li>检查 <code>config.conf</code> 中 <code>ENABLED=true</code></li>
                <li>检查 <code>rescue.log</code> 是否有 post-fs-data 启动记录</li>
                <li>确认失败次数达到阈值</li>
            </ul>
            <p><strong>误触发救砖：</strong></p>
            <ul>
                <li>调大 <code>USER_REBOOT_GRACE_SEC</code></li>
                <li>开启 <code>DRY_RUN</code> 验证逻辑</li>
                <li>调高 <code>REBOOT_THRESHOLD</code></li>
            </ul>
            <p><strong>系统更新后误触发：</strong></p>
            <ul>
                <li>确认 <code>detect_ota</code> / <code>detect_patch_update</code> 能识别你的 ROM</li>
                <li>适当调大 <code>OTA_TIMEOUT_SEC</code> 或 <code>PATCH_UPDATE_TIMEOUT_SEC</code></li>
            </ul>

            <h3>⚠️ 免责声明</h3>
            <p>本模块作者<strong>不对因使用本模块导致的任何数据丢失或设备损坏负责</strong>。使用即表示你已理解并接受风险。</p>
            <p>如遇救砖后仍无法启动，可尝试：</p>
            <ol>
                <li>进入 Recovery，手动删除 <code>/data/adb/modules/问题模块/disable</code> 之外的所有 disable 标记</li>
                <li>或在 Recovery 中删除 RescueX 模块目录</li>
                <li>极端情况下需恢复出厂设置</li>
            </ol>
        ` : `
            <h3>⚠ Before You Start</h3>
            <p>This module <strong>disables system modules</strong> and <strong>triggers reboots</strong>. Before use:</p>
            <ol>
                <li><strong>Backup important data</strong>: Although rescue logic only disables modules, factory reset may be needed in extreme cases.</li>
                <li><strong>Test on non-primary device</strong>: Validate behavior before deploying to your main device.</li>
                <li><strong>Enable DRY_RUN first</strong>: Log-only mode to verify logic before enabling for real.</li>
            </ol>

            <h3>📋 Recommended Setup</h3>
            <ol>
                <li>Install module, reboot</li>
                <li>Open WebUI, complete onboarding</li>
                <li>Enable <code>DRY_RUN</code>, save config</li>
                <li>Reboot, check <code>rescue.log</code> for normal startup logging</li>
                <li>If OK, disable DRY_RUN, tune thresholds</li>
                <li>Add critical modules (fonts, audio) to whitelist</li>
                <li>Take a snapshot as recovery baseline</li>
            </ol>

            <h3>🔧 Tuning Tips</h3>
            <ul>
                <li><strong>Reboot Threshold</strong>: Conservative = 5, Aggressive = 2</li>
                <li><strong>Boot Timeout</strong>: Slow devices 120-180s, flagships 60-90s</li>
                <li><strong>Grace Period</strong>: Frequent module testers: 60-120s</li>
                <li><strong>Poll Interval</strong>: Default 2s is fine; auto-scales for long timeouts (v2.5)</li>
            </ol>

            <h3>🚨 Troubleshooting</h3>
            <p><strong>Rescue not triggered:</strong></p>
            <ul>
                <li>Check <code>ENABLED=true</code> in config.conf</li>
                <li>Check rescue.log for post-fs-data entries</li>
                <li>Confirm fail count reaches threshold</li>
            </ul>
            <p><strong>False rescue trigger:</strong></p>
            <ul>
                <li>Increase <code>USER_REBOOT_GRACE_SEC</code></li>
                <li>Enable <code>DRY_RUN</code> to verify</li>
                <li>Increase <code>REBOOT_THRESHOLD</code></li>
            </ul>

            <h3>⚠️ Disclaimer</h3>
            <p>The author is <strong>NOT responsible for any data loss or device damage</strong> resulting from use of this module. Use at your own risk.</p>
        `;
        this._showDocModal(this.t('usage_title'), html);
    }

    // === v2.7: 救砖审计日志 ===
    async loadAuditLog() {
        try {
            const raw = await this.exec(`cat "${this.stateDir}/rescue_audit.log" 2>/dev/null`, EXEC_DEFAULT_TIMEOUT_MS);
            const el = this.qs('#audit-log-content');
            if (!el) return;
            if (!raw || raw.trim() === '') {
                el.textContent = this.t('no_audit');
                return;
            }
            // Convert epoch timestamps to readable time
            const lines = raw.split('\n').filter(l => l.trim());
            const converted = lines.map(line => {
                const match = line.match(/^\[(\d+)\]\s*(.*)/);
                if (match && /^\d{10}$/.test(match[1])) {
                    const d = new Date(parseInt(match[1]) * 1000);
                    let timeStr;
                    try {
                        timeStr = d.toLocaleString(this.lang === 'zh' ? 'zh-CN' : 'en-US', {
                            timeZone: this.systemTimezone || undefined
                        });
                    } catch (_) {
                        // Invalid/unknown Android timezone values must not break
                        // the whole audit view; fall back to WebView local time.
                        timeStr = d.toLocaleString(this.lang === 'zh' ? 'zh-CN' : 'en-US');
                    }
                    return `[${timeStr}] ${match[2]}`;
                }
                return line;
            });
            el.textContent = converted.join('\n');
        } catch (e) {
            console.warn('loadAuditLog failed:', e);
        }
    }

    async refreshAuditLog() {
        await this.loadAuditLog();
        this.toast(this.t('refreshed'), 'success');
    }

    async copyAuditLog() {
        const el = this.qs('#audit-log-content');
        if (!el) return;
        const text = el.textContent || '';
        if (!text || text === this.t('no_audit')) {
            this.toast(this.t('no_content'), 'warn');
            return;
        }
        try {
            if (navigator.clipboard && navigator.clipboard.writeText) {
                await navigator.clipboard.writeText(text);
                this.toast(this.t('copied'), 'success');
                return;
            }
        } catch (e) { /* fallback */ }
        try {
            const ta = document.createElement('textarea');
            ta.value = text;
            ta.style.cssText = 'position:fixed;top:-9999px;left:-9999px;opacity:0;';
            document.body.appendChild(ta);
            ta.select();
            document.execCommand('copy');
            document.body.removeChild(ta);
            this.toast(this.t('copied'), 'success');
        } catch (e) {
            this.toast(this.t('copy_failed'), 'error');
        }
    }

    // === v2.7: 单模块启用/禁用切换 ===
    async toggleModule(modId, enable) {
        if (!MODULE_ID_RE.test(String(modId || '')) || typeof enable !== 'boolean') {
            this.toast(this.t('save_failed'), 'error');
            return;
        }
        const action = enable ? 'enable' : 'disable';
        try {
            // Source common.sh to use toggle_single_module function
            const cmd = `. "${this.basePath}/common.sh" && toggle_single_module "${modId}" ${action}; echo RESULT=$?`;
            const result = await this.exec(cmd, EXEC_DEFAULT_TIMEOUT_MS);
            if (!result.includes('RESULT=0')) {
                this.toast(this.t('save_failed'), 'error');
                return;
            }
            this.toast(enable ? `${modId} ${this.lang === 'zh' ? '已启用' : 'enabled'}` : `${modId} ${this.lang === 'zh' ? '已禁用' : 'disabled'}`);
            // Refresh module lists
            await Promise.all([this.loadModules(), this.loadDisabledModules()]);
        } catch (e) {
            this.toast(this.t('save_failed'), 'error');
        }
    }

    // === v2.7: 导出完整状态 ===
    async exportFullState() {
        try {
            const ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
            const filepath = `/sdcard/Download/rescuex-full-state-${ts}.txt`;
            const cmd = `. "${this.basePath}/common.sh" && export_full_state "${filepath}"`;
            const result = await this.exec(cmd, EXEC_DEFAULT_TIMEOUT_MS);
            if (result.includes(filepath)) {
                await this.exec(`am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file://'${filepath}' 2>/dev/null`);
                this.toast((this.lang === 'zh' ? '已保存到 ' : 'Saved to ') + filepath, 'success', 5000);
            } else {
                this.toast(this.t('export_failed'), 'error');
            }
        } catch (e) {
            this.toast(this.t('export_failed'), 'error');
        }
    }

    // === v2.7.1: 自定义目录权限 ===
    async loadCustomDirs() {
        try {
            const raw = await this.exec(`cat "${this.customDirsFile}" 2>/dev/null`);
            const el = this.qs('#custom-dirs-list');
            if (!el) return;
            const entries = [];
            if (raw && raw.trim()) {
                raw.trim().split('\n').forEach(line => {
                    const parts = line.trim().split(/\s+/);
                    if (parts.length >= 2) {
                        const path = this.normalizeCustomDirPath(parts[0]);
                        entries.push({ path, perms: parts[1], valid: this.isSafeCustomDirPath(path) });
                    }
                });
            }
            this._customDirs = entries;
            this._renderCustomDirs();
            this.renderReadiness();
        } catch (e) {
            console.warn('loadCustomDirs failed:', e);
        }
    }

    _renderCustomDirs() {
        const el = this.qs('#custom-dirs-list');
        if (!el) return;
        const entries = this._customDirs || [];
        if (entries.length === 0) {
            el.innerHTML = `<div class="empty-state">${this.t('no_custom_dirs')}</div>`;
            return;
        }
        let html = '';
        entries.forEach((e, i) => {
            html += `<div class="custom-dir-row${e.valid === false ? ' invalid' : ''}">
                <input type="text" class="dir-path" value="${this.escapeHtml(e.path)}" placeholder="${this.t('dir_path')}">
                <select class="dir-perms">
                    <option value="770" ${e.perms === '770' ? 'selected' : ''}>770</option>
                    <option value="755" ${e.perms === '755' ? 'selected' : ''}>755</option>
                    <option value="700" ${e.perms === '700' ? 'selected' : ''}>700</option>
                    <option value="750" ${e.perms === '750' ? 'selected' : ''}>750</option>
                </select>
                <button class="btn-icon-del" data-action="removeCustomDir" data-index="${i}">&times;</button>
                ${e.valid === false ? `<div class="custom-dir-error">${this.escapeHtml(this.t('custom_dir_invalid'))}</div>` : ''}
            </div>`;
        });
        el.innerHTML = html;
    }

    addCustomDir() {
        if (!this._customDirs) this._customDirs = [];
        this._customDirs.push({ path: '', perms: '770', valid: true });
        this._renderCustomDirs();
    }

    async removeCustomDir(e, target) {
        const idx = parseInt(target.dataset.index);
        if (isNaN(idx) || !this._customDirs) return;
        this._customDirs.splice(idx, 1);
        this._renderCustomDirs();
    }

    async saveCustomDirs() {
        const rows = document.querySelectorAll('#custom-dirs-list .custom-dir-row');
        const entries = [];
        rows.forEach(row => {
            const pathInput = row.querySelector('.dir-path');
            const permsSelect = row.querySelector('.dir-perms');
            const path = this.normalizeCustomDirPath((pathInput && pathInput.value) || '');
            const perms = permsSelect ? permsSelect.value : '770';
            if (path) entries.push(`${path} ${perms}`);
        });
        this._customDirs = entries.map(e => {
            const parts = e.split(/\s+/);
            const path = this.normalizeCustomDirPath(parts[0]);
            return { path, perms: parts[1] || '770', valid: this.isSafeCustomDirPath(path) };
        });
        const invalid = this._customDirs.filter(e => e.valid === false).length;
        try {
            const safeEntries = this._customDirs.filter(e => e.valid).map(e => `${e.path} ${e.perms}`);
            const content = safeEntries.join('\n') || '';
            const b64 = utf8ToBase64(content + (content ? '\n' : ''));
            if (!/^[A-Za-z0-9+/=]*$/.test(b64)) {
                this.toast(this.t('save_failed'), 'error');
                return;
            }
            const result = await this.exec(`TMP_FILE="${this.stateDir}/.custom_dirs.upload.$$"; trap 'rm -f "$TMP_FILE"' EXIT; umask 077; printf '%s' '${b64}' | base64 -d > "$TMP_FILE" && . "${this.basePath}/common.sh" && save_custom_dirs_file "$TMP_FILE"`);
            if (result.includes('SAVED=')) {
                this.toast(this.t('saved'), 'success');
                if (invalid > 0) {
                    this.toast(this.t('custom_dir_rejected').replace('N', String(invalid)), 'warn', 5000);
                }
                await this.loadCustomDirs();
            } else {
                this.toast(this.t('save_failed'), 'error');
            }
        } catch (e) {
            this.toast(this.t('save_failed'), 'error');
        }
    }

    // === v2.7: 启动耗时趋势 ===
    async loadBootTrend() {
        try {
            const raw = await this.exec(`cat "${this.historyFile}" 2>/dev/null | grep SERVICE | tail -n 9`, EXEC_DEFAULT_TIMEOUT_MS);
            const el = this.qs('#boot-trend');
            if (!el) return;
            if (!raw || raw.trim() === '') {
                el.textContent = '--';
                return;
            }
            const lines = raw.trim().split('\n');
            let entries = [];
            for (const line of lines) {
                const durMatch = line.match(/duration=(\d+)s/);
                const timeMatch = line.match(/^\[(\d+)\]/);
                if (!durMatch) continue;
                const dur = parseInt(durMatch[1]);
                if (dur <= 0 || dur > 3600) continue;
                let label = '';
                if (timeMatch && /^\d{10}$/.test(timeMatch[1])) {
                    const d = new Date(parseInt(timeMatch[1]) * 1000);
                    label = `${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`;
                }
                entries.push({ dur, label, raw: line });
            }
            if (entries.length === 0) {
                el.textContent = '--';
                return;
            }
            const maxDur = Math.max(...entries.map(e => e.dur));
            let html = '';
            for (const e of entries) {
                const pct = maxDur > 0 ? Math.round((e.dur / maxDur) * 100) : 100;
                const cls = e.dur >= 120 ? 'slow' : 'normal';
                html += `<div class="boot-trend-bar-wrap">
                    <span class="boot-trend-value">${e.dur}s</span>
                    <div class="boot-trend-bar ${cls}" style="height:${pct}%"></div>
                    <span class="boot-trend-label">${e.label}</span>
                </div>`;
            }
            el.innerHTML = html;
        } catch (e) {
            console.warn('loadBootTrend failed:', e);
        }
    }

    // === v3.0.1: 嫌疑模块追踪面板 ===
    async loadSuspectModules() {
        try {
            const goodRaw = await this.exec(`cat "${this.stateDir}/good_modules.list" 2>/dev/null`, EXEC_DEFAULT_TIMEOUT_MS);
            const goodEntries = goodRaw.split('\n').map(line => line.trim()).filter(line => line && !line.startsWith('#'));
            const goodEnabledCount = goodEntries.filter(line => !line.startsWith(':') && MODULE_ID_RE.test(line)).length;
            const goodTotalCount = goodEntries.filter(line => MODULE_ID_RE.test(line.replace(/^:/, ''))).length;
            const modulesRaw = await this.exec(`. "${this.basePath}/common.sh" && list_all_modules | cut -d'|' -f1,2`, EXEC_DEFAULT_TIMEOUT_MS);
            const currentModules = modulesRaw.split('\n').map(line => line.trim()).filter(Boolean).map(line => {
                const parts = line.split('|');
                return { id: parts[0], enabled: parts[1] === '1' };
            }).filter(item => item.id);
            const currentModuleIds = new Set(currentModules.map(item => item.id));
            this.setText('#info-good-modules', goodEnabledCount);
            this.goodModuleStats = { enabled: goodEnabledCount, total: goodTotalCount };

            // Load suspect log
            const suspectRaw = await this.exec(`cat "${this.stateDir}/suspect_modules.log" 2>/dev/null`);
            const el = this.qs('#suspect-list');
            if (!el) return;

            if (!suspectRaw || suspectRaw.trim() === '' || suspectRaw.trim().startsWith('#')) {
                el.innerHTML = `<div class="empty-state">${goodTotalCount > 0 ? (this.lang === 'zh' ? '暂无嫌疑记录（已知良好模块已建立）' : 'No suspects (good module list is established)') : this.t('loading')}</div>`;
                this.setText('#info-suspect-count', 0);
                this.renderReadiness();
                return;
            }

            const suspects = suspectRaw.split('\n').filter(l => l.trim() && !l.trim().startsWith('#')).filter(line => {
                const clean = line.replace(/^[?+:]/, '').trim();
                return clean && currentModuleIds.has(clean);
            });
            const certain = suspects.filter(s => !s.startsWith('?') && !s.startsWith('+'));
            const stateChanged = suspects.filter(s => s.startsWith('+'));
            const uncertain = suspects.filter(s => s.startsWith('?'));

            this.setText('#info-suspect-count', certain.length + stateChanged.length);

            if (suspects.length === 0) {
                el.innerHTML = `<div class="empty-state">${this.lang === 'zh' ? '无嫌疑模块' : 'No suspect modules'}</div>`;
                this.renderReadiness();
                return;
            }

            let html = '';
            certain.forEach(s => {
                const name = this.escapeHtml(s);
                html += `<div class="suspect-module-item">
                    <span class="suspect-icon">&#9888;</span>
                    <div class="suspect-info"><div class="suspect-name">${name}</div></div>
                    <span class="module-tag disabled">${this.lang === 'zh' ? '嫌疑' : 'Suspect'}</span>
                </div>`;
            });
            stateChanged.forEach(s => {
                const name = this.escapeHtml(s.substring(1)); // strip + prefix
                html += `<div class="suspect-module-item" style="opacity:0.85;">
                    <span class="suspect-icon">&#8635;</span>
                    <div class="suspect-info"><div class="suspect-name">${name}</div></div>
                    <span class="suspect-uncertain-tag">${this.lang === 'zh' ? '状态变化' : 'Changed'}</span>
                </div>`;
            });
            uncertain.forEach(s => {
                const name = this.escapeHtml(s.substring(1)); // strip ? prefix
                html += `<div class="suspect-module-item suspect-uncertain">
                    <span class="suspect-icon">?</span>
                    <div class="suspect-info"><div class="suspect-name">${name}</div></div>
                    <span class="suspect-uncertain-tag">${this.lang === 'zh' ? '参考' : 'Ref'}</span>
                </div>`;
            });
            el.innerHTML = html;
            this.renderReadiness();
        } catch (e) {
            console.warn('loadSuspectModules failed:', e);
        }
    }

    // === v3.0.1: 救砖级别展示 ===
    async loadRescueLevel() {
        try {
            const raw = await this.exec(`cat "${this.stateDir}/rescue_level" 2>/dev/null`);
            const level = parseInt(raw) || 0;
            const badge = this.qs('#rescue-level-badge');
            if (!badge) return;

            const levelLabels = {
                0: this.t('rescue_level_0'),
                1: this.t('rescue_level_1'),
                2: this.t('rescue_level_2')
            };
            const levelClasses = {
                0: 'rescue-level-badge-l0',
                1: 'rescue-level-badge-l1',
                2: 'rescue-level-badge-l2'
            };

            badge.textContent = levelLabels[level] || this.t('rescue_level_label');
            badge.className = `badge ${levelClasses[level] || 'badge-info'}`;
            this.rescueLevel = level;
            this.renderReadiness();
        } catch (e) {
            console.warn('loadRescueLevel failed:', e);
        }
    }

    async saveGoodModules() {
        try {
            const result = await this.exec(`. "${this.basePath}/common.sh" && manual_save_good_modules`);
            if (result) {
                this.toast(this.t('good_modules_saved') + (result !== '0' ? ` (${result})` : ''), 'success');
                await Promise.all([this.loadSuspectModules(), this.loadRescueLevel()]);
            } else {
                this.toast(this.t('save_failed'), 'error');
            }
        } catch (e) {
            this.toast(this.t('save_failed'), 'error');
        }
    }

    async clearSuspectLog() {
        try {
            await this.exec(`. "${this.basePath}/common.sh" && clear_suspect_log`);
            this.toast(this.t('suspect_cleared'), 'success');
            await this.loadSuspectModules();
        } catch (e) {
            this.toast(this.t('save_failed'), 'error');
        }
    }

    async resetRescueLevel() {
        try {
            await this.exec(`. "${this.basePath}/common.sh" && reset_rescue_level_state`);
            this.toast(this.t('rescue_level_reset'), 'success');
            await this.loadRescueLevel();
        } catch (e) {
            this.toast(this.t('save_failed'), 'error');
        }
    }

    // === v3.5.9: diagnostics and one-shot safe mode ===
    v35Command(functionName) {
        const allowed = new Set([
            'v35_simulate_rescue', 'v35_one_shot_status',
            'v35_arm_one_shot_safe_mode', 'v35_cancel_one_shot_safe_mode',
            'v35_generate_diagnostic_bundle'
        ]);
        if (!allowed.has(functionName)) throw new Error('Unsupported v3.5 action');
        return `MODDIR="${this.basePath}"; . "${this.basePath}/common.sh" 2>/dev/null && ${functionName}`;
    }

    v35SetOutput(output) {
        const box = this.qs('#v35-output');
        if (box) box.textContent = String(output || '--').trim() || '--';
    }

    async v35RunSimulation() {
        this.showLoading(true);
        try {
            const result = await this.exec(this.v35Command('v35_simulate_rescue'));
            this.v35SetOutput(result);
            this.toast(this.lang === 'zh' ? '只读模拟已完成' : 'Read-only simulation completed', 'success');
        } catch (e) {
            this.v35SetOutput(this.lang === 'zh' ? '模拟失败，请查看救援日志。' : 'Simulation failed. Check the rescue log.');
            this.toast(this.t('save_failed'), 'error');
        }
        this.showLoading(false);
    }

    async v35RefreshStatus() {
        try {
            const result = await this.exec(this.v35Command('v35_one_shot_status'));
            this.v35SetOutput(result);
        } catch (e) {
            this.v35SetOutput(this.lang === 'zh' ? '无法读取一次性安全模式状态。' : 'Unable to read one-shot safe mode status.');
        }
    }

    async v35ArmOneShotSafeMode() {
        // v3.5.9: Show a dry-run diff preview before the user confirms.
        this.showLoading(true);
        let preview = '';
        try {
            const previewR = await this.execStrict(`${this.v35Command('v35_arm_one_shot_safe_mode --dry-run')}; rc=$?; echo PREVIEW_RC=$rc`);
            preview = previewR.stdout || '';
        } catch (_) { preview = ''; }
        this.showLoading(false);
        const diffLines = preview.split('\n').filter(l => l.startsWith('DISABLE:') || l.startsWith('SKIP:') || l.startsWith('PREVIEW_RC='));
        const diffSummary = diffLines.length > 0 ? diffLines.join('\n') : (this.lang === 'zh' ? '（无法获取预览，将直接执行）' : '(No preview available; will execute directly)');
        const message = this.lang === 'zh'
            ? `将立即写入本次事务涉及模块的禁用标记，下一次启动进入安全模式；成功启动后仅按事务清单恢复。不会触碰白名单或原先已禁用模块。\n\n=== 变更预览 ===\n${diffSummary}\n\n是否确认执行？`
            : `This writes disable markers for this transaction now, starts the next boot in safe mode, and restores only markers recorded in its journal after a successful boot. Whitelisted and previously disabled modules are untouched.\n\n=== Change Preview ===\n${diffSummary}\n\nConfirm and execute?`;
        // v3.5.9: Double confirmation for danger operations.
        if (!await this.confirmDialog(this.t('confirm_title'), message, this.t('btn_confirm'), 'btn-danger')) return;
        const finalMsg = this.lang === 'zh'
            ? '这是高风险操作：写入的禁用标记将在下次启动生效。确定要继续吗？'
            : 'This is a high-risk operation: disable markers will take effect on next boot. Are you sure?';
        if (!await this.confirmDialog(this.lang === 'zh' ? '二次确认' : 'Final Confirmation', finalMsg, this.t('btn_confirm'), 'btn-danger')) return;
        this.showLoading(true);
        try {
            const r = await this.execStrict(`${this.v35Command('v35_arm_one_shot_safe_mode')}; rc=$?; v35_one_shot_status; echo RESULT=$rc`);
            const result = r.stdout || '';
            this.v35SetOutput(result);
            if (r.ok && result.includes('RESULT=0')) {
                this.toast(this.lang === 'zh' ? '一次性安全模式已布防' : 'One-shot safe mode armed', 'success');
                await this.loadDisabledModules();
            } else if (r.timedOut) {
                this.toast(this.lang === 'zh' ? '操作超时' : 'Operation timed out', 'error');
            } else {
                this.toast(this.t('save_failed'), 'error');
            }
        } catch (e) {
            this.toast(this.t('save_failed'), 'error');
        }
        this.showLoading(false);
    }

    async v35CancelOneShotSafeMode() {
        const message = this.lang === 'zh'
            ? '将根据事务清单精确恢复 RescueX 本次写入的禁用标记；不会恢复原先已禁用的其他模块。是否继续？'
            : 'This restores only disable markers written by this RescueX transaction according to its journal. Previously disabled modules are not changed. Continue?';
        if (!await this.confirmDialog(this.t('confirm_title'), message, this.t('btn_confirm'), 'btn-filled')) return;
        this.showLoading(true);
        try {
            const result = await this.exec(`${this.v35Command('v35_cancel_one_shot_safe_mode')}; rc=$?; v35_one_shot_status; echo RESULT=$rc`);
            this.v35SetOutput(result);
            if (result.includes('RESULT=0')) {
                this.toast(this.lang === 'zh' ? '已按事务清单恢复' : 'Restored from transaction journal', 'success');
                await this.loadDisabledModules();
            } else {
                this.toast(this.t('save_failed'), 'error');
            }
        } catch (e) {
            this.toast(this.t('save_failed'), 'error');
        }
        this.showLoading(false);
    }

    async v35ExportDiagnostic() {
        this.showLoading(true);
        try {
            const script = `${this.v35Command('v35_generate_diagnostic_bundle')}; rc=$?; echo RESULT=$rc`;
            const r = await this.execStrict(script, EXEC_REPORT_TIMEOUT_MS);
            const result = r.stdout || '';
            this.v35SetOutput(result);
            if (r.ok && result.includes('RESULT=0')) {
                const pathMatch = result.match(/PATH=(\S+)/);
                const path = pathMatch ? pathMatch[1] : '';
                const ext = path.endsWith('.tar.gz') ? '.tar.gz' : (path.endsWith('.txt') ? '.txt' : '.zip');
                this.toast(this.lang === 'zh'
                    ? `诊断包已生成（${ext}）${path ? '，路径: ' + path : ''}`
                    : `Diagnostic bundle created (${ext})${path ? ', path: ' + path : ''}`, 'success', 6000);
                // v3.5.9: Offer to open a pre-filled GitHub Issue draft.
                const issueMsg = this.lang === 'zh'
                    ? '是否打开 GitHub Issue 草稿页面？诊断包不会被自动上传，你需要手动决定是否附加文件。'
                    : 'Open a pre-filled GitHub Issue draft? The diagnostic bundle will NOT be auto-uploaded; you decide whether to attach it.';
                const wantIssue = await this.confirmDialog(
                    this.lang === 'zh' ? '反馈 Issue' : 'Report Issue',
                    issueMsg,
                    this.t('btn_confirm'), 'btn-filled'
                );
                if (wantIssue) {
                    const body = encodeURIComponent(
                        `## RescueX Diagnostic Report\n\n` +
                        `Version: ${APP_VERSION}\n` +
                        `Date: ${new Date().toISOString()}\n\n` +
                        `### Diagnostic Summary\n\`\`\`\n${result.split('\n').filter(l => l.includes('PATH=') || l.includes('RESULT=')).join('\n')}\n\`\`\`\n\n` +
                        `### Description\n<!-- Describe the issue you encountered -->\n\n` +
                        `### Steps to Reproduce\n<!-- List the steps -->\n\n` +
                        `### Diagnostic Bundle\n<!-- The bundle was saved to your device (${ext}). Attach it here if you want to share it. -->\n`
                    );
                    const labels = encodeURIComponent('diagnostic');
                    this.openExternal(`${REPO_URL}/issues/new?labels=${labels}&body=${body}`);
                }
            } else if (r.timedOut) {
                this.toast(this.lang === 'zh' ? '诊断包生成超时' : 'Diagnostic bundle generation timed out', 'error');
            } else {
                this.toast(this.lang === 'zh' ? '诊断包生成失败' : 'Diagnostic bundle generation failed', 'error');
            }
        } catch (e) {
            this.toast(this.t('export_failed'), 'error');
        }
        this.showLoading(false);
    }

    // === v3.0.1: APP 解冻 (v3.5.9: 使用 execStrict 区分拒绝/失败/无项目) ===
    async unfreezeApps() {
        const confirm = await this.confirmDialog(
            this.t('confirm_title'),
            this.lang === 'zh'
                ? 'APP 解冻功能已永久退役。此操作不会再删除 package-restrictions.xml。'
                : 'APP unfreeze has been permanently retired. This action will not delete package-restrictions.xml.',
            this.t('btn_confirm'), 'btn-filled'
        );
        if (!confirm) return;
        this.showLoading(true);
        try {
            const r = await this.execStrict(`. "${this.basePath}/common.sh" && manual_unfreeze_apps 2>/dev/null; echo "RC=$?"`);
            const out = r.stdout || '';
            if (r.timedOut) {
                this.toast(this.lang === 'zh' ? '操作超时' : 'Operation timed out', 'error');
            } else if (out.includes('REFUSED')) {
                this.toast(this.lang === 'zh' ? 'APP 解冻已被安全策略拒绝' : 'APP unfreeze refused by safety policy', 'warn');
            } else if (out.includes('DONE')) {
                this.toast(this.t('unfreeze_done'), 'success');
            } else if (out.includes('NOT_FOUND') || out.includes('SKIP')) {
                this.toast(this.lang === 'zh' ? '没有需要解冻的项目' : 'No items to unfreeze', 'warn');
            } else {
                this.toast(this.lang === 'zh' ? 'APP 解冻已退役或未产生变更' : 'APP unfreeze retired or no change', 'warn');
            }
        } catch (e) {
            this.toast(this.t('save_failed'), 'error');
        }
        this.showLoading(false);
    }

    // === v3.0.1: 锁定脚本目录 ===
    // === Modal ===
    // v3.5.9: default focus is Cancel (not OK). Danger dialogs use Escape/Enter
    // to dismiss, never to confirm. Focus is trapped inside the overlay.
    confirmDialog(title, message, okText, okClass) {
        return new Promise(resolve => {
            const overlay = document.createElement('div');
            overlay.className = 'modal-overlay';
            overlay.setAttribute('role', 'dialog');
            overlay.setAttribute('aria-modal', 'true');
            overlay.setAttribute('aria-labelledby', 'rx-modal-title');
            overlay.setAttribute('aria-describedby', 'rx-modal-desc');
            const modal = document.createElement('div');
            modal.className = 'modal';
            const h3 = document.createElement('h3');
            h3.id = 'rx-modal-title';
            h3.textContent = title;
            const p = document.createElement('p');
            p.id = 'rx-modal-desc';
            p.textContent = message;
            const btns = document.createElement('div');
            btns.className = 'modal-buttons';
            const cancel = document.createElement('button');
            cancel.className = 'btn btn-text';
            cancel.textContent = this.t('btn_cancel');
            const ok = document.createElement('button');
            ok.className = `btn ${okClass || 'btn-filled'}`;
            ok.textContent = okText || this.t('btn_confirm');
            btns.appendChild(cancel);
            btns.appendChild(ok);
            modal.appendChild(h3);
            modal.appendChild(p);
            modal.appendChild(btns);
            overlay.appendChild(modal);
            document.body.appendChild(overlay);

            const close = (result) => { overlay.remove(); resolve(result); };
            cancel.onclick = () => close(false);
            ok.onclick = () => close(true);
            overlay.onclick = (e) => { if (e.target === overlay) close(false); };
            overlay.tabIndex = -1;
            overlay.focus();
            overlay.onkeydown = (e) => {
                if (e.key === 'Escape') { e.preventDefault(); close(false); }
                else if (e.key === 'Enter') {
                    // For danger buttons, Enter dismisses (cancel), not confirms.
                    const isDanger = (okClass || '').includes('danger');
                    e.preventDefault();
                    close(!isDanger);
                } else if (e.key === 'Tab') {
                    // Simple focus trap: cycle between cancel and ok.
                    e.preventDefault();
                    if (document.activeElement === ok) cancel.focus();
                    else ok.focus();
                }
            };
            // v3.5.9: default focus is Cancel, not OK.
            setTimeout(() => cancel.focus(), 50);
        });
    }
}

// v3.5.9: Restore instantiation that was accidentally removed.
window.RescueXUI = RescueXUI;

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => new RescueXUI());
} else {
    new RescueXUI();
}

})();
