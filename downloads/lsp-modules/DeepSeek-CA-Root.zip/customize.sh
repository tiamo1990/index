#!/system/bin/sh
ui_print "- Repository: https://github.com/lllucccian/Deekseep"
ENVIRONMENT="Unknown root manager"
if [ "$APATCH" = "true" ] || [ -x /data/adb/ap/bin/apd ]; then
  ENVIRONMENT="APatch"
elif [ "$KSU" = "true" ] || [ -x /data/adb/ksu/bin/ksud ]; then
  KSU_NAME="$(/data/adb/ksu/bin/ksud -V 2>/dev/null)"
  case "$KSU_NAME" in *Suki*|*suki*) ENVIRONMENT="SukiSU Ultra" ;;
    *) ENVIRONMENT="KernelSU" ;; esac
elif command -v magisk >/dev/null 2>&1; then
  MAGISK_NAME="$(magisk -V 2>/dev/null)"
  case "$MAGISK_NAME" in *alpha*|*Alpha*) ENVIRONMENT="Magisk Alpha" ;;
    *) ENVIRONMENT="Magisk" ;; esac
fi
ui_print "- Detected: $ENVIRONMENT"
ui_print "- CA file: 95ed143f.0"
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/system/etc/security/cacerts/95ed143f.0 0 0 0644
ui_print "- Reboot after installation"
